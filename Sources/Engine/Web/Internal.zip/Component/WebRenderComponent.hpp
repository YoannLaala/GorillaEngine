#ifndef _WEB_RENDER_COMPONENT_HPP_
#define _WEB_RENDER_COMPONENT_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>
#include <Web/Component/WebComponent.hpp>
#include <Renderer/RenderComponent.hpp>

/******************************************************************************
**	Class Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebRenderComponent : public WebComponent, public Renderer::RenderComponent
	{
	public:
		WebRenderComponent();
		~WebRenderComponent();

		virtual void Start() override;
		virtual void Stop() override;
	};
}}
#endif