/******************************************************************************
**	Includes
******************************************************************************/
#include "WebComponentRectangle.hpp"

#include <Web/Property/WebProperty.hpp>
#include <Web/WebResourceFactory.hpp>

#include <Renderer/Color.hpp>
#include <Renderer/Canvas/CanvasContext.hpp>

/******************************************************************************
**	Class Definition
******************************************************************************/
namespace Gorilla { namespace Web
{
	//!	@brief		Constructor
	//!	@date		2016-26-03
	WebComponentRectangle::WebComponentRectangle()
		: m_pGeometry(NULL)
		, m_pColor(NULL)
	{
		// Nothing to do
	}

	//!	@brief		Destructor
	//!	@date		2016-26-03
	WebComponentRectangle::~WebComponentRectangle()
	{
		// Nothing to do
	}

	//!	@brief		Update
	//!	@date		2016-26-03
	void WebComponentRectangle::Update()
	{
		// Nothing to do
	}

	//!	@brief		OnPropertyChanged
	//!	@date		2016-26-03
	void WebComponentRectangle::OnPropertyChanged(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, EWebProperty::Type _eProperty, const WebProperty* _pProperty)
	{
		switch(_eProperty)
		{
			case EWebProperty::BackgroundColor:
			{
				_pContext->DestroyResource(m_pColor);
				m_pColor = WebResourceFactory::GetBrush(_pContext, _pSurface, _pProperty->GetUInt32());
				break;
			}
		}
	}

	//!	@brief		OnSizeChanged
	//!	@date		2016-26-03
	void WebComponentRectangle::OnSizeChanged(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, float32 _fWidth, float32 _fHeight)
	{
		_pContext->DestroyResource(m_pGeometry);
		m_pGeometry = WebResourceFactory::GetRectangle(_pContext, _pSurface, _fWidth, _fHeight);

		// Default Color
		if(!m_pColor)
		{
			m_pColor = WebResourceFactory::GetBrush(_pContext, _pSurface, Renderer::Color::White);
		}
	}

	//!	@brief		PushCommand
	//!	@date		2015-12-29
	void WebComponentRectangle::PushCommand(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, const Math::Matrix33& _mTransform)
	{ 
		_pContext->PushGeometryFilled(_pSurface, m_pGeometry, m_pColor, _mTransform);

		/*WebElement* pElement = GetElement();
		const WebComponentNode* pCpnNode = pElement->GetComponent<WebComponentNode>();

		_pContext->FillGeometry(_pSurface, m_pGeometry, m_pColor, pCpnNode->GetPositionLeft(), pCpnNode->GetPositionTop());*/
	}
}}