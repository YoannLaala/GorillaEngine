/******************************************************************************
**	Includes
******************************************************************************/
#include "WebComponent.hpp"

/******************************************************************************
**	Class Definition
******************************************************************************/
namespace Gorilla { namespace Web
{
	//!	@brief		Constructor
	//!	@date		2015-12-29
	WebComponent::WebComponent()
		: m_eState(EState::Start)
		, m_eFlag(0)
	{
		// Nothing to do
	}

	//!	@brief		Destructor
	//!	@date		2015-12-29
	WebComponent::~WebComponent()
	{
		// Nothing to do
	}
	
	//!	@brief		Execute
	//!	@date		2015-12-29
	void WebComponent::Execute()
	{
		switch(m_eState)
		{
			case EState::Start:
			{
				Start();
				SetState(EState::Update);
				break;
			}

			case EState::Update:
			{
				Update();			
				break;
			}

			case EState::Stop:
			{
				Stop();
				SetState(EState::Inactive);
				break;
			}
		}
	}

	//!	@brief		Start
	//!	@date		2015-12-29
	void WebComponent::Start()
	{
		// Nothing to do
	}

	//!	@brief		Update
	//!	@date		2015-12-29
	void WebComponent::Update()
	{
		// Nothing to do
	}

	//!	@brief		Stop
	//!	@date		2015-12-29
	void WebComponent::Stop()
	{
		// Nothing to do
	}

	//!	@brief		OnPropertyChanged
	//!	@date		2015-12-29
	void WebComponent::OnPropertyChanged(Renderer::CanvasContext* /*_pContext*/, Renderer::CanvasSurface* /*_pSurface*/, EWebProperty::Type /*_eProperty*/, const WebProperty* /*_pProperty*/)
	{
		// Nothing to do
	}

	//!	@brief		OnSizeChanged
	//!	@date		2015-12-29
	void WebComponent::OnSizeChanged(Renderer::CanvasContext* /*_pContext*/, Renderer::CanvasSurface* /*_pSurface*/, float32 /*_fWidth*/, float32 /*_fHeight*/)
	{
		// Nothing to do
	}
}}