#ifndef _WEB_COMPONENT_RECTANGLE_HPP_
#define _WEB_COMPONENT_RECTANGLE_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>
#include <Web/Component/WebRenderComponent.hpp>

/******************************************************************************
**	Class Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebComponentRectangle : public WebRenderComponent
	{
	public:
		WebComponentRectangle();
		~WebComponentRectangle();
		DECLARE_WEB_COMPONENT(EWebComponent::Rectangle);

		virtual void Update() override;

	protected:
		virtual void OnPropertyChanged(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, EWebProperty::Type _eProperty, const WebProperty* _pProperty) override;
		virtual void OnSizeChanged(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, float32 _fWidth, float32 _fHeight) override;
		virtual void PushCommand(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, const Math::Matrix33& _mTransform) override;

	private:
		Renderer::CanvasGeometry* m_pGeometry;
		Renderer::CanvasBrush* m_pColor;
	};
}}

#endif