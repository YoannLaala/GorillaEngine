/******************************************************************************
**	Includes
******************************************************************************/
#include "WebComponentList.hpp"

/******************************************************************************
**	Class Definition
******************************************************************************/
namespace Gorilla { namespace Web
{
	//!	@brief		Constructor
	//!	@date		2016-26-03
	WebComponentList::WebComponentList()
	{
		// Nothing to do
	}

	//!	@brief		Destructor
	//!	@date		2016-26-03
	WebComponentList::~WebComponentList()
	{
		// Nothing to do
	}


	//!	@brief		Update
	//!	@date		2016-26-03
	void WebComponentList::Update()
	{
		
	}

	//!	@brief		PushCommand
	//!	@date		2015-12-29
	void WebComponentList::PushCommand(Renderer::CanvasContext* /*_pContext*/, Renderer::CanvasSurface* /*_pSurface*/, const Math::Matrix33& /*_mTransform*/)
	{ 

	}
}}