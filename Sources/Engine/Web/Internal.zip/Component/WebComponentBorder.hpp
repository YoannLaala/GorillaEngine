#ifndef _WEB_COMPONENT_BORDER_HPP_
#define _WEB_COMPONENT_BORDER_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>
#include <Web/Component/WebRenderComponent.hpp>

/******************************************************************************
**	Class Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebComponentBorder : public WebRenderComponent
	{
	public:
		WebComponentBorder();
		~WebComponentBorder();
		DECLARE_WEB_COMPONENT(EWebComponent::Border);

		virtual void Update() override;

	protected:
		virtual void PushCommand(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, const Math::Matrix33& _mTranform) override;
	};
}}

#endif