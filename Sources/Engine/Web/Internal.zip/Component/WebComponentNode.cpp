/******************************************************************************
**	Includes
******************************************************************************/
#include "WebComponentNode.hpp"

#include <Web/Element/WebElement.hpp>
#include <Web/Document/WebPage.hpp>
#include <Renderer/Tree/QuadTree.hpp>
#include <Renderer/Canvas/Resource/Texture/CanvasSurface.hpp>

/******************************************************************************
**	Class Definition
******************************************************************************/
namespace Gorilla { namespace Web
{
	//!	@brief		Constructor
	//!	@date		2015-12-29
	WebComponentNode::WebComponentNode()
		: m_pNode(NULL)
		, m_eDisplay(EWebPropertyDisplay::Inline)
	{
		m_pNode = new Renderer::Node();
	}

	//!	@brief		Destructor
	//!	@date		2015-12-29
	WebComponentNode::~WebComponentNode()
	{
		SAFE_DELETE(m_pNode);
	}

	//!	@brief		Start
	//!	@date		2015-12-29
	void WebComponentNode::Start()
	{
		GetElement()->GetPage()->GetTree()->Add(m_pNode);
	}

	//!	@brief		Stop
	//!	@date		2015-12-29
	void WebComponentNode::Stop()
	{
		GetElement()->GetPage()->GetTree()->Remove(m_pNode);
	}

	//!	@brief		OnPropertyChanged
	//!	@date		2016-26-03
	void WebComponentNode::OnPropertyChanged(Renderer::CanvasContext* /*_pContext*/, Renderer::CanvasSurface* _pSurface, EWebProperty::Type _eProperty, const WebProperty* _pProperty)
	{
		/*EWebPropertyDisplay::Type eDisplay = (EWebPropertyDisplay::Type)WebPropertyValueComputer::Enum(_pElement, EWebProperty::Display);*/
		Math::Vector2 vSizeMax((float32)_pSurface->GetWidth(), (float32)_pSurface->GetHeight());
		WebElement* pParent = GetElement()->GetParent();
		if(pParent)
		{
			WebComponentNode* pCpnNodeParent = pParent->GetComponent<WebComponentNode>(); 
			if(pCpnNodeParent)
			{
				vSizeMax.Set(pCpnNodeParent->GetWidth(), pCpnNodeParent->GetHeight());
			}
		}

		switch(_eProperty)
		{
			case EWebProperty::Display:
			{
				m_eDisplay = (EWebPropertyDisplay::Type)_pProperty->GetUInt32();
				break;
			}

			case EWebProperty::Width:
			{
				m_vSize.SetX(WebPropertyValueComputer::Size(_pProperty, vSizeMax.GetX(), 0.0f, vSizeMax.GetX()));
				break;
			}

			case EWebProperty::Height:
			{
				m_vSize.SetY(WebPropertyValueComputer::Size(_pProperty, vSizeMax.GetY(), 0.0f, vSizeMax.GetY()));
				break;
			}
		}
		
		GetElement()->SetFlag(WebElement::EFlag::LayoutChanged);
		/*Math::Vector2 m_vMargin;
		Math::Vector2 m_vPadding;
		switch(eDisplay)
		{
			case EWebPropertyDisplay::Block:
			{
				m_vMargin.SetX(WebPropertyValueAnalyzer::ComputeSize(_pElement, EWebProperty::MarginLeft));
				m_vMargin.SetY(WebPropertyValueAnalyzer::ComputeSize(_pElement, EWebProperty::MarginTop));

				m_vPadding.SetX(WebPropertyValueAnalyzer::ComputeSize(_pElement, EWebProperty::PaddingLeft));
				m_vPadding.SetY(WebPropertyValueAnalyzer::ComputeSize(_pElement, EWebProperty::PaddingTop));
				break;
			}
		}*/

		/*switch(_eProperty)
		{
			case EWebProperty::Display:
			{
				m_eDisplay = (EWebPropertyDisplay::Type)_pProperty->GetUInt32();
				break;
			}

			case EWebProperty::MarginTop:
			{
				m_vMargin.SetY(ComputeHeight(_pProperty));
				break;
			}

			case EWebProperty::MarginRight:
			{
				m_vMargin.SetZ(ComputeWidth(_pProperty));
				break;
			}

			case EWebProperty::MarginBottom:
			{
				m_vMargin.SetW(ComputeHeight(_pProperty));
				break;
			}

			case EWebProperty::MarginLeft:
			{
				m_vMargin.SetX(ComputeWidth(_pProperty));
				break;
			}

			case EWebProperty::Left:
			{
				m_vPosition.SetX(ComputeSize(_pProperty));
				break;
			}

			case EWebProperty::Top:
			{
				m_vPosition.SetY(ComputeSize(_pProperty));
				break;
			}

			case EWebProperty::Width:
			{
				m_vSize.SetX(ComputeWidth(_pProperty));
				break;
			}

			case EWebProperty::Height:
			{
				m_vSize.SetY(ComputeHeight(_pProperty));
				break;
			}
		}*/
	}
}}