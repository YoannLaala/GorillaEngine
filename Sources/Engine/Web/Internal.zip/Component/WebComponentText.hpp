#ifndef _WEB_COMPONENT_TEXT_HPP_
#define _WEB_COMPONENT_TEXT_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>
#include <Web/Component/WebRenderComponent.hpp>

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla { namespace Renderer
{
	class CanvasText;
	class CanvasFont;
	class CanvasBrush;
}}

/******************************************************************************
**	Class Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebComponentText : public WebRenderComponent
	{
	public:
		WebComponentText();
		~WebComponentText();
		DECLARE_WEB_COMPONENT(EWebComponent::Text);

		virtual void Update() override;

	protected:
		virtual void OnPropertyChanged(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, EWebProperty::Type _eProperty, const WebProperty* _pProperty) override;
		virtual void PushCommand(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, const Math::Matrix33& _mTranform) override;

	private:
		Renderer::CanvasText* m_pText;
		Renderer::CanvasFont* m_pFont;
		Renderer::CanvasBrush* m_pColor;
	};
}}

#endif