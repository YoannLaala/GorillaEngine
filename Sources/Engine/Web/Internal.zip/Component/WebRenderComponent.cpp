/******************************************************************************
**	Includes
******************************************************************************/
#include "WebRenderComponent.hpp"

#include <Web/Element/WebElement.hpp>
#include <Web/Component/WebComponentNode.hpp>

/******************************************************************************
**	Class Definition
******************************************************************************/
namespace Gorilla { namespace Web
{
	//!	@brief		Constructor
	//!	@date		2015-12-29
	WebRenderComponent::WebRenderComponent()
	{
		// Nothing to do
	}

	//!	@brief		Destructor
	//!	@date		2015-12-29
	WebRenderComponent::~WebRenderComponent()
	{
		// Nothing to do
	}

	//!	@brief		Start
	//!	@date		2016-03-26
	void WebRenderComponent::Start()
	{
		WebComponentNode* pCpnNode = GetElement()->GetComponent<WebComponentNode>();
		pCpnNode->AddRenderComponent(this);
	}

	//!	@brief		Stop
	//!	@date		2016-03-26
	void WebRenderComponent::Stop()
	{
		WebComponentNode* pCpnNode = GetElement()->GetComponent<WebComponentNode>();
		pCpnNode->RemoveRenderComponent(this);
	}
}}