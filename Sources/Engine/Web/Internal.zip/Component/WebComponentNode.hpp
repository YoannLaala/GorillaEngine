#ifndef _WEB_COMPONENT_NODE_HPP_
#define _WEB_COMPONENT_NODE_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>
#include <Web/Component/WebComponent.hpp>
#include <Web/Property/Enum/WebPropertyDisplay.hpp>

#include <Renderer/Node.hpp>

/******************************************************************************
**	Class Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebComponentNode : public WebComponent
	{
	public:
		WebComponentNode();
		~WebComponentNode();
		DECLARE_WEB_COMPONENT(EWebComponent::Node);

		virtual void Start() override;
		virtual void Stop() override;

		// Display
		inline EWebPropertyDisplay::Type GetDisplayType() const { return m_eDisplay; }

		// Position
		inline float32				GetLeft() const { return m_pNode->GetPosition().GetX(); }
		inline float32				GetTop() const { return m_pNode->GetPosition().GetY(); }
		inline void					SetLeft(float32 _fLeft) { m_pNode->SetPosition(_fLeft, m_pNode->GetPosition().GetY(), m_pNode->GetPosition().GetZ()); }
		inline void					SetTop(float32 _fTop) { m_pNode->SetPosition(m_pNode->GetPosition().GetX(), _fTop, m_pNode->GetPosition().GetZ()); }
		inline void					SetPosition(float32 _fLeft, float32 _fTop) { m_pNode->SetPosition(_fLeft,  _fTop, 0.0f); }
		inline const Math::Vector2&	GetPosition() const { return *reinterpret_cast<const Math::Vector2*>(&m_pNode->GetPosition()); }

		// Margin
		inline float32				GetMarginTop() const { return m_vMargin.GetY(); }
		inline float32				GetMarginRight() const { return m_vMargin.GetZ(); }
		inline float32				GetMarginBottom() const { return m_vMargin.GetW(); }
		inline float32				GetMarginLeft() const { return m_vMargin.GetX(); }
		inline void					SetMarginTop(float32 _fMargin) {  m_vMargin.SetY(_fMargin); }
		inline void					SetMarginRight(float32 _fMargin) { m_vMargin.SetZ(_fMargin); }
		inline void					SetMarginBottom(float32 _fMargin) { m_vMargin.SetW(_fMargin); }
		inline void					SetMarginLeft(float32 _fMargin) { m_vMargin.SetX(_fMargin); }

		// Size
		inline float32				GetWidth() const { return m_vSize.GetX(); }
		inline float32				GetHeight() const { return m_vSize.GetY(); }
		inline void					SetSize(float32 _fWidth, float32 _fHeight) { m_vSize.Set(_fWidth, _fHeight); }
		//inline void					SetWidth(float32 _fWidth) { m_vSize.SetX(_fWidth); }
		//inline void					SetHeight(float32 _fHeight) { m_vSize.SetY(_fHeight); }

		// Render Component
		inline void					AddRenderComponent(Renderer::RenderComponent* _pComponent) { m_pNode->AddRenderComponent(_pComponent); }
		inline void					RemoveRenderComponent(Renderer::RenderComponent* _pComponent) { m_pNode->RemoveRenderComponent(_pComponent); }

	protected:
		virtual void OnPropertyChanged(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, EWebProperty::Type _eProperty, const WebProperty* _pProperty) override;

	private:
		Math::Vector4				m_vMargin;
		Math::Vector2				m_vPadding;
		Math::Vector2				m_vSize;	
		Renderer::Node*				m_pNode;
		EWebPropertyDisplay::Type	m_eDisplay;
	};
}}
#endif