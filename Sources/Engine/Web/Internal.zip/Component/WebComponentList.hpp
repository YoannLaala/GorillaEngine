#ifndef _WEB_COMPONENT_LIST_HPP_
#define _WEB_COMPONENT_LIST_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>
#include <Web/Component/WebRenderComponent.hpp>

/******************************************************************************
**	Class Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebComponentList : public WebRenderComponent
	{
	public:
		WebComponentList();
		~WebComponentList();
		DECLARE_WEB_COMPONENT(EWebComponent::List);

		virtual void Update() override;

	protected:
		virtual void PushCommand(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, const Math::Matrix33& _mTransform) override;
	};
}}

#endif