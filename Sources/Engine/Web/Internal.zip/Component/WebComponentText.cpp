/******************************************************************************
**	Includes
******************************************************************************/
#include "WebComponentText.hpp"

#include <Renderer/Canvas/Resource/Text/CanvasText.hpp>
#include <Renderer/Canvas/Resource/Text/CanvasFont.hpp>

#include <Web/Document/WebPage.hpp>
#include <Web/Element/WebElement.hpp>
#include <Web/Component/WebComponentNode.hpp>

/******************************************************************************
**	Class Definition
******************************************************************************/
namespace Gorilla { namespace Web
{
	//!	@brief		Constructor
	//!	@date		2016-26-03
	WebComponentText::WebComponentText()
		: m_pText(NULL)
		, m_pFont(NULL)
		, m_pColor(NULL)
	{
		// Nothing to do
	}

	//!	@brief		Destructor
	//!	@date		2016-26-03
	WebComponentText::~WebComponentText()
	{
		// Nothing to do
	}

	//!	@brief		Update
	//!	@date		2016-26-03
	void WebComponentText::Update()
	{
		/*if(m_pText && GetElement()->HasFlag(WebElement::PropertyChanged))
		{
			WebComponentNode* pCpnNode = GetElement()->GetComponent<WebComponentNode>();
			Math::Vector2 vSizeMax(WebPropertyValueComputer::Size(GetElement(), EWebProperty::Width, m_pText->GetWidth(), 0.0f, pCpnNode->GetWidth()));
		}

		if(m_pText)
		{
			


			m_vSize.SetX(WebPropertyValueComputer::Size(_pElement, EWebProperty::Width, pCpnNodeParent->GetWidth(), 0.0f, pCpnNodeParent->GetWidth()));

			const WebProperty* pWidthProperty = GetElement()->GetPropertyChanged(EWebProperty::Width);
			const WebProperty* pHeightProperty = GetElement()->GetPropertyChanged(EWebProperty::Width);
			WebComponentNode* pCpnNode = GetElement()->GetComponent<WebComponentNode>();
			if(pCpnNode->HasFlag(WebComponent::EFlag::PropertyChanged))
			{
				m_pText
			}

			m_pText->GetHandle
		}*/
	}

	//!	@brief		OnPropertyChanged
	//!	@date		2016-26-03
	void WebComponentText::OnPropertyChanged(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, EWebProperty::Type _eProperty, const WebProperty* _pProperty)
	{
		switch(_eProperty)
		{
			case EWebProperty::FontFamily:
			{
				Renderer::CanvasFont* pFontOld = m_pFont;
				m_pFont = WebResourceFactory::GetFont(_pContext,  _pProperty->GetString() , pFontOld->GetSize(), pFontOld->GetWeight(), pFontOld->GetStyle());
				_pContext->DestroyResource(pFontOld);

				break;
			}

			case EWebProperty::FontSize:
			{
				Renderer::CanvasFont* pFontOld = m_pFont;
				m_pFont = WebResourceFactory::GetFont(_pContext, pFontOld->GetFamily().GetBuffer() , WebPropertyValueComputer::Size(_pProperty, EWebProperty::FontSize), pFontOld->GetWeight(), pFontOld->GetStyle());
				_pContext->DestroyResource(pFontOld);

				break;
			}

			case EWebProperty::FontWeight:
			{
				Renderer::CanvasFont* pFontOld = m_pFont;
				m_pFont = WebResourceFactory::GetFont(_pContext,  pFontOld->GetFamily().GetBuffer() , pFontOld->GetSize(), _pProperty->GetUInt32(), pFontOld->GetStyle());
				_pContext->DestroyResource(pFontOld);

				break;
			}

			case EWebProperty::FontStyle:
			{
				Renderer::CanvasFont* pFontOld = m_pFont;
				m_pFont = WebResourceFactory::GetFont(_pContext,  pFontOld->GetFamily().GetBuffer() , pFontOld->GetSize(), pFontOld->GetWeight(), (Renderer::EFontStyle::Type)_pProperty->GetUInt32());
				_pContext->DestroyResource(pFontOld);

				break;
			}

			case EWebProperty::Color:
			{
				_pContext->DestroyResource(m_pColor);
				m_pColor = WebResourceFactory::GetBrush(_pContext, _pSurface, _pProperty->GetUInt32());

				break;
			}

			case EWebProperty::Content:
			{
				// Default Color
				if(!m_pColor)
				{
					m_pColor = WebResourceFactory::GetBrush(_pContext, _pSurface, Renderer::Color::Black);
				}

				// Default Font
				if(!m_pFont)
				{
					m_pFont = WebResourceFactory::GetFont(_pContext, DEFAULT_FONT_FAMILY, DEFAULT_FONT_SIZE, DEFAULT_FONT_WEIGHT, DEFAULT_FONT_STYLE);
				}

				// Create Text
				_pContext->DestroyResource(m_pText);
				m_pText = WebResourceFactory::GetText(_pContext, _pSurface, _pProperty->GetString(), m_pFont);		

				// Update Size
				if(!GetElement()->HasPropertyState(EWebProperty::Width))
				{
					WebProperty kProperty(EWebPropertyUnit::Pixel, m_pText->GetWidth());
					GetElement()->SetProperty(EWebProperty::Width, &kProperty);
				}
				
				if(!GetElement()->HasPropertyState(EWebProperty::Height))
				{
					WebProperty kProperty(EWebPropertyUnit::Pixel, m_pText->GetHeight());
					GetElement()->SetProperty(EWebProperty::Height, &kProperty);
				}

				break;
			}
		}
	}

	//!	@brief		PushCommand
	//!	@date		2015-12-29
	void WebComponentText::PushCommand(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, const Math::Matrix33& _mTranform)
	{ 
		if(m_pText)
		{
			_pContext->PushText(_pSurface, m_pText, m_pColor, _mTranform);
		}
	}
}}