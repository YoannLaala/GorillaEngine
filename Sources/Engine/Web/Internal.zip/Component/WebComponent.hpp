#ifndef _WEB_COMPONENT_HPP_
#define _WEB_COMPONENT_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>

/******************************************************************************
**	Defines
******************************************************************************/
#define DECLARE_WEB_COMPONENT(_type_)											\
class RTTI																		\
{																				\
public:																			\
	static EWebComponent::Type GetType() { return _type_; }						\
};																				\
virtual EWebComponent::Type GetType() const override{ return RTTI::GetType(); }	\

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebElement;
	class WebProperty;
}}

namespace Gorilla { namespace Renderer
{
	class CanvasContext;
	class CanvasSurface;
}}

namespace Gorilla { namespace Web
{
	namespace EWebComponent
	{
		enum Type : uint8
		{
			Node = 0,
			Border,
			Rectangle,
			Elipse,
			List,
			Text,

			Count
		};	
	}
}}

/******************************************************************************
**	Class Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebComponent
	{
		friend class WebElement;

	public:
		WebComponent();
		~WebComponent();

		virtual EWebComponent::Type GetType() const = 0;

		void Execute();
		virtual void Start();
		virtual void Update();
		virtual void Stop();

	protected:
		struct EState
		{
			enum Type : uint8
			{
				Inactive = 0,
				Start,
				Update,
				Stop,
			};
		};

		struct EFlag
		{
			enum Type : uint8
			{
				PropertyChanged = 0x01,
			};
		};

	protected:
		virtual void OnPropertyChanged(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, EWebProperty::Type _eProperty, const WebProperty* _pProperty);
		virtual void OnSizeChanged(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, float32 _fWidth, float32 _fHeight);

		inline WebElement*	GetElement	() { return m_pElement; }
		inline void			SetElement	(WebElement* _pElement) { m_pElement = _pElement; }

		// State
		inline bool		HasState(EState::Type _eState) const { return m_eState == _eState; }
		inline void		SetState(EState::Type _eState) { m_eState = _eState; }

		// Flag
		inline bool		HasFlag		(EFlag::Type _eFlag) const { return (m_eFlag & _eFlag) != 0; }
		inline void		SetFlag		(EFlag::Type _eFlag) { m_eFlag |= _eFlag; }
		inline void		RemoveFlag	(EFlag::Type _eFlag) { m_eFlag &= ~_eFlag; }

	private:
		WebElement*		m_pElement;
		EState::Type	m_eState;
		uint8			m_eFlag;
	};
}}
#endif