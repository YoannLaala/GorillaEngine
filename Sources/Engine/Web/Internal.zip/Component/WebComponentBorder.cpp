/******************************************************************************
**	Includes
******************************************************************************/
#include "WebComponentBorder.hpp"

/******************************************************************************
**	Class Definition
******************************************************************************/
namespace Gorilla { namespace Web
{
	//!	@brief		Constructor
	//!	@date		2016-26-03
	WebComponentBorder::WebComponentBorder()
	{
		// Nothing to do
	}

	//!	@brief		Destructor
	//!	@date		2016-26-03
	WebComponentBorder::~WebComponentBorder()
	{
		// Nothing to do
	}


	//!	@brief		Update
	//!	@date		2016-26-03
	void WebComponentBorder::Update()
	{
		
	}

	//!	@brief		PushCommand
	//!	@date		2015-12-29
	void WebComponentBorder::PushCommand(Renderer::CanvasContext* /*_pContext*/, Renderer::CanvasSurface* /*_pSurface*/, const Math::Matrix33& /*_mTranform*/)
	{ 

	}
}}