#ifndef _WEB_DOCUMENT_HPP_
#define _WEB_DOCUMENT_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebBrowser;
	class WebPage;
	class WebElement;
}}

/******************************************************************************
**	Class Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebDocument
	{
		friend class WebBrowser;
		friend class WebPage;

	public:
		virtual void Parse(const char* _szBuffer, uint32 _uiSize = (uint32)-1) = 0;

	protected:
		struct EState
		{
			enum Type : uint8
			{
				Loading = 0,
				Loaded,
			};
		};

		WebDocument();
		~WebDocument();

		virtual void	ApplyOn(WebElement* _pElement) = 0;

		inline bool		HasState(EState::Type _eState) const { return m_eState == _eState; }
		inline void		SetState(EState::Type _eState) { m_eState = _eState; }

	private:
		EState::Type m_eState;
	};
}}
#endif