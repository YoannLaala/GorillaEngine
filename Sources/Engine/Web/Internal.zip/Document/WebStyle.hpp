#ifndef _WEB_STYLE_HPP_
#define _WEB_STYLE_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>

#include <Web/Document/WebDocument.hpp>
#include <Web/Element/WebElementStyle.hpp>
#include <katana-parser/src/katana.h>

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebBrowser;
	class WebSelector;
	class WebElement;
}}

/******************************************************************************
**	Class Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebStyle : public WebDocument
	{
		friend class WebBrowser;
		friend class WebElement;

	public:
		virtual void		Parse(const char* _szBuffer, uint32 _uiSize = (uint32)-1) override;

	protected:
		WebStyle();
		~WebStyle();

		static void			Parse(WebElementStyle* _pElement, const char* _szBuffer, uint32 _uiSize /*= (uint32)-1*/);
		static void			ParseElement(WebElementStyle* _pElement, KatanaStyleRule* _pKatanaStyleRule);
		static void			ParseProperty(WebElementStyle* _pElement, KatanaValue* _pKatanaValue, uint32 _eProperty, uint32 _uiOffset);
		static void			ParseSelector(WebSelector* _pSelector, KatanaSelector* pKatanaSelector);
		static void			AddProperty(WebElementStyle* _pElement, KatanaValue* _pKatanaValue, uint32 _eProperty, uint32 _eUnit, uint32 _eValue);

		virtual void		ApplyOn(WebElement* _pElement) override;

	private:
		Vector<WebElementStyle*> m_vStyle;
	};
}}
#endif