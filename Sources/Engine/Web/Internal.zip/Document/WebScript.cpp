/******************************************************************************
**	Includes
******************************************************************************/
#include "WebScript.hpp"

#pragma warning(push)
#pragma warning(disable : 4512)
#pragma warning(disable : 4100)
#pragma warning(disable : 4127)
#include <v8/include/v8.h>
#pragma warning(pop)

/******************************************************************************
**	Class Definition
******************************************************************************/
namespace Gorilla { namespace Web
{
	//!	@brief		Constructor
	//!	@date		2015-12-29
	WebScript::WebScript()
	{
		// Nothing to do
	}

	//!	@brief		Destructor
	//!	@date		2015-12-29
	WebScript::~WebScript()
	{
		// Nothing to do
	}

	// The callback that is invoked by v8 whenever the JavaScript 'print'
	// function is called.  Prints its arguments on stdout separated by
	// spaces and ending with a newline.
	void Print(const v8::FunctionCallbackInfo<v8::Value>& args) 
	{
		bool first = true;
		for (int i = 0; i < args.Length(); i++) 
		{
			v8::HandleScope handle_scope(args.GetIsolate());
			if (first)
				first = false;
			else
				printf(" ");
			v8::String::Utf8Value str(args[i]);
			LOG_PRINT("%s", *str);
		}
	}

	//!	@brief		Parse
	//!	@date		2015-12-29
	void WebScript::Parse(const char* _szBuffer, uint32 _uiSize /*= (uint32)-1*/)
	{
		_uiSize = _uiSize == (uint32)-1 ? (uint32)strlen(_szBuffer) : _uiSize;

		// Create a stack-allocated handle scope
		v8::Persistent<v8::Context, v8::CopyablePersistentTraits<v8::Context>> kContext;
		v8::Isolate* pIsolate = v8::Isolate::GetCurrent();
		{
			v8::HandleScope hStack(pIsolate);
				
			// Create a javascript function
			v8::Handle<v8::ObjectTemplate> hGlobal = v8::ObjectTemplate::New(pIsolate);
			hGlobal->Set(v8::String::NewFromUtf8(pIsolate, "print"), v8::FunctionTemplate::New(pIsolate, Print));

			// Create a new context
			v8::Handle<v8::Context> hContext = v8::Context::New(pIsolate, NULL, hGlobal);
			kContext = v8::Persistent<v8::Context>(pIsolate, hContext);
		}
		
		{
			v8::HandleScope hStack(pIsolate);

			v8::Handle<v8::Context> hContext = kContext.Get(pIsolate);
			hContext->Enter();

			// Compile script
			v8::Handle<v8::String> hName = v8::String::NewFromUtf8(hContext->GetIsolate(), "(my_source)");
			v8::Handle<v8::String> hSource = v8::String::NewFromUtf8(hContext->GetIsolate(), _szBuffer, v8::String::kNormalString, _uiSize);
			v8::Handle<v8::Script> hScript = v8::Script::Compile(hSource, hName);

			//Execute Script
			v8::Handle<v8::Value> hResult = hScript->Run();
			v8::String::Utf8Value str(hResult);
			printf("%s\n", *str);
			hContext->Exit();
		}

		kContext.Reset();
		SetState(WebDocument::EState::Loaded);
	}

	//!	@brief		ApplyOn
	//!	@date		2015-12-29
	void WebScript::ApplyOn(WebElement* /*_pElement*/)
	{
	
	}
}}