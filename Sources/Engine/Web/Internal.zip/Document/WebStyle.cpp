/******************************************************************************
**	Includes
******************************************************************************/
#include "WebStyle.hpp"

#include <Web/Property/Analyzer/WebPropertyAnalyzer.hpp>
#include <Web/Element/WebElementStyle.hpp>


/******************************************************************************
**	Class Definition
******************************************************************************/
namespace Gorilla { namespace Web
{
	//!	@brief		Constructor
	//!	@date		2015-12-29
	WebStyle::WebStyle()
	{
		// Nothing to do
	}

	//!	@brief		Destructor
	//!	@date		2015-12-29
	WebStyle::~WebStyle()
	{
		const uint32 uiStyleCount = m_vStyle.GetSize();
		for(uint32 uiStyle = 0; uiStyle < uiStyleCount; ++uiStyle)
		{
			WebElementStyle* pStyle = m_vStyle[uiStyle];
			SAFE_DELETE(pStyle);
		}
		m_vStyle.Clear();
	}

	//!	@brief		Parse
	//!	@date		2015-12-29
	void WebStyle::Parse(const char* _szBuffer, uint32 _uiSize /*= (uint32)-1*/)
	{
		_uiSize = _uiSize == (uint32)-1 ? (uint32)strlen(_szBuffer) : _uiSize;
		KatanaOutput* pKatanaOutput = katana_parse(_szBuffer, _uiSize, KatanaParserModeStylesheet);
		KatanaArray* pKatanaRuleArray = &pKatanaOutput->stylesheet->rules;
		const uint32 uiRuleCount = pKatanaRuleArray->length;
		for(uint32 uiRule = 0; uiRule < uiRuleCount; ++uiRule)
		{
			KatanaStyleRule* pKatanaRuleStyle = static_cast<KatanaStyleRule*>(pKatanaRuleArray->data[uiRule]);

			// Create & parse element
			WebElementStyle* pElement = new WebElementStyle();
			ParseElement(pElement, pKatanaRuleStyle);
			m_vStyle.Add(pElement);

			// Selectors
			KatanaArray* pKatanaSelectorArray = pKatanaRuleStyle->selectors;
			const uint32 uiSelectorCount = pKatanaSelectorArray->length;
			for(uint32 uiSelector = 0; uiSelector < uiSelectorCount; ++uiSelector)
			{
				KatanaSelector* pKatanaSelector = static_cast<KatanaSelector*>(pKatanaSelectorArray->data[uiSelector]);
				
				WebSelector& kSelector = pElement->AddSelector();
				ParseSelector(&kSelector, pKatanaSelector);
			}
		}
		katana_destroy_output(pKatanaOutput);
	}

	//!	@brief		Parse
	//!	@date		2015-12-29
	void WebStyle::Parse(WebElementStyle* _pElement, const char* _szBuffer, uint32 _uiSize /*= (uint32)-1*/)
	{
		_uiSize = _uiSize == (uint32)-1 ? (uint32)strlen(_szBuffer) : _uiSize;
		KatanaOutput* pKatanaOutput = katana_parse(_szBuffer, _uiSize, KatanaParserModeStylesheet);
		KatanaArray* pKatanaRuleArray = &pKatanaOutput->stylesheet->rules;
		const uint32 uiRuleCount = pKatanaRuleArray->length;
		for(uint32 uiRule = 0; uiRule < uiRuleCount; ++uiRule)
		{
			KatanaStyleRule* pKatanaRuleStyle = static_cast<KatanaStyleRule*>(pKatanaRuleArray->data[uiRule]);

			// Create & parse element
			ParseElement(_pElement, pKatanaRuleStyle);
		}
		katana_destroy_output(pKatanaOutput);
	}

	//!	@brief		ParsePropertyValue
	//! @details	Using WebPropertyAnalyzer
	//!	@date		2006-05-01
	void ParsePropertyValue(EWebProperty::Type _eProperty, KatanaValue* _pKatanaValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _eValueOut)
	{
		switch(_pKatanaValue->unit)
		{
			case KATANA_VALUE_NUMBER:
			case KATANA_VALUE_PX:
			{
				_eUnitOut = EWebPropertyUnit::Pixel;
				break;
			}

			case KATANA_VALUE_CM:
			{
				_eUnitOut = EWebPropertyUnit::Centimeter;
				break;
			}

			case KATANA_VALUE_MM:
			{
				_eUnitOut = EWebPropertyUnit::Millimeter;
				break;
			}

			case KATANA_VALUE_IN:
			{
				_eUnitOut = EWebPropertyUnit::Inch;
				break;
			}

			case KATANA_VALUE_PT:
			{
				_eUnitOut = EWebPropertyUnit::Point;
				break;
			}

			case KATANA_VALUE_PC:
			{
				_eUnitOut = EWebPropertyUnit::Pica;
				break;
			}

			case KATANA_VALUE_S:
			{
				_eUnitOut = EWebPropertyUnit::Time;
				break;
			}

			case KATANA_VALUE_PERCENTAGE:
			{
				_eUnitOut = EWebPropertyUnit::Percentage;
				break;
			}

			case KATANA_VALUE_EMS:
			{
				_eUnitOut = EWebPropertyUnit::Em;
				break;
			}

			case KATANA_VALUE_PARSER_HEXCOLOR:
			case KATANA_VALUE_PARSER_FUNCTION:
			{
				_eUnitOut = EWebPropertyUnit::Color;
				break;
			}

			case KATANA_VALUE_URI:
			case KATANA_VALUE_STRING:
			{
				_eUnitOut = EWebPropertyUnit::String;
				break;
			}

			// Find static value from string
			case KATANA_VALUE_IDENT:
			{
				WebPropertyAnalyzer<EWebProperty::Unknown>::ParseValue(_eProperty, _pKatanaValue->string, _eUnitOut, _eValueOut);
				break;
			}

			default:
			{
				ASSERT(false, "Not supported");
				break;
			}
		}
	}
	
	//!	@brief		GetAtomicProperty
	//! @details	Using WebPropertyAnalyzer
	//!	@date		2006-05-01
	EWebProperty::Type GetAtomicProperty(EWebProperty::Type _eProperty, EWebPropertyUnit::Type _eUnit, uint32 _uiOffset)
	{
		return WebPropertyAnalyzer<EWebProperty::Unknown>::GetAtomicProperty(_eProperty, _eUnit, _uiOffset);
	}

	//!	@brief		ParseElement
	//!	@date		2015-12-29
	void WebStyle::ParseElement(WebElementStyle* _pElement, KatanaStyleRule* _pKatanaStyleRule)
	{
		if(_pKatanaStyleRule->base.type != KatanaRuleStyle)
		{
			return;
		}

		// Declarations
		KatanaArray* pKatanaDeclarationArray = _pKatanaStyleRule->declarations;
		const uint32 uiDeclarationCount = pKatanaDeclarationArray->length;
		for(uint32 uiDeclaration = 0; uiDeclaration < uiDeclarationCount; ++uiDeclaration)
		{
			KatanaDeclaration* pKatanaDeclaration = static_cast<KatanaDeclaration*>(pKatanaDeclarationArray->data[uiDeclaration]);
					
			// Find the property from the name - maybe the shorthand
			EWebProperty::Type eProperty = EWebProperty::Find(pKatanaDeclaration->property);
			if(eProperty == EWebProperty::Unknown)
			{
				continue;
			}

			KatanaArray* pKatanaValueArray = pKatanaDeclaration->values;
			const uint32 uiValueCount = pKatanaValueArray->length;
			uint32 uiValueOffset = uiValueCount > 1 ? 1 : 0;
			for(uint32 uiValue = 0; uiValue < uiValueCount; ++uiValue)
			{	
				KatanaValue* pKatanaValue = static_cast<KatanaValue*>(pKatanaValueArray->data[uiValue]);

				// Parse value and unit associated
				uint32 eValue = (uint32)-1;
				EWebPropertyUnit::Type eUnit = EWebPropertyUnit::Unknown;
				ParsePropertyValue(eProperty, pKatanaValue, eUnit, eValue);
				if(eUnit == EWebPropertyUnit::Unknown)
				{
					continue;
				}

				//// If this is a short hand to specific top - right - bottom - left
				//// We add 4 times the same value if generic value specified
				//// margin: 8px; // Propagate 8px on each side	
				uint32 uiPropertyToAddCount = uiValueCount;
				switch(eProperty)
				{
					case EWebProperty::Margin:
					case EWebProperty::Border:
					case EWebProperty::BorderColor:
					case EWebProperty::BorderStyle:
					case EWebProperty::BorderWidth:
					case EWebProperty::Padding:
					{
						uiPropertyToAddCount = uiValueCount == 1 ? 4 : uiValueCount;
						uiValueOffset = 1;
						break;
					}
				}
				
				// Check if this is a shorthand - in this case we must get the proper WebProperty
				// Will tranform backtground: red into background-color: red
				// It will also check if the unit is valid for the property
				for(uint32 uiPropertyToAdd = 0; uiPropertyToAdd < uiPropertyToAddCount; ++uiPropertyToAdd)
				{
					uint32 uiOffset = uiValue + uiPropertyToAdd + uiValueOffset;
					EWebProperty::Type eAtomicProperty = GetAtomicProperty(eProperty, eUnit, uiOffset);
					if(eAtomicProperty == EWebProperty::Unknown)
					{
						continue;
					}

					AddProperty(_pElement, pKatanaValue, eAtomicProperty, eUnit, eValue);
				}
			}
		}
	}

	//!	@brief		AddProperty
	//!	@date		2015-12-29
	void WebStyle::AddProperty(WebElementStyle* _pElement, KatanaValue* _pKatanaValue, uint32 _eProperty, uint32 _eUnit, uint32 _eValue)
	{
		WebProperty& kProperty = _pElement->AddProperty((EWebProperty::Type)_eProperty);
		switch(_eUnit)
		{
			case EWebPropertyUnit::Number:
			case EWebPropertyUnit::Time:

			// Size
			case EWebPropertyUnit::Pixel:
			case EWebPropertyUnit::Centimeter:
			case EWebPropertyUnit::Millimeter:
			case EWebPropertyUnit::Inch:
			case EWebPropertyUnit::Point:
			case EWebPropertyUnit::Pica:
			case EWebPropertyUnit::Percentage:
			case EWebPropertyUnit::Em:
			{
				kProperty.Set((EWebPropertyUnit::Type)_eUnit, (float32)_pKatanaValue->fValue);
				break;
			}

			case EWebPropertyUnit::String:
			{
				kProperty.Set(EWebPropertyUnit::String, _pKatanaValue->string);
				break;
			}

			// Enum
			case EWebPropertyUnit::AlignContent:
			case EWebPropertyUnit::Display:
			case EWebPropertyUnit::BackgroundAttachment:
			case EWebPropertyUnit::BackgroundRepeat:
			case EWebPropertyUnit::ListPosition:
			case EWebPropertyUnit::ListStyle:
			{
				kProperty.Set((EWebPropertyUnit::Type)_eUnit, _eValue);
				break;
			}

			// Border Style
			case EWebPropertyUnit::BorderStyle:
			{
				uint32 eBorderStyle = Renderer::ELineStyle::Solid;
				switch(_eValue)
				{
					case EWebPropertyBorderStyle::Hidden:
					case EWebPropertyBorderStyle::Dotted:
					case EWebPropertyBorderStyle::Dashed:
					case EWebPropertyBorderStyle::Solid:
					case EWebPropertyBorderStyle::Double:
					case EWebPropertyBorderStyle::Groove:
					case EWebPropertyBorderStyle::Ridge:
					case EWebPropertyBorderStyle::Inset:
					case EWebPropertyBorderStyle::Outset:
					{
						break;
					}
				}
				
				kProperty.Set(EWebPropertyUnit::BorderStyle, eBorderStyle);
				break;
			}

			case EWebPropertyUnit::FontStyle:
			{
				uint32 eFontStyle = Renderer::EFontStyle::Normal;
				switch(_eValue)
				{
					case EWebPropertyFontStyle::Italic:
					{
						eFontStyle = Renderer::EFontStyle::Italic;
						break;
					}

					case EWebPropertyFontStyle::Oblique:
					{
						eFontStyle = Renderer::EFontStyle::Oblique;
						break;
					}
				}

				kProperty.Set(EWebPropertyUnit::FontStyle, eFontStyle);
				break;
			}

			// Font weight
			case EWebPropertyUnit::FontWeight:
			{
				uint32 uiWeight = _pKatanaValue->iValue;
				if(_eValue != (uint32)-1)
				{
					switch(_eValue)
					{
						case EWebPropertyFontWeight::Bold:
						{
							uiWeight = Renderer::EFontWeight::Bold;
							break;
						}

						case EWebPropertyFontWeight::Bolder:
						{
							uiWeight = Renderer::EFontWeight::BoldExtra;
							break;
						}

						case EWebPropertyFontWeight::Lighter:
						{
							uiWeight = Renderer::EFontWeight::Light;
							break;
						}

						default:
						{
							uiWeight = Renderer::EFontWeight::Normal;
							break;
						}
					}
				}
				
				kProperty.Set(EWebPropertyUnit::FontWeight, uiWeight);
				break;
			}

			// Color
			case EWebPropertyUnit::Color:
			{
				uint32 uiColor = 0;
				if(_eValue != (uint32)-1)
				{
					uiColor = EWebPropertyColor::Value[_eValue];
				}

				kProperty.Set((EWebPropertyUnit::Type)_eUnit, uiColor);
				break;
			}

			//case KATANA_VALUE_PARSER_HEXCOLOR:
			//{
			//	uint32 uiColor = 0;
			//	int8 iValue;

			//	// Iterates each character per 2
			//	for(uint32 uiCharacter = 0; uiCharacter < 6;)
			//	{
			//		// Each hex value has 2 characters
			//		for(uint32 uiHexPart = 0; uiHexPart < 2; ++uiHexPart)
			//		{
			//			iValue = _pKatanaValue->string[uiCharacter++] - 'A';				// Check value minus 'A' (Assuming alsway upper character)
			//			iValue = iValue < 0 ? iValue += 17 : iValue +10;				// Less than 0 means [0-9] so add 17 ('A' - '0') value
			//																			// Greater/Equals than 0 means ['A'-'F'] so add hex value 'A' 10
			//			uiColor = (uiColor << 4) | iValue;								// for each character shift of 4bit and add iValue
			//				
			//		}
			//	}

			//	// Add alpha channel
			//	uiColor = (uiColor << 8) | 0xff;

			//	kProperty.Set(EWebPropertyUnit::Color, uiColor);
			//	break;
			//}

			//case KATANA_VALUE_PARSER_FUNCTION:
			//{
			//	uint32 uiColor = 0;

			//	// Get only the number in argument to create the color as int32
			//	KatanaArray* pKatanaArgumentArray = _pKatanaValue->function->args;
			//	const uint32 uiArgumentCount = pKatanaArgumentArray->length;
			//	for(uint32 uiArgument = 0; uiArgument < uiArgumentCount; ++uiArgument)
			//	{
			//		KatanaValue* pKatanaArgument = static_cast<KatanaValue*>(pKatanaArgumentArray->data[uiArgument]);
			//		if(pKatanaArgument->isInt)
			//		{
			//			uiColor = (uiColor << 8) | (uint8)pKatanaArgument->fValue;
			//		}
			//	}

			//	// Add alpha channel
			//	uiColor = (uiColor << 8) | 0xff;

			//	kProperty.Set(EWebPropertyUnit::Color, uiColor);
			//	break;
			//}

			default:
			{
				ASSERT(false, "Not supported");
				break;
			}
		}
	}

	//!	@brief		ParseSelector
	//!	@date		2015-12-29
	void WebStyle::ParseSelector(WebSelector* _pSelector, KatanaSelector* pKatanaSelector)
	{
		switch (pKatanaSelector->match)
		{
			case KatanaSelectorMatchTag:
			{
				_pSelector->SetTag(pKatanaSelector->tag->local);
				break;
			}

			case KatanaSelectorMatchId:
			{
				_pSelector->SetId(EWebSelector::Id, pKatanaSelector->data->value);
				break;
			}

			case KatanaSelectorMatchClass:
			{
				_pSelector->SetId(EWebSelector::Class, pKatanaSelector->data->value);
				break;
			}

			default:
			{
				ASSERT(false, "Not supported!");
				break;
			}
		}

		// SubInformation
		if(pKatanaSelector->tagHistory)
		{
			ParseSelector(_pSelector, pKatanaSelector->tagHistory);
		}
	}

	//!	@brief		ApplyOn
	//!	@date		2015-12-29
	void WebStyle::ApplyOn(WebElement* _pElement)
	{
		const uint32 uiStyleCount = m_vStyle.GetSize();
		for(uint32 uiStyle = 0; uiStyle < uiStyleCount; ++uiStyle)
		{
			WebElementStyle* pStyle = m_vStyle[uiStyle];
			pStyle->ApplyOn(_pElement);
		}
	}
}}