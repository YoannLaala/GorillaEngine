#ifndef _WEB_PAGE_HPP_
#define _WEB_PAGE_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>
#include <Renderer/Tree/QuadTree.hpp>

#include <Web/Document/WebDocument.hpp>

#include <gumbo-parser/src/gumbo.h>

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebBrowser;
	class WebElement;
	class WebComponentNode;
}}

namespace Gorilla { namespace Renderer
{
	class Texture2D;
	class CanvasSurface;
	class Node;
}}

/******************************************************************************
**	Class Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{	
	class WebPage : public WebDocument
	{
		friend class WebBrowser;
		friend class WebComponentNode;	// Special access to Tree

	public:
		bool			Open(const char* _szUrl);

		void			Update();

		inline WebElement* GetDOM() { return m_pDOM; }
		inline WebBrowser* GetBrowser() { return m_pBrowser; }
		inline Renderer::CanvasSurface* GetSurface() { return m_pSurface; }

		float32			GetScrollX() const { return m_vScroll.GetX(); }
		float32			GetScrollY() const { return m_vScroll.GetY(); }
		void			SetScroll(float32 _fScrollX, float32 _fScrollY);
		inline void		SetScrollX(float32 _fScroll) { SetScroll(_fScroll, m_vScroll.GetY()); }
		inline void		SetScrollY(float32 _fScroll) { SetScroll(m_vScroll.GetX(), _fScroll); }
		inline void		Scroll(float32 _fScrollX, float32 _fScrollY) { SetScroll(m_vScroll.GetX() + _fScrollX, m_vScroll.GetY() + _fScrollY); }
		inline void		ScrollX(float32 _fScroll) { SetScrollX(m_vScroll.GetX() + _fScroll); }
		inline void		ScrollY(float32 _fScroll) { SetScrollY(m_vScroll.GetY() + _fScroll); }

	protected:
		WebPage();
		~WebPage();

		void			Initialize(WebBrowser* _pBrowser, Renderer::Texture2D* _pTexture);
		void			Release();

	protected:
		inline Renderer::QuadTree*	GetTree		() { return m_pTree; }

		virtual WebElement* CreateCustomElement(const char* /*_szTagName*/) { return NULL; }

	private:
		virtual void	Parse(const char* _szBuffer, uint32 _uiSize = (uint32)-1) override;
		void			ParseNode(const GumboNode* _pGumboNode, WebElement* _pParent = NULL);
		void			ParseDocument(const GumboDocument* _pGumboDocument);
		void			ParseElement(const GumboElement* _pGumboElement, WebElement* _pParent);
		void			ParseElementAttribute(const GumboVector& _vGumboAttribute, WebElement* _pElement);
		void			ParseElementChild(const GumboVector& _vGumboChild, WebElement* _pParent);

		virtual void	ApplyOn(WebElement* _pElement) override;

	private:
		Vector<WebDocument*>		m_vDocument;
		Vector<Renderer::Node*>		m_vNode;
		WebBrowser*					m_pBrowser;
		Renderer::CanvasSurface*	m_pSurface;
		WebElement*					m_pDOM;
		Renderer::QuadTree*			m_pTree;

		Math::Vector2				m_vScroll;
	};
}}				

#endif