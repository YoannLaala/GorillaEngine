/******************************************************************************
**	Includes
******************************************************************************/
#include "WebDocument.hpp"

/******************************************************************************
**	Class Definition
******************************************************************************/
namespace Gorilla { namespace Web
{
	//!	@brief		Constructor
	//!	@date		2015-12-29
	WebDocument::WebDocument()
		: m_eState(EState::Loading)
	{
		// Nothing to do
	}

	//!	@brief		Destructor
	//!	@date		2015-12-29
	WebDocument::~WebDocument()
	{
		// Nothing to do
	}
}}