#ifndef _WEB_SCRIPT_HPP_
#define _WEB_SCRIPT_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>
#include <Web/Document/WebDocument.hpp>

/******************************************************************************
**	Class Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebScript : public WebDocument
	{
		friend class WebBrowser;

	public:
		virtual void Parse(const char* _szBuffer, uint32 _uiSize = (uint32)-1) override;

	protected:
		WebScript();
		~WebScript();

		virtual void		ApplyOn(WebElement* _pElement) override;
	};
}}
#endif