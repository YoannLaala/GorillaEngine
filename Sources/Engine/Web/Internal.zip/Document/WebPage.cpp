/******************************************************************************
**	Includes
******************************************************************************/
#include "WebPage.hpp"

#include <Core/Stream/FileReader.hpp>
#include <Web/Document/WebScript.hpp>
#include <Web/Document/WebStyle.hpp>

#include <Web/WebBrowser.hpp>
#include <Web/Element/WebElementImage.hpp>
#include <Web/Element/WebElementText.hpp>

#include <Web/Component/WebComponentNode.hpp>

#include <Renderer/Node.hpp>
#include <Renderer/RenderComponent.hpp>
#include <Renderer/Texture/Texture2D.hpp>
#include <Renderer/Canvas/CanvasContext.hpp>

/******************************************************************************
**	Class Definition
******************************************************************************/
namespace Gorilla { namespace Web
{
	//!	@brief		Constructor
	//!	@date		2015-12-29
	WebPage::WebPage()
		: m_pSurface(NULL)
		, m_pDOM(NULL)
		, m_pTree(NULL)
	{
		// Nothing to do
	}

	//!	@brief		Destructor
	//!	@date		2015-12-29
	WebPage::~WebPage()
	{
		// Nothing to do
	}

	//!	@brief		Initialize
	//!	@date		2015-12-29
	void WebPage::Initialize(WebBrowser* _pBrowser, Renderer::Texture2D* _pTexture)
	{
		m_pDOM = new WebElement();
		m_pTree = new Renderer::QuadTree();
		m_pBrowser = _pBrowser;
		m_pSurface = m_pBrowser->GetContext()->CreateSurface(_pTexture);
	}

	//!	@brief		Release
	//!	@date		2015-12-29
	void WebPage::Release()
	{
		m_pBrowser->GetContext()->DestroyResource(m_pSurface);
		m_pBrowser = NULL;
		SAFE_DELETE(m_pTree);
		SAFE_DELETE(m_pDOM);
	}

	//!	@brief		Open
	//!	@date		2015-12-05
	bool WebPage::Open(const char* _szUrl)
	{
		return m_pBrowser->Open(this, _szUrl);
	}

	//!	@brief		Parse
	//!	@date		2015-12-05
	void WebPage::Parse(const char* _szBuffer, uint32 /*_uiSize*/ /*= (uint32)-1*/)
	{
		GumboOutput* pGumbo = gumbo_parse(_szBuffer);
		ParseNode(pGumbo->document);
		gumbo_destroy_output(&kGumboDefaultOptions, pGumbo);
	}

	//!	@brief		GetTagName
	//!	@date		2015-12-05
	void GetTagName(GumboNode* _pGumboNode, String& sTagNameOut)
	{
		// Work around lack of proper name for document node
		if (_pGumboNode->type == GUMBO_NODE_DOCUMENT) 
		{
			sTagNameOut = "document";
		} 
		else 
		{
			sTagNameOut = gumbo_normalized_tagname(_pGumboNode->v.element.tag);
		}

		// Final check
		if (sTagNameOut.IsEmpty()) 
		{
			GumboStringPiece& sOriginalTagName = _pGumboNode->v.element.original_tag;
			if (sOriginalTagName.data) 
			{
				gumbo_tag_from_original_text(&sOriginalTagName);
				sTagNameOut.Set(sOriginalTagName.data, (uint32)sOriginalTagName.length);
			}
		}
	}

	//!	@brief		ParseNode
	//!	@date		2015-12-05
	void WebPage::ParseNode(const GumboNode* _pGumboNode, WebElement* _pParent /*= NULL*/)
	{
		switch(_pGumboNode->type)
		{
			case GUMBO_NODE_DOCUMENT:
			{
				ParseDocument(&_pGumboNode->v.document);
				break;
			}

			case GUMBO_NODE_ELEMENT:
			{
				ParseElement(&_pGumboNode->v.element, _pParent);
				break;
			}

			case GUMBO_NODE_TEXT:
			{
				// Information Tag
				switch(_pGumboNode->parent->v.element.tag)
				{
					case GUMBO_TAG_META:
					case GUMBO_TAG_HEAD:
					case GUMBO_TAG_TITLE:
					case GUMBO_TAG_BASE:
					{
						return;
						break;
					}
				}

				// Avoid empty text <body></body> generates \n\t
				const char* pEndTag = _pGumboNode->parent->v.element.original_end_tag.data;
				const char* pText = _pGumboNode->v.text.original_text.data;
				if(!pEndTag || pEndTag - pText < 0)
				{
					return;
				}

				WebProperty kProperty(EWebPropertyUnit::String, _pGumboNode->v.text.text);
				_pParent->SetProperty(EWebProperty::Content, &kProperty);
				break;
			}

			case GUMBO_NODE_CDATA:
			{
				break;
			}

			case GUMBO_NODE_COMMENT:
			{
				break;
			}

			case GUMBO_NODE_WHITESPACE:
			{
				break;
			}

			case GUMBO_NODE_TEMPLATE:
			{
				break;
			}
		}
	}

	//!	@brief		ParseDocument
	//!	@date		2015-12-05
	void WebPage::ParseDocument(const GumboDocument* _pGumboDocument)
	{
		ParseElementChild(_pGumboDocument->children, m_pDOM);
	}

	//!	@brief		ParseElement
	//!	@date		2015-12-05
	void WebPage::ParseElement(const GumboElement* _pGumboElement, WebElement* _pParent)
	{
		static uint32 aTagId[GUMBO_TAG_LAST] = 
		{
			EWebElement::Id[EWebElement::Html],
			EWebElement::Id[EWebElement::Head],
			EWebElement::Id[EWebElement::Title],
			EWebElement::Id[EWebElement::Base],
			EWebElement::Id[EWebElement::Link],
			EWebElement::Id[EWebElement::Meta],
			EWebElement::Id[EWebElement::Style],
			EWebElement::Id[EWebElement::Script],
			EWebElement::Id[EWebElement::Noscript],
			Identifier::Compute("template"),
			EWebElement::Id[EWebElement::Body],
			EWebElement::Id[EWebElement::Article],
			EWebElement::Id[EWebElement::Section],
			EWebElement::Id[EWebElement::Nav],
			EWebElement::Id[EWebElement::Aside],
			EWebElement::Id[EWebElement::H1],
			EWebElement::Id[EWebElement::H2],
			EWebElement::Id[EWebElement::H3],
			EWebElement::Id[EWebElement::H4],
			EWebElement::Id[EWebElement::H5],
			EWebElement::Id[EWebElement::H6],
			Identifier::Compute("hgroup"),
			EWebElement::Id[EWebElement::Header],
			EWebElement::Id[EWebElement::Footer],
			EWebElement::Id[EWebElement::Address],
			EWebElement::Id[EWebElement::P],
			EWebElement::Id[EWebElement::Hr],
			EWebElement::Id[EWebElement::Pre],
			EWebElement::Id[EWebElement::Blockquote],
			EWebElement::Id[EWebElement::Ol],
			EWebElement::Id[EWebElement::Ul],
			EWebElement::Id[EWebElement::Li],
			EWebElement::Id[EWebElement::Dl],
			EWebElement::Id[EWebElement::Dt],
			EWebElement::Id[EWebElement::Dd],
			EWebElement::Id[EWebElement::Figure],
			EWebElement::Id[EWebElement::Figcaption],
			EWebElement::Id[EWebElement::Main],
			EWebElement::Id[EWebElement::Div],
			EWebElement::Id[EWebElement::A],
			EWebElement::Id[EWebElement::Em],
			EWebElement::Id[EWebElement::Strong],
			EWebElement::Id[EWebElement::Small],
			EWebElement::Id[EWebElement::S],
			EWebElement::Id[EWebElement::Cite],
			EWebElement::Id[EWebElement::Q],
			EWebElement::Id[EWebElement::Dfn],
			EWebElement::Id[EWebElement::Abbr],
			Identifier::Compute("data"),
			EWebElement::Id[EWebElement::Time],
			EWebElement::Id[EWebElement::Code],
			EWebElement::Id[EWebElement::Var],
			EWebElement::Id[EWebElement::Samp],
			EWebElement::Id[EWebElement::Kbd],
			EWebElement::Id[EWebElement::Sub],
			EWebElement::Id[EWebElement::Sup],
			EWebElement::Id[EWebElement::I],
			EWebElement::Id[EWebElement::B],
			EWebElement::Id[EWebElement::U],
			EWebElement::Id[EWebElement::Mark],
			EWebElement::Id[EWebElement::Ruby],
			EWebElement::Id[EWebElement::Rt],
			EWebElement::Id[EWebElement::Rp],
			EWebElement::Id[EWebElement::Bdi],
			EWebElement::Id[EWebElement::Bdo],
			EWebElement::Id[EWebElement::Span],
			EWebElement::Id[EWebElement::Br],
			EWebElement::Id[EWebElement::Wbr],
			EWebElement::Id[EWebElement::Ins],
			EWebElement::Id[EWebElement::Del],
			Identifier::Compute("image"),
			EWebElement::Id[EWebElement::Img],
			EWebElement::Id[EWebElement::Iframe],
			EWebElement::Id[EWebElement::Embed],
			EWebElement::Id[EWebElement::Object],
			EWebElement::Id[EWebElement::Param],
			EWebElement::Id[EWebElement::Video],
			EWebElement::Id[EWebElement::Audio],
			EWebElement::Id[EWebElement::Source],
			EWebElement::Id[EWebElement::Track],
			EWebElement::Id[EWebElement::Canvas],
			EWebElement::Id[EWebElement::Map],
			EWebElement::Id[EWebElement::Area],
			Identifier::Compute("math"),
			Identifier::Compute("mi"),
			Identifier::Compute("mo"),
			Identifier::Compute("mn"),
			Identifier::Compute("ms"),
			Identifier::Compute("mtext"),
			Identifier::Compute("mglyph"),
			Identifier::Compute("malignmark"),
			Identifier::Compute("annotation_xml"),
			Identifier::Compute("svg"),
			Identifier::Compute("foreignobject"),
			Identifier::Compute("desc"),
			EWebElement::Id[EWebElement::Table],
			EWebElement::Id[EWebElement::Caption],
			EWebElement::Id[EWebElement::Colgroup],
			EWebElement::Id[EWebElement::Col],
			EWebElement::Id[EWebElement::Tbody],
			EWebElement::Id[EWebElement::Thead],
			EWebElement::Id[EWebElement::Tfoot],
			EWebElement::Id[EWebElement::Tr],
			EWebElement::Id[EWebElement::Td],
			EWebElement::Id[EWebElement::Th],
			EWebElement::Id[EWebElement::Form],
			EWebElement::Id[EWebElement::Fieldset],
			EWebElement::Id[EWebElement::Legend],
			EWebElement::Id[EWebElement::Label],
			EWebElement::Id[EWebElement::Input],
			EWebElement::Id[EWebElement::Button],
			EWebElement::Id[EWebElement::Select],
			EWebElement::Id[EWebElement::Datalist],
			EWebElement::Id[EWebElement::Optgroup],
			EWebElement::Id[EWebElement::Option],
			EWebElement::Id[EWebElement::Textarea],
			EWebElement::Id[EWebElement::Keygen],
			EWebElement::Id[EWebElement::Output],
			EWebElement::Id[EWebElement::Progress],
			EWebElement::Id[EWebElement::Meter],
			EWebElement::Id[EWebElement::Details],
			EWebElement::Id[EWebElement::Summary],
			EWebElement::Id[EWebElement::Menu],
			EWebElement::Id[EWebElement::Menuitem],
			Identifier::Compute("applet"),
			Identifier::Compute("acronym"),
			Identifier::Compute("bgsound"),
			Identifier::Compute("dir"),
			Identifier::Compute("frame"),
			Identifier::Compute("frameset"),
			Identifier::Compute("noframes"),
			Identifier::Compute("isindex"),
			Identifier::Compute("listing"),
			Identifier::Compute("xmp"),
			Identifier::Compute("nextid"),
			Identifier::Compute("noembed"),
			Identifier::Compute("plaintext"),
			Identifier::Compute("rb"),
			Identifier::Compute("strike"),
			Identifier::Compute("basefont"),
			Identifier::Compute("big"),
			Identifier::Compute("blink"),
			Identifier::Compute("center"),
			Identifier::Compute("font"),
			Identifier::Compute("marquee"),
			Identifier::Compute("multicol"),
			Identifier::Compute("nobr"),
			Identifier::Compute("spacer"),
			Identifier::Compute("tt"),
			Identifier::Compute("rtc"),
			(uint32)-1,
		};

		uint32 uiTagId = aTagId[(uint8)_pGumboElement->tag];
		WebElement* pElement = NULL;
		switch(_pGumboElement->tag)
		{
			// Create a custom element
			case GUMBO_TAG_UNKNOWN:
			{
				pElement = CreateCustomElement(_pGumboElement->original_tag.data);
				if(pElement)
				{
					uiTagId = Identifier::Compute(_pGumboElement->original_tag.data);
					_pParent->AddElement(pElement);
				}
				break;
			}

			// Information Tag
			case GUMBO_TAG_META:
			case GUMBO_TAG_HEAD:
			case GUMBO_TAG_TITLE:
			case GUMBO_TAG_BASE:
			case GUMBO_TAG_NOSCRIPT:	// Avoided tag
			{
				pElement = _pParent->AddElement<WebElement>();
				break;
			}

			case GUMBO_TAG_LINK:
			{
				//pElement = _pParent->AddElement<WebElementLink>();

				// Track StyleSheet
				/*GumboAttribute* pGumboAttribute = gumbo_get_attribute(&_pGumboElement->attributes, "rel");
				if(pGumboAttribute && _strcmpi(pGumboAttribute->value, "stylesheet") == 0)
				{
					pGumboAttribute = gumbo_get_attribute(&_pGumboElement->attributes, "href");
					if(pGumboAttribute)
					{
						AddDocument<WebStyle>(pGumboAttribute->value);
					}
				}*/

				break;
			}

			case GUMBO_TAG_STYLE:
			{
				//pElement = _pParent->AddElement<WebElementStyle>();

				//// Build up result for each child, recursively if need be
				//const uint32 uiChildCount = _pGumboElement->children.length;
				//if(uiChildCount == 1)
				//{
				//	const GumboNode* pChildNode = static_cast<const GumboNode*>(_pGumboElement->children.data[0]);
				//	
				//	// Create a WebStyle for this 
				//	WebStyle* pStyle = AddDocument<WebStyle>();
				//	pStyle->Parse(pChildNode->v.text.text);
				//}

				return; // Nothing to do after that
			}

			case GUMBO_TAG_SCRIPT:
			{
				//pElement = _pParent->AddElement<WebElementScript>();

				//// Track Script
				//GumboAttribute* pGumboAttribute = gumbo_get_attribute(&_pGumboElement->attributes, "src");
				//if(pGumboAttribute)
				//{
				//	AddDocument<WebScript>(pGumboAttribute->value);
				//}

				break;
			}

			// Main Node -it will always be present
			case GUMBO_TAG_HTML:
			{
				pElement = m_pDOM;
				pElement->GetOrCreateComponent<WebComponentNode>();
				break;
			}

			// Empty Node	
			case GUMBO_TAG_BODY:
			case GUMBO_TAG_LI:
			case GUMBO_TAG_UL:
			case GUMBO_TAG_OL:
			case GUMBO_TAG_TABLE:
			case GUMBO_TAG_CAPTION:
			case GUMBO_TAG_THEAD:
			case GUMBO_TAG_TBODY:
			case GUMBO_TAG_TR:
			case GUMBO_TAG_TH:
			case GUMBO_TAG_TD:
			case GUMBO_TAG_TFOOT:
			case GUMBO_TAG_BUTTON:
			case GUMBO_TAG_INPUT:
			case GUMBO_TAG_A:
			case GUMBO_TAG_HEADER:
			case GUMBO_TAG_NAV:
			case GUMBO_TAG_MAIN:
			case GUMBO_TAG_SECTION:
			case GUMBO_TAG_ARTICLE:
			case GUMBO_TAG_BLOCKQUOTE:
			case GUMBO_TAG_CITE:
			case GUMBO_TAG_FOOTER:
			case GUMBO_TAG_DL:
			case GUMBO_TAG_DT:
			case GUMBO_TAG_DD:
			case GUMBO_TAG_DIV:
			case GUMBO_TAG_SPAN:
			case GUMBO_TAG_P:
			case GUMBO_TAG_HR:
			case GUMBO_TAG_H1:
			case GUMBO_TAG_H2:
			case GUMBO_TAG_H3:
			case GUMBO_TAG_H4:
			case GUMBO_TAG_H5:
			case GUMBO_TAG_H6:
			case GUMBO_TAG_STRONG:
			case GUMBO_TAG_KBD:
			case GUMBO_TAG_CODE:
			case GUMBO_TAG_SAMP:
			case GUMBO_TAG_PRE:
			case GUMBO_TAG_EM:
			case GUMBO_TAG_B:
			case GUMBO_TAG_I:
			case GUMBO_TAG_DEL:
			case GUMBO_TAG_INS:
			case GUMBO_TAG_S:
			case GUMBO_TAG_SMALL:
			case GUMBO_TAG_SUB:
			case GUMBO_TAG_U:
			case GUMBO_TAG_SUP:
			case GUMBO_TAG_Q:
			case GUMBO_TAG_ABBR:
			case GUMBO_TAG_DFN:
			case GUMBO_TAG_MARK:
			case GUMBO_TAG_VAR:
			case GUMBO_TAG_TIME:
			case GUMBO_TAG_FIGURE:
			case GUMBO_TAG_FIGCAPTION:
			case GUMBO_TAG_AUDIO:
			case GUMBO_TAG_VIDEO:
			case GUMBO_TAG_CANVAS:
			case GUMBO_TAG_METER:
			case GUMBO_TAG_PROGRESS:
			case GUMBO_TAG_SVG:
			case GUMBO_TAG_IFRAME:
			case GUMBO_TAG_FORM:
			case GUMBO_TAG_FIELDSET:
			case GUMBO_TAG_LEGEND:
			case GUMBO_TAG_LABEL:
			case GUMBO_TAG_SELECT:
			case GUMBO_TAG_TEXTAREA:
			case GUMBO_TAG_IMAGE:
			case GUMBO_TAG_IMG:
			{
				pElement = _pParent->AddElement<WebElement>();
				pElement->GetOrCreateComponent<WebComponentNode>();
				break;
			}
			
			/*case GUMBO_TAG_OPTGROUP:
			{
				if(_pParent->GetTagId() == EWebElement::Select)
				{
					//WebComponentComboBox* pCpnComboBox = pElement->GetOrCreateComponent<WebComponentComboBox>();
				}
				
				break;
			}

			case GUMBO_TAG_OPTION:
			{
				if(_pParent->GetTagId() == EWebElement::Optgroup)
				{
					//WebComponentComboBox* pCpnComboBox = pElement->GetOrCreateComponent<WebComponentComboBox>();
				}
				
				break;
			}*/
			
			default:
			{
				ASSERT(false, "Not supported!");
			}
		}

		// Parse attributes
		if(pElement)
		{
			pElement->SetPage(this);
			pElement->SetTagId(uiTagId);

			WebComponentNode* pCpnNode = pElement->GetComponent<WebComponentNode>();
			if(pCpnNode)
			{
				WebProperty kProperty(EWebPropertyUnit::Percentage, 100.0f);
				pElement->SetProperty(EWebProperty::Width, &kProperty);
				pElement->SetProperty(EWebProperty::Height, &kProperty);
			}

			ParseElementAttribute(_pGumboElement->attributes, pElement);
		}
		// If no element was created, attach child to Root
		else
		{
			pElement = m_pDOM;
		}

		/*WebProperty kProperty(EWebPropertyUnit::Percentage, 100.0f);
		pElement->SetProperty(EWebProperty::Width, &kProperty);
		pElement->SetProperty(EWebProperty::Height, &kProperty);*/

		// Parse all child
		ParseElementChild(_pGumboElement->children, pElement);	
	}

	//!	@brief		ParseElementAttribute
	//!	@date		2015-12-05
	void WebPage::ParseElementAttribute(const GumboVector& _vGumboAttribute, WebElement* _pElement)
	{
		// Build up result for each child, recursively if need be
		const uint32 uiChildCount = _vGumboAttribute.length;
		for (uint32 uiChild = 0; uiChild < uiChildCount; ++uiChild) 
		{
			const GumboAttribute* pGumboAttribute = static_cast<const GumboAttribute*>(_vGumboAttribute.data[uiChild]);
			_pElement->AddAttribute(pGumboAttribute->name, pGumboAttribute->value);
		}
	}

	//!	@brief		ParseElementChild
	//!	@date		2015-12-05
	void WebPage::ParseElementChild(const GumboVector& _vGumboChild, WebElement* _pParent)
	{
		// Build up result for each child, recursively if need be
		const uint32 uiChildCount = _vGumboChild.length;
		for (uint32 uiChild = 0; uiChild < uiChildCount; ++uiChild) 
		{
			const GumboNode* pChildNode = static_cast<const GumboNode*>(_vGumboChild.data[uiChild]);
			ParseNode(pChildNode, _pParent);
		}
	}

	//!	@brief		SetScroll
	//!	@date		2016-03-19
	void WebPage::SetScroll(float32 _fScrollX, float32 _fScrollY)
	{ 
		m_vScroll.Set(_fScrollX, _fScrollY);
		//m_pRoot->SetScroll(_fScrollX, _fScrollY);
	}

	//!	@brief		Update
	//!	@date		2015-12-29
	void WebPage::Update()
	{
		m_pDOM->Update();
		if(!m_pDOM->HasFlag(WebElement::EFlag::Changed))
		{
			return;
		}

		Renderer::CanvasContext* pContext = m_pBrowser->GetContext();

		// Update all WebElement 
		if(m_pDOM->HasFlag(WebElement::EFlag::LayoutChanged))
		{
			m_pDOM->OnChanged(pContext, m_pSurface);

			// Find visible nodes
			m_vNode.Clear();
			Math::Vector2 vSize((float32)m_pSurface->GetWidth(), (float32)m_pSurface->GetHeight());
			m_pTree->FindVisible((float32*)&m_vScroll, (float32*)&vSize, m_vNode);
		}

		// Push Render command for each render component of visible nodes
		Math::Matrix33 mTransform;
		const uint32 uiNodecount = m_vNode.GetSize();
		for(uint32 uiNode = 0; uiNode < uiNodecount; ++uiNode)
		{
			Renderer::Node* pNode = m_vNode[uiNode];

			const Math::Vector3& vPosition = pNode->GetPosition();
			//const Math::Quaternion& qOrientation = pNode->GetOrientation();
			const Math::Vector3& vScale = pNode->GetScale();

			mTransform.SetTranslation(vPosition.GetX(), vPosition.GetY());
			mTransform.SetScale(vScale.GetX(), vScale.GetY());

			const Vector<Renderer::RenderComponent*>& vRenderComponent = pNode->GetVecRenderComponent();
			const uint32 uiComponentCount = vRenderComponent.GetSize();
			for(uint32 uiComponent = 0; uiComponent < uiComponentCount; ++uiComponent)
			{
				// Push the command only if the component is activated
				Renderer::RenderComponent* pRenderComponent = vRenderComponent[uiComponent];
				pRenderComponent->PushCommand(pContext, m_pSurface, mTransform);
			}
		}
	}

	//!	@brief		ApplyOn
	//!	@date		2015-12-29
	void WebPage::ApplyOn(WebElement* /*_pElement*/)
	{
	
	}
}}
