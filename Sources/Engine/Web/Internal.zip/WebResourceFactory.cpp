/******************************************************************************
**	Includes
******************************************************************************/
#include "WebResourceFactory.hpp"

#include <Core/String/String16.hpp>
#include <Core/String/StringHelper.hpp>

#include <Web/Element/WebElement.hpp>

#include <Renderer/Canvas/CanvasContext.hpp>
#include <Renderer/Canvas/Resource/Texture/CanvasSurface.hpp>

/******************************************************************************
**	Class Definition
******************************************************************************/
namespace Gorilla { namespace Web
{
	//!	@brief		GetBrush
	//!	@date		2015-12-29
	Renderer::CanvasBrush* WebResourceFactory::GetBrush(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, uint32 _uiColor)
	{
		// Search Brush or create it if needed
		Renderer::CanvasBrush* pBrush = _pContext->GetBrush(_uiColor);
		if(!pBrush)
		{
			pBrush = _pContext->CreateBrush(_pSurface, _uiColor);
		}

		return pBrush;
	}

	//!	@brief		GetStyle
	//!	@date		2015-12-29
	Renderer::CanvasStyle* WebResourceFactory::GetStyle(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, uint32 _eLine)
	{
		// Search Brush or create it if needed
		Renderer::ELineStyle::Type eLineStyle = (Renderer::ELineStyle::Type)_eLine;
		Renderer::CanvasStyle* pStyle = _pContext->GetStyle(eLineStyle);
		if(!pStyle)
		{
			pStyle = _pContext->CreateStyle(_pSurface, eLineStyle);
		}

		return pStyle;
	}

	//!	@brief		GetRectangle
	//!	@date		2015-12-29
	Renderer::CanvasGeometry* WebResourceFactory::GetRectangle(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, float32 _fWidth, float32 _fHeight, float32 _fRadiusX /*= 0.0f*/, float32 _fRadiusY /*= 0.0f*/)
	{
		// Search Rectangle or create it if needed
		Renderer::CanvasGeometry* pRectangle = _pContext->GetRectangle("");
		if(!pRectangle)
		{
			pRectangle = _pContext->CreateRectangle("", _pSurface, _fWidth, _fHeight, _fRadiusX, _fRadiusY);
		}

		return pRectangle;
	}

	//!	@brief		GetElipse
	//!	@date		2015-12-29
	Renderer::CanvasGeometry* WebResourceFactory::GetElipse(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, float32 _fRadiusX, float32 _fRadiusY)
	{
		// Search Rectangle or create it if needed
		Renderer::CanvasGeometry* pElipse = _pContext->GetElipse("");
		if(!pElipse)
		{
			pElipse = _pContext->CreateElipse("", _pSurface, _fRadiusX, _fRadiusY);
		}

		return pElipse;
	}

	//!	@brief		GetFont
	//!	@date		2015-12-29
	Renderer::CanvasFont* WebResourceFactory::GetFont(Renderer::CanvasContext* _pContext, const char* _szFamily, float32 _fSize, uint32 _uiWeight, uint32 _eStyle)
	{
		// Build FontId
		String sFontId(_szFamily);
		sFontId.Append((uint32)_fSize).Append(_uiWeight).Append((uint32)_eStyle);
			
		// Search font or create it if needed
		Renderer::CanvasFont* pFont = _pContext->GetFont(sFontId.GetBuffer());
		if(!pFont)
		{
			// Build family Name in utf16
			String16 sFamily;
			StringHelper::ToString16(_szFamily, sFamily);

			pFont = _pContext->CreateFont(sFontId.GetBuffer(), sFamily.GetBuffer(), _fSize, _uiWeight, (Renderer::EFontStyle::Type)_eStyle);
		}

		return pFont;
	}

	//!	@brief		GetText
	//!	@date		2015-12-29
	Renderer::CanvasText* WebResourceFactory::GetText(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, const char* _szText, Renderer::CanvasFont* _pFont)
	{
		// Build TextId
		String sTextId(_szText);
		sTextId.Append('_').Append((uint32)_pFont);

		// Search text or create it if needed
		Renderer::CanvasText* pText =_pContext->GetText(sTextId.GetBuffer());
		if(!pText)
		{
			// Build Text in String16
			String16 sText16;
			StringHelper::ToString16(_szText, sText16);

			// Create Text
			pText = _pContext->CreateText(sTextId.GetBuffer(), sText16.GetBuffer(), (float32)_pSurface->GetWidth(), (float32)_pSurface->GetHeight(), _pFont);
		}

		return pText;
	}
}}
