#ifndef _WEB_REQUEST_HPP_
#define _WEB_REQUEST_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebBrowser;
	class WebPage;
	class WebDocument;
}}

/******************************************************************************
**	Class Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebRequest
	{
		friend class WebBrowser;

	public:
		WebRequest();	
		~WebRequest();

		void Initialize(WebDocument* _pDocument, const char* _szUrl, WebPage* _pSource /*= NULL*/);		
		
		inline const String&	GetUrl() const { return m_sUrl; }
		inline WebPage*			GetSource() { return m_pSource; }
		inline WebDocument*		GetDocument() { return m_pDocument; }
		inline const char*		GetBuffer() const { return m_szBuffer; }
		inline uint32			GetBufferSize() const { return m_uiBufferSize; }

	private:
		inline void SetBuffer(const char* _szBuffer, uint32 _uiSize) { m_szBuffer = _szBuffer; m_uiBufferSize = _uiSize; }

	private:
		String					m_sUrl;
		WebPage*				m_pSource;
		WebDocument*			m_pDocument;
		const char*				m_szBuffer;
		uint32					m_uiBufferSize;
	};
}}		

#endif