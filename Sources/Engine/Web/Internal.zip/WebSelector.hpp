#ifndef _WEB_SELECTOR_HPP_
#define _WEB_SELECTOR_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>

/******************************************************************************
**	Class Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	namespace EWebSelector
	{
		enum Type : uint8
		{
			TagInherited = 0,
			Tag,
			ClassInherited,
			IdInherited,
			ElementInherited,
			Class,
			Id,
			Element,
		};
	};

	namespace EWebModifier
	{
		enum Type : uint8
		{
			Before = 0,
			After,

			Count,
			Default,
		};

		static const char* Name[EWebModifier::Count] = 
		{
			"before",
			"after",
		};

		EWebModifier::Type Find(const char* _szModifier)
		{
			EWebModifier::Type eModifier = EWebModifier::Default;
			for(uint8 uiModifier = 0; uiModifier < EWebModifier::Count; ++uiModifier)
			{
				if(strcmp(EWebModifier::Name[uiModifier], _szModifier) == 0)
				{
					eModifier = (EWebModifier::Type)uiModifier;
					break;
				}
			}

			return eModifier;
		}
	};

	class WebSelector
	{
	public:
		WebSelector();
		~WebSelector();

		inline bool HasTag() { return m_uiTagId != (uint32)-1; }
		inline uint32 GetTagId() const { return m_uiTagId; }
		inline void SetTag(const char* _szTagName) { m_uiTagId = Identifier::Compute(_szTagName); }

		inline bool HasId() const { return m_eSelector > EWebSelector::ElementInherited; }
		inline EWebSelector::Type GetIdType() const { return m_eSelector; }
		inline uint32 GetId() const { return m_uiId; }

		inline void SetId(EWebSelector::Type _eSeclector, const char* _szIdName) { m_eSelector = _eSeclector; m_uiId = Identifier::Compute(_szIdName); }
		inline void SetModifier(const char* _szModifierName) { m_eModifier = EWebModifier::Find(_szModifierName); }

	private:
		uint32 m_uiTagId;
		uint32 m_uiId;
		EWebSelector::Type m_eSelector;
		EWebModifier::Type m_eModifier;
	};
}}
#endif