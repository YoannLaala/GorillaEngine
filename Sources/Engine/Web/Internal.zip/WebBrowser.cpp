/******************************************************************************
**	Includes
******************************************************************************/
#include "WebBrowser.hpp"

#include <Core/File/FileManager.hpp>
#include <Core/Stream/FileReader.hpp>
#include <Core/Process/Thread.hpp>

#include <Web/Document/WebPage.hpp>
#include <Web/Document/WebStyle.hpp>
#include <Renderer/Renderer.hpp>
#include <Renderer/Canvas/CanvasRenderer.hpp>

#pragma warning(push)
#pragma warning(disable : 4512)
#pragma warning(disable : 4100)
#pragma warning(disable : 4127)
#include <v8/include/libplatform/libplatform.h>
#include <v8/include/v8.h>
#pragma warning(pop)

#include <curl/include/curl/curl.h>

/******************************************************************************
**	Define
******************************************************************************/
# define WEB_DOCUMENY_STYLE_CORE_INDEX 0

/******************************************************************************
**	Class Definition
******************************************************************************/
namespace Gorilla { namespace Web
{
	class V8ArrayBufferAllocator : public v8::ArrayBuffer::Allocator 
	{
	public:
		virtual void* Allocate(size_t length) override { return AllocateUninitialized(length); }
		virtual void* AllocateUninitialized(size_t length) override { return Memory::Allocate(length); }
		virtual void Free(void* data, size_t) override { Memory::Deallocate(data); }
	};

	//!	@brief		Constructor
	//!	@date		2015-12-29
	WebBrowser::WebBrowser(Renderer::Renderer* _pRenderer /*= NULL*/)
		: m_pRenderer(NULL)
		, m_pContext(NULL)
		, m_pPlatform(NULL)
		, m_pIsolate(NULL)
		, m_bIsRendererInternal(false)
		, m_bIsRunning(false)
	{		
		// Initialize v8
		v8::V8::InitializeICU();
		m_pPlatform = v8::platform::CreateDefaultPlatform();
		v8::V8::InitializePlatform(m_pPlatform);
		v8::V8::Initialize();

		// Create the virtual Machine
		v8::Isolate::CreateParams kParameters;
		V8ArrayBufferAllocator kV8ArrayAllocator;
		kParameters.array_buffer_allocator = &kV8ArrayAllocator;
		m_pIsolate = v8::Isolate::New(kParameters);
		m_pIsolate->Enter();

		// Initialize Curl
		curl_global_init(CURL_GLOBAL_ALL);
		Thread::Create("WebRequestThread", &RequestThreadEntry, this, Thread::EPriority::Low);
		m_bIsRunning = true;

		// Renderer
		m_pRenderer = _pRenderer;
		if(!m_pRenderer)
		{
			m_pRenderer = new Renderer::Renderer();
			if(!m_pRenderer->Initialize())
			{
				ASSERT(false, "Renderer Initialization failed");
			}
			m_bIsRendererInternal = true;
		}

		// Create a new context for this browser
		m_pContext = m_pRenderer->GetCanvasRenderer()->AddContext();

		// Generate Core CSS file path
		String sCoreCSSFilePath;
		FileManager::GetDirectory(sCoreCSSFilePath);
		sCoreCSSFilePath.Append("Config\\Web\\css\\Core.css");

		// Load Core CSS
		if(!Open<WebStyle>(sCoreCSSFilePath.GetBuffer()))
		{
			ASSERT(false, "[WebBrowser] Failed to read Core CSS file");
		}
	}

	//!	@brief		Destructor
	//!	@date		2015-12-29
	WebBrowser::~WebBrowser()
	{
		m_bIsRunning = false;

		// Clean renderer if allocated internaly
		if(m_bIsRendererInternal)
		{
			SAFE_RELEASE_AND_DELETE(m_pRenderer);
		}

		// Clean curl
		curl_global_cleanup();

		// Clean v8
		m_pIsolate->Exit();
		m_pIsolate->Dispose();
		v8::V8::Dispose();
		v8::V8::ShutdownPlatform();
		SAFE_DELETE(m_pPlatform);
	}

	//!	@brief		Open
	//!	@date		2016-01-30
	WebPage* WebBrowser::Open(const char* _szUrl, Renderer::Texture2D* _pTexture /*= NULL*/)
	{
		WebPage* pPage = Open(_pTexture);
		pPage->Open(_szUrl);

		// Apply Core CSS
		WebElement* pElement = pPage->GetDOM();
		m_vDocument[WEB_DOCUMENY_STYLE_CORE_INDEX]->ApplyOn(pElement);		
		
		return pPage;
	}

	//!	@brief		Open
	//!	@date		2016-01-30
	WebPage* WebBrowser::Open(const char* _szUrl, uint32 _uiWidth, uint32 _uiHeight)
	{
		WebPage* pPage = Open(_uiWidth, _uiHeight);
		pPage->Open(_szUrl);

		// Apply Core CSS
		WebElement* pElement = pPage->GetDOM();
		m_vDocument[WEB_DOCUMENY_STYLE_CORE_INDEX]->ApplyOn(pElement);		

		return pPage;
	}

	//!	@brief		Open
	//!	@date		2016-01-30
	WebPage* WebBrowser::Open(uint32 _uiWidth, uint32 _uiHeight)
	{
		Renderer::Texture2D* pTexture = m_pRenderer->CreateTexture2D(_uiWidth, _uiHeight, 1, Renderer::EFormat::R8G8B8A8_UNORM, Renderer::EBind::ShaderResource);
		return Open(pTexture);
	}

	//!	@brief		Open
	//!	@date		2015-12-29
	WebPage* WebBrowser::Open(Renderer::Texture2D* _pTexture /*= NULL*/)
	{
		// Create Texture if needed
		if(!_pTexture)
		{
			_pTexture = m_pRenderer->CreateTexture2D(1280, 720, 1, Renderer::EFormat::R8G8B8A8_UNORM, Renderer::EBind::ShaderResource);
			m_vTexture.Add(_pTexture);
		}

		// Create WebPage
		WebPage* pWebPage = Open<WebPage>();
		pWebPage->Initialize(this, _pTexture);
		
		return pWebPage;
	}

	//!	@brief		Open
	//!	@date		2016-01-30
	bool WebBrowser::Open(WebDocument* _pDocument, const char* _szUrl, WebPage* _pSource /*= NULL*/)
	{
		// Check if this an web request
		if(strncmp(_szUrl, "http://", 7) == 0)
		{
			PushRequest(_pDocument, _szUrl, _pSource);
			return true;
		}

		// Open local file
		FileReader kFileReader;
		if(!kFileReader.Open(_szUrl))
		{
			return false;
		}

		// Copy it to a buffer
		uint32 uiSize = kFileReader.GetSize();
		char* pBuffer = new char[uiSize];
		kFileReader.Read(pBuffer, uiSize);
		kFileReader.Close();

		// Parse this buffer	
		Parse(_pDocument, pBuffer, uiSize, _pSource);
		SAFE_DELETE(pBuffer);

		return true;
	}

	//!	@brief		Parse
	//!	@date		2016-01-30
	void WebBrowser::Parse(WebDocument* _pDocument, const char* _szBuffer, uint32 _uiSize, WebPage* _pSource /*= NULL*/)
	{	
		_pDocument->Parse(_szBuffer, _uiSize);
		if(_pSource)
		{
			WebElement* pElement = _pSource->GetDOM();
			_pDocument->ApplyOn(pElement);
		}
	}

	//!	@brief		Close
	//!	@date		2015-12-29
	void WebBrowser::Close(WebPage* _pPage)
	{
		m_vDocument.Remove(_pPage);
		SAFE_RELEASE_AND_DELETE(_pPage);
	}

	//!	@brief		OnPushRequest
	//!	@date		2015-11-21
	void WebBrowser::PushRequest(WebDocument* _pDocument, const char* _szUrl, WebPage* _pSource /*= NULL*/)
	{
		m_kMutexRequest.Lock();
		WebRequest& kRequest = m_vRequest.Add();
		kRequest.Initialize(_pDocument, _szUrl, _pSource);
		m_kMutexRequest.Unlock();
		m_kConditionRequest.Signal();
	}

	//!	@brief		RequestThreadEntry
	//!	@date		2015-11-21
	void WebBrowser::RequestThreadEntry(void* _pData)
	{
		WebBrowser* pWebBrowser = static_cast<WebBrowser*>(_pData);
		pWebBrowser->m_pIsolate->Enter();

		while(pWebBrowser->m_bIsRunning)
		{
			pWebBrowser->RequestLoop();
		}

		pWebBrowser->m_pIsolate->Exit();		
	}

	//!	@brief		RequestLoop
	//!	@date		2015-11-21
	void WebBrowser::RequestLoop()
	{
		static Vector<WebRequest> vRequestCopy;

		// Check if we need to wait
		if(m_vRequest.IsEmpty())
		{
			m_kConditionRequest.Wait(m_kMutexRequest);
		}

		// Copy in all request needed
		m_kMutexRequest.Lock();
		vRequestCopy.Add(m_vRequest);
		m_vRequest.Clear();
		m_kMutexRequest.Unlock();

		// Initialize CurlMilti
		CURLM* pCurlMulti = curl_multi_init();

		// Handle request asset
		const uint32 uiRequestCount = vRequestCopy.GetSize();
		for (uint32 uiRequest = 0; uiRequest < uiRequestCount; ++uiRequest)
		{
			WebRequest& kRequest = vRequestCopy[uiRequest];

			LOG_PRINT("[WebBrowser] Request '%s' ", kRequest.GetUrl().GetBuffer());

			// Prepare a request for Curl
			CURL* pCurlRequest = curl_easy_init();
			curl_easy_setopt(pCurlRequest, CURLOPT_WRITEFUNCTION, HandleRequestResult);
			curl_easy_setopt(pCurlRequest, CURLOPT_WRITEDATA, &kRequest);
			curl_easy_setopt(pCurlRequest, CURLOPT_HEADER, 0L);
			curl_easy_setopt(pCurlRequest, CURLOPT_URL, kRequest.GetUrl().GetBuffer());
			curl_easy_setopt(pCurlRequest, CURLOPT_PRIVATE, kRequest.GetUrl().GetBuffer());
			curl_easy_setopt(pCurlRequest, CURLOPT_VERBOSE, 0L);
			
			curl_multi_add_handle(pCurlMulti, pCurlRequest);
		}

		// Wait for all request completed
		int32 iRequestLeft = -1;
		do
		{	
			// Execute Request
			curl_multi_perform(pCurlMulti, &iRequestLeft);

			int32 iCurlMultiWaitResult = 0;
			CURLMcode EResult = curl_multi_wait(pCurlMulti, NULL, 0, 15000, &iCurlMultiWaitResult);
			if(EResult != CURLM_OK) 
			{
				LOG_ERROR("[WebBrowser] Request '%i' Failed", iCurlMultiWaitResult);
				continue;
			}

			Sleep(10);
		}
		while (iRequestLeft);

		// Handle all finished request
		CURLMsg* pCurlMessage = curl_multi_info_read(pCurlMulti, &iRequestLeft);
		while(pCurlMessage)
		{
			switch(pCurlMessage->msg)
			{
				case CURLMSG_DONE:
				{
					uint32 uiRequestIndex = (uiRequestCount-1) - iRequestLeft;
					WebRequest& kRequest = vRequestCopy[uiRequestIndex];
					CURL* pCurlRequest = pCurlMessage->easy_handle;

					// Retrieve url
					const char* szUrl = NULL;
					curl_easy_getinfo(pCurlRequest, CURLINFO_PRIVATE, &szUrl);
						
					// Check result
					if(pCurlMessage->data.result != CURLE_OK) 
					{
						LOG_ERROR("[WebBrowser] Request '%s' Failed", szUrl);
						break;
					}

					// Get HTTP status code
					uint32 uiHttpCode = 0;
					curl_easy_getinfo(pCurlRequest, CURLINFO_RESPONSE_CODE, &uiHttpCode);
						
					// Parse document downloaded
					WebPage* pSource = kRequest.GetSource();
					WebDocument* pDocument = kRequest.GetDocument();
					Parse(pDocument, kRequest.GetBuffer(), kRequest.GetBufferSize(), pSource);
		
					// Clean request
					curl_multi_remove_handle(pCurlMulti, pCurlRequest);
					curl_easy_cleanup(pCurlRequest);
					break;
				}
			}
			pCurlMessage = curl_multi_info_read(pCurlMulti, &iRequestLeft);
		}
		
		// Clean Curl Multi
		curl_multi_cleanup(pCurlMulti);
		vRequestCopy.Clear();
	}

	//!	@brief		HandleRequestResult
	//!	@date		2015-11-21
	size_t WebBrowser::HandleRequestResult(char* _pBuffer, size_t _iSize, size_t l, void* _pData)
	{
		WebRequest* pRequest = static_cast<WebRequest*>(_pData);
		pRequest->SetBuffer(_pBuffer, (uint32)_iSize);

		return _iSize*l;
	}
}}