#ifndef _WEB_PROPERTY_STATE_HPP_
#define _WEB_PROPERTY_STATE_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>
#include <Web/WebSelector.hpp>

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebProperty;
	class WebElementStyle;
}}

/******************************************************************************
**	Class Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebPropertyState
	{
	public:
		WebPropertyState();
		~WebPropertyState();

		inline const WebElementStyle* GetStyle() const { return m_pStyle; }
		inline void SetStyle(const WebElementStyle* _pStyle) { m_pStyle = _pStyle; }

		inline const WebProperty* GetProperty() const { return m_pProperty; }
		inline void SetProperty(const WebProperty* _pProperty) { m_pProperty = _pProperty; }

		inline void SetSelector(EWebSelector::Type _eSelector) { m_eSelector = _eSelector; }
		inline EWebSelector::Type GetSelector() const { return m_eSelector; }

	private:
		const WebElementStyle* m_pStyle;
		const WebProperty* m_pProperty;
		EWebSelector::Type m_eSelector;
	};
}}
#endif