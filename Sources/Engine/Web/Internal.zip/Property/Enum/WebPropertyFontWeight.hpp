/* GENERATED ENUM WITH WEBDESCRIPTOR 2016-04-24 */

#ifndef _WEBPROPERTYFONTWEIGHT_HPP_
#define _WEBPROPERTYFONTWEIGHT_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla {namespace Web {
namespace EWebPropertyFontWeight
{
	enum Type
	{
		Normal=0,
        Bold=1,
        Bolder=2,
        Lighter=3,
        Count=4,
        Unknown

	};
	
	
	
	static const uint32 Id[EWebPropertyFontWeight::Count] =
	{
		Identifier::Compute("normal"),
        Identifier::Compute("bold"),
        Identifier::Compute("bolder"),
        Identifier::Compute("lighter"),
        
    };
	
	EWebPropertyFontWeight::Type Find(uint32 _uiId)
	{
		EWebPropertyFontWeight::Type eValue = EWebPropertyFontWeight::Unknown;;
		for(uint32 uiElement = 0; uiElement < EWebPropertyFontWeight::Count; ++uiElement)
		{
			if(EWebPropertyFontWeight::Id[uiElement] == _uiId)
			{
				eValue = (EWebPropertyFontWeight::Type)uiElement;
				break;
			}
		}
		
		return eValue;
	}
	
	EWebPropertyFontWeight::Type Find(const char* _szValue)
	{
		uint32 uiId = Identifier::Compute(_szValue);
		return Find(uiId);
	}
}
} } 

#endif