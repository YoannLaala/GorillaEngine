/* GENERATED ENUM WITH WEBDESCRIPTOR 2016-04-24 */

#ifndef _WEBPROPERTYBORDERSTYLE_HPP_
#define _WEBPROPERTYBORDERSTYLE_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla {namespace Web {
namespace EWebPropertyBorderStyle
{
	enum Type
	{
		Hidden=0,
        Dotted=1,
        Dashed=2,
        Solid=3,
        Double=4,
        Groove=5,
        Ridge=6,
        Inset=7,
        Outset=8,
        Count=9,
        Unknown

	};
	
	
	
	static const uint32 Id[EWebPropertyBorderStyle::Count] =
	{
		Identifier::Compute("hidden"),
        Identifier::Compute("dotted"),
        Identifier::Compute("dashed"),
        Identifier::Compute("solid"),
        Identifier::Compute("double"),
        Identifier::Compute("groove"),
        Identifier::Compute("ridge"),
        Identifier::Compute("inset"),
        Identifier::Compute("outset"),
        
    };
	
	EWebPropertyBorderStyle::Type Find(uint32 _uiId)
	{
		EWebPropertyBorderStyle::Type eValue = EWebPropertyBorderStyle::Unknown;;
		for(uint32 uiElement = 0; uiElement < EWebPropertyBorderStyle::Count; ++uiElement)
		{
			if(EWebPropertyBorderStyle::Id[uiElement] == _uiId)
			{
				eValue = (EWebPropertyBorderStyle::Type)uiElement;
				break;
			}
		}
		
		return eValue;
	}
	
	EWebPropertyBorderStyle::Type Find(const char* _szValue)
	{
		uint32 uiId = Identifier::Compute(_szValue);
		return Find(uiId);
	}
}
} } 

#endif