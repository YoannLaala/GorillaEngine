/* GENERATED ENUM WITH WEBDESCRIPTOR 2016-04-24 */

#ifndef _WEBPROPERTYDISPLAY_HPP_
#define _WEBPROPERTYDISPLAY_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla {namespace Web {
namespace EWebPropertyDisplay
{
	enum Type
	{
		Inline=0,
        Block=1,
        Flex=2,
        InlineBlock=3,
        InlineFlex=4,
        InlineTable=5,
        ListItem=6,
        RunIn=7,
        Table=8,
        TableCaption=9,
        TableColumnGroup=10,
        TableHeaderGroup=11,
        TableFooterGroup=12,
        TableRowGroup=13,
        TableCell=14,
        TableColumn=15,
        TableRow=16,
        Count=17,
        Unknown

	};
	
	
	
	static const uint32 Id[EWebPropertyDisplay::Count] =
	{
		Identifier::Compute("inline"),
        Identifier::Compute("block"),
        Identifier::Compute("flex"),
        Identifier::Compute("inline-block"),
        Identifier::Compute("inline-flex"),
        Identifier::Compute("inline-table"),
        Identifier::Compute("list-item"),
        Identifier::Compute("run-in"),
        Identifier::Compute("table"),
        Identifier::Compute("table-caption"),
        Identifier::Compute("table-column-group"),
        Identifier::Compute("table-header-group"),
        Identifier::Compute("table-footer-group"),
        Identifier::Compute("table-row-group"),
        Identifier::Compute("table-cell"),
        Identifier::Compute("table-column"),
        Identifier::Compute("table-row"),
        
    };
	
	EWebPropertyDisplay::Type Find(uint32 _uiId)
	{
		EWebPropertyDisplay::Type eValue = EWebPropertyDisplay::Unknown;;
		for(uint32 uiElement = 0; uiElement < EWebPropertyDisplay::Count; ++uiElement)
		{
			if(EWebPropertyDisplay::Id[uiElement] == _uiId)
			{
				eValue = (EWebPropertyDisplay::Type)uiElement;
				break;
			}
		}
		
		return eValue;
	}
	
	EWebPropertyDisplay::Type Find(const char* _szValue)
	{
		uint32 uiId = Identifier::Compute(_szValue);
		return Find(uiId);
	}
}
} } 

#endif