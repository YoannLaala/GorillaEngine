/* GENERATED ENUM WITH WEBDESCRIPTOR 2016-04-24 */

#ifndef _WEBPROPERTYFONTSTYLE_HPP_
#define _WEBPROPERTYFONTSTYLE_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla {namespace Web {
namespace EWebPropertyFontStyle
{
	enum Type
	{
		Italic=0,
        Oblique=1,
        Count=2,
        Unknown

	};
	
	
	
	static const uint32 Id[EWebPropertyFontStyle::Count] =
	{
		Identifier::Compute("italic"),
        Identifier::Compute("oblique"),
        
    };
	
	EWebPropertyFontStyle::Type Find(uint32 _uiId)
	{
		EWebPropertyFontStyle::Type eValue = EWebPropertyFontStyle::Unknown;;
		for(uint32 uiElement = 0; uiElement < EWebPropertyFontStyle::Count; ++uiElement)
		{
			if(EWebPropertyFontStyle::Id[uiElement] == _uiId)
			{
				eValue = (EWebPropertyFontStyle::Type)uiElement;
				break;
			}
		}
		
		return eValue;
	}
	
	EWebPropertyFontStyle::Type Find(const char* _szValue)
	{
		uint32 uiId = Identifier::Compute(_szValue);
		return Find(uiId);
	}
}
} } 

#endif