/* GENERATED ENUM WITH WEBDESCRIPTOR 2016-04-24 */

#ifndef _WEBPROPERTYLISTPOSITION_HPP_
#define _WEBPROPERTYLISTPOSITION_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla {namespace Web {
namespace EWebPropertyListPosition
{
	enum Type
	{
		Inside=0,
        Outside=1,
        Count=2,
        Unknown

	};
	
	
	
	static const uint32 Id[EWebPropertyListPosition::Count] =
	{
		Identifier::Compute("inside"),
        Identifier::Compute("outside"),
        
    };
	
	EWebPropertyListPosition::Type Find(uint32 _uiId)
	{
		EWebPropertyListPosition::Type eValue = EWebPropertyListPosition::Unknown;;
		for(uint32 uiElement = 0; uiElement < EWebPropertyListPosition::Count; ++uiElement)
		{
			if(EWebPropertyListPosition::Id[uiElement] == _uiId)
			{
				eValue = (EWebPropertyListPosition::Type)uiElement;
				break;
			}
		}
		
		return eValue;
	}
	
	EWebPropertyListPosition::Type Find(const char* _szValue)
	{
		uint32 uiId = Identifier::Compute(_szValue);
		return Find(uiId);
	}
}
} } 

#endif