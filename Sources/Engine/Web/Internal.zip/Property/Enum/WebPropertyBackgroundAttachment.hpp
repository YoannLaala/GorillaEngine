/* GENERATED ENUM WITH WEBDESCRIPTOR 2016-04-24 */

#ifndef _WEBPROPERTYBACKGROUNDATTACHMENT_HPP_
#define _WEBPROPERTYBACKGROUNDATTACHMENT_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla {namespace Web {
namespace EWebPropertyBackgroundAttachment
{
	enum Type
	{
		Scroll=0,
        Fixed=1,
        Local=2,
        Count=3,
        Unknown

	};
	
	
	
	static const uint32 Id[EWebPropertyBackgroundAttachment::Count] =
	{
		Identifier::Compute("scroll"),
        Identifier::Compute("fixed"),
        Identifier::Compute("local"),
        
    };
	
	EWebPropertyBackgroundAttachment::Type Find(uint32 _uiId)
	{
		EWebPropertyBackgroundAttachment::Type eValue = EWebPropertyBackgroundAttachment::Unknown;;
		for(uint32 uiElement = 0; uiElement < EWebPropertyBackgroundAttachment::Count; ++uiElement)
		{
			if(EWebPropertyBackgroundAttachment::Id[uiElement] == _uiId)
			{
				eValue = (EWebPropertyBackgroundAttachment::Type)uiElement;
				break;
			}
		}
		
		return eValue;
	}
	
	EWebPropertyBackgroundAttachment::Type Find(const char* _szValue)
	{
		uint32 uiId = Identifier::Compute(_szValue);
		return Find(uiId);
	}
}
} } 

#endif