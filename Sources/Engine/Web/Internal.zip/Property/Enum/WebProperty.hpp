/* GENERATED ENUM WITH WEBDESCRIPTOR 2016-04-24 */

#ifndef _WEBPROPERTY_HPP_
#define _WEBPROPERTY_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla {namespace Web {
namespace EWebProperty
{
	enum Type
	{
		AlignContent=0,
        Margin=1,
        MarginTop=2,
        MarginRight=3,
        MarginBottom=4,
        MarginLeft=5,
        Border=6,
        BorderTop=7,
        BorderRight=8,
        BorderBottom=9,
        BorderLeft=10,
        BorderColor=11,
        BorderTopColor=12,
        BorderRightColor=13,
        BorderBottomColor=14,
        BorderLeftColor=15,
        BorderStyle=16,
        BorderTopStyle=17,
        BorderRightStyle=18,
        BorderBottomStyle=19,
        BorderLeftStyle=20,
        BorderWidth=21,
        BorderTopWidth=22,
        BorderRightWidth=23,
        BorderBottomWidth=24,
        BorderLeftWidth=25,
        Padding=26,
        PaddingTop=27,
        PaddingRight=28,
        PaddingBottom=29,
        PaddingLeft=30,
        Top=31,
        Right=32,
        Bottom=33,
        Left=34,
        Width=35,
        Height=36,
        Display=37,
        Content=38,
        Color=39,
        Background=40,
        BackgroundAttachment=41,
        BackgroundImage=42,
        BackgroundColor=43,
        BackgroundRepeat=44,
        Font=45,
        FontFamily=46,
        FontSize=47,
        FontWeight=48,
        FontStyle=49,
        ListStyle=50,
        ListStyleImage=51,
        ListStylePosition=52,
        ListStyleType=53,
        ZIndex=54,
        Count=55,
        Unknown

	};
	
	
	
	static const uint32 Id[EWebProperty::Count] =
	{
		Identifier::Compute("align-content"),
        Identifier::Compute("margin"),
        Identifier::Compute("margin-top"),
        Identifier::Compute("margin-right"),
        Identifier::Compute("margin-bottom"),
        Identifier::Compute("margin-left"),
        Identifier::Compute("border"),
        Identifier::Compute("border-top"),
        Identifier::Compute("border-right"),
        Identifier::Compute("border-bottom"),
        Identifier::Compute("border-left"),
        Identifier::Compute("border-color"),
        Identifier::Compute("border-top-color"),
        Identifier::Compute("border-right-color"),
        Identifier::Compute("border-bottom-color"),
        Identifier::Compute("border-left-color"),
        Identifier::Compute("border-style"),
        Identifier::Compute("border-top-style"),
        Identifier::Compute("border-right-style"),
        Identifier::Compute("border-bottom-style"),
        Identifier::Compute("border-left-style"),
        Identifier::Compute("border-width"),
        Identifier::Compute("border-top-width"),
        Identifier::Compute("border-right-width"),
        Identifier::Compute("border-bottom-width"),
        Identifier::Compute("border-left-width"),
        Identifier::Compute("padding"),
        Identifier::Compute("padding-top"),
        Identifier::Compute("padding-right"),
        Identifier::Compute("padding-bottom"),
        Identifier::Compute("padding-left"),
        Identifier::Compute("top"),
        Identifier::Compute("right"),
        Identifier::Compute("bottom"),
        Identifier::Compute("left"),
        Identifier::Compute("width"),
        Identifier::Compute("height"),
        Identifier::Compute("display"),
        Identifier::Compute("content"),
        Identifier::Compute("color"),
        Identifier::Compute("background"),
        Identifier::Compute("background-attachment"),
        Identifier::Compute("background-image"),
        Identifier::Compute("background-color"),
        Identifier::Compute("background-repeat"),
        Identifier::Compute("font"),
        Identifier::Compute("font-family"),
        Identifier::Compute("font-size"),
        Identifier::Compute("font-weight"),
        Identifier::Compute("font-style"),
        Identifier::Compute("list-style"),
        Identifier::Compute("list-style-image"),
        Identifier::Compute("list-style-position"),
        Identifier::Compute("list-style-type"),
        Identifier::Compute("z-index"),
        
    };
	
	EWebProperty::Type Find(uint32 _uiId)
	{
		EWebProperty::Type eValue = EWebProperty::Unknown;;
		for(uint32 uiElement = 0; uiElement < EWebProperty::Count; ++uiElement)
		{
			if(EWebProperty::Id[uiElement] == _uiId)
			{
				eValue = (EWebProperty::Type)uiElement;
				break;
			}
		}
		
		return eValue;
	}
	
	EWebProperty::Type Find(const char* _szValue)
	{
		uint32 uiId = Identifier::Compute(_szValue);
		return Find(uiId);
	}
}
} } 

#endif