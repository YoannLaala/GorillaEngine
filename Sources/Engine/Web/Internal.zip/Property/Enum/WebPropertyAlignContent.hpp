/* GENERATED ENUM WITH WEBDESCRIPTOR 2016-04-24 */

#ifndef _WEBPROPERTYALIGNCONTENT_HPP_
#define _WEBPROPERTYALIGNCONTENT_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla {namespace Web {
namespace EWebPropertyAlignContent
{
	enum Type
	{
		Stretch=0,
        Center=1,
        FlexStart=2,
        FlexEnd=3,
        SpaceBetween=4,
        SpaceAround=5,
        Count=6,
        Unknown

	};
	
	
	
	static const uint32 Id[EWebPropertyAlignContent::Count] =
	{
		Identifier::Compute("stretch"),
        Identifier::Compute("center"),
        Identifier::Compute("flex-start"),
        Identifier::Compute("flex-end"),
        Identifier::Compute("space-between"),
        Identifier::Compute("space-around"),
        
    };
	
	EWebPropertyAlignContent::Type Find(uint32 _uiId)
	{
		EWebPropertyAlignContent::Type eValue = EWebPropertyAlignContent::Unknown;;
		for(uint32 uiElement = 0; uiElement < EWebPropertyAlignContent::Count; ++uiElement)
		{
			if(EWebPropertyAlignContent::Id[uiElement] == _uiId)
			{
				eValue = (EWebPropertyAlignContent::Type)uiElement;
				break;
			}
		}
		
		return eValue;
	}
	
	EWebPropertyAlignContent::Type Find(const char* _szValue)
	{
		uint32 uiId = Identifier::Compute(_szValue);
		return Find(uiId);
	}
}
} } 

#endif