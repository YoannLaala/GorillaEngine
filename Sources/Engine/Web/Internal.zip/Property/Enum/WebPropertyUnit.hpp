/* GENERATED ENUM WITH WEBDESCRIPTOR 2016-04-24 */

#ifndef _WEBPROPERTYUNIT_HPP_
#define _WEBPROPERTYUNIT_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla {namespace Web {
namespace EWebPropertyUnit
{
	enum Type
	{
		Number=0,
        Pixel=1,
        Centimeter=2,
        Millimeter=3,
        Inch=4,
        Point=5,
        Pica=6,
        Percentage=7,
        Em=8,
        String=9,
        Time=10,
        AlignContent=11,
        Display=12,
        BackgroundAttachment=13,
        BackgroundRepeat=14,
        BorderStyle=15,
        FontWeight=16,
        FontStyle=17,
        ListPosition=18,
        ListStyle=19,
        Color=20,
        Count=21,
        Unknown

	};
}
} } 

#endif