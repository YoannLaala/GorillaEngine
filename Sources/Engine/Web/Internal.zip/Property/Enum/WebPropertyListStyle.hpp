/* GENERATED ENUM WITH WEBDESCRIPTOR 2016-04-24 */

#ifndef _WEBPROPERTYLISTSTYLE_HPP_
#define _WEBPROPERTYLISTSTYLE_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla {namespace Web {
namespace EWebPropertyListStyle
{
	enum Type
	{
		Disc=0,
        Armenian=1,
        Circle=2,
        CjkIdeographic=3,
        Decimal=4,
        DecimalLeadingZero=5,
        Georgian=6,
        Hebrew=7,
        Hiragana=8,
        HiraganaIroha=9,
        Katakana=10,
        KatakanaIroha=11,
        LowerAlpha=12,
        LowerGreek=13,
        LowerLatin=14,
        LowerRoman=15,
        Square=16,
        UpperAlpha=17,
        UpperLatin=18,
        UpperRoman=19,
        Count=20,
        Unknown

	};
	
	
	
	static const uint32 Id[EWebPropertyListStyle::Count] =
	{
		Identifier::Compute("disc"),
        Identifier::Compute("armenian"),
        Identifier::Compute("circle"),
        Identifier::Compute("cjk-ideographic"),
        Identifier::Compute("decimal"),
        Identifier::Compute("decimal-leading-zero"),
        Identifier::Compute("georgian"),
        Identifier::Compute("hebrew"),
        Identifier::Compute("hiragana"),
        Identifier::Compute("hiragana-iroha"),
        Identifier::Compute("katakana"),
        Identifier::Compute("katakana-iroha"),
        Identifier::Compute("lower-alpha"),
        Identifier::Compute("lower-greek"),
        Identifier::Compute("lower-latin"),
        Identifier::Compute("lower-roman"),
        Identifier::Compute("square"),
        Identifier::Compute("upper-alpha"),
        Identifier::Compute("upper-latin"),
        Identifier::Compute("upper-roman"),
        
    };
	
	EWebPropertyListStyle::Type Find(uint32 _uiId)
	{
		EWebPropertyListStyle::Type eValue = EWebPropertyListStyle::Unknown;;
		for(uint32 uiElement = 0; uiElement < EWebPropertyListStyle::Count; ++uiElement)
		{
			if(EWebPropertyListStyle::Id[uiElement] == _uiId)
			{
				eValue = (EWebPropertyListStyle::Type)uiElement;
				break;
			}
		}
		
		return eValue;
	}
	
	EWebPropertyListStyle::Type Find(const char* _szValue)
	{
		uint32 uiId = Identifier::Compute(_szValue);
		return Find(uiId);
	}
}
} } 

#endif