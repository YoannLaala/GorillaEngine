/* GENERATED ENUM WITH WEBDESCRIPTOR 2016-04-24 */

#ifndef _WEBPROPERTYBACKGROUNDREPEAT_HPP_
#define _WEBPROPERTYBACKGROUNDREPEAT_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla {namespace Web {
namespace EWebPropertyBackgroundRepeat
{
	enum Type
	{
		Default=0,
        RepeatX=1,
        RepeatY=2,
        NoRepeat=3,
        Count=4,
        Unknown

	};
	
	
	
	static const uint32 Id[EWebPropertyBackgroundRepeat::Count] =
	{
		Identifier::Compute("repeat"),
        Identifier::Compute("repeat-x"),
        Identifier::Compute("repeat-y"),
        Identifier::Compute("no-repeat"),
        
    };
	
	EWebPropertyBackgroundRepeat::Type Find(uint32 _uiId)
	{
		EWebPropertyBackgroundRepeat::Type eValue = EWebPropertyBackgroundRepeat::Unknown;;
		for(uint32 uiElement = 0; uiElement < EWebPropertyBackgroundRepeat::Count; ++uiElement)
		{
			if(EWebPropertyBackgroundRepeat::Id[uiElement] == _uiId)
			{
				eValue = (EWebPropertyBackgroundRepeat::Type)uiElement;
				break;
			}
		}
		
		return eValue;
	}
	
	EWebPropertyBackgroundRepeat::Type Find(const char* _szValue)
	{
		uint32 uiId = Identifier::Compute(_szValue);
		return Find(uiId);
	}
}
} } 

#endif