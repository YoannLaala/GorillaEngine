/* GENERATED CLASS WITH WEBDESCRIPTOR 2016-04-24 */

#ifndef _WEBPROPERTYANALYZER_HPP_
#define _WEBPROPERTYANALYZER_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>
#include "../Enum/WebProperty.hpp"
#include "../Enum/WebPropertyUnit.hpp"
#include "../Enum/WebPropertyAlignContent.hpp"
#include "../Enum/WebPropertyBorderStyle.hpp"
#include "../Enum/WebPropertyColor.hpp"
#include "../Enum/WebPropertyDisplay.hpp"
#include "../Enum/WebPropertyBackgroundAttachment.hpp"
#include "../Enum/WebPropertyBackgroundRepeat.hpp"
#include "../Enum/WebPropertyFontWeight.hpp"
#include "../Enum/WebPropertyFontStyle.hpp"
#include "../Enum/WebPropertyListPosition.hpp"
#include "../Enum/WebPropertyListStyle.hpp"


/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla {namespace Web 
{
	template <EWebProperty::Type T>
	class WebPropertyAnalyzer;
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::AlignContent>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyAlignContent::Type eAlignContent = EWebPropertyAlignContent::Find(uiId);
            if(eAlignContent != EWebPropertyAlignContent::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::AlignContent;
                _uiValueOut = eAlignContent;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::AlignContent: return EWebProperty::AlignContent;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentNode>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::Margin>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::Margin;
                case EWebPropertyUnit::Centimeter: return EWebProperty::Margin;
                case EWebPropertyUnit::Millimeter: return EWebProperty::Margin;
                case EWebPropertyUnit::Inch: return EWebProperty::Margin;
                case EWebPropertyUnit::Point: return EWebProperty::Margin;
                case EWebPropertyUnit::Pica: return EWebProperty::Margin;
                case EWebPropertyUnit::Percentage: return EWebProperty::Margin;
                case EWebPropertyUnit::Em: return EWebProperty::Margin;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentNode>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::MarginTop>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::MarginTop;
                case EWebPropertyUnit::Centimeter: return EWebProperty::MarginTop;
                case EWebPropertyUnit::Millimeter: return EWebProperty::MarginTop;
                case EWebPropertyUnit::Inch: return EWebProperty::MarginTop;
                case EWebPropertyUnit::Point: return EWebProperty::MarginTop;
                case EWebPropertyUnit::Pica: return EWebProperty::MarginTop;
                case EWebPropertyUnit::Percentage: return EWebProperty::MarginTop;
                case EWebPropertyUnit::Em: return EWebProperty::MarginTop;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentNode>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::MarginRight>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::MarginRight;
                case EWebPropertyUnit::Centimeter: return EWebProperty::MarginRight;
                case EWebPropertyUnit::Millimeter: return EWebProperty::MarginRight;
                case EWebPropertyUnit::Inch: return EWebProperty::MarginRight;
                case EWebPropertyUnit::Point: return EWebProperty::MarginRight;
                case EWebPropertyUnit::Pica: return EWebProperty::MarginRight;
                case EWebPropertyUnit::Percentage: return EWebProperty::MarginRight;
                case EWebPropertyUnit::Em: return EWebProperty::MarginRight;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentNode>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::MarginBottom>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::MarginBottom;
                case EWebPropertyUnit::Centimeter: return EWebProperty::MarginBottom;
                case EWebPropertyUnit::Millimeter: return EWebProperty::MarginBottom;
                case EWebPropertyUnit::Inch: return EWebProperty::MarginBottom;
                case EWebPropertyUnit::Point: return EWebProperty::MarginBottom;
                case EWebPropertyUnit::Pica: return EWebProperty::MarginBottom;
                case EWebPropertyUnit::Percentage: return EWebProperty::MarginBottom;
                case EWebPropertyUnit::Em: return EWebProperty::MarginBottom;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentNode>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::MarginLeft>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::MarginLeft;
                case EWebPropertyUnit::Centimeter: return EWebProperty::MarginLeft;
                case EWebPropertyUnit::Millimeter: return EWebProperty::MarginLeft;
                case EWebPropertyUnit::Inch: return EWebProperty::MarginLeft;
                case EWebPropertyUnit::Point: return EWebProperty::MarginLeft;
                case EWebPropertyUnit::Pica: return EWebProperty::MarginLeft;
                case EWebPropertyUnit::Percentage: return EWebProperty::MarginLeft;
                case EWebPropertyUnit::Em: return EWebProperty::MarginLeft;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentNode>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::Border>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyBorderStyle::Type eBorderStyle = EWebPropertyBorderStyle::Find(uiId);
            if(eBorderStyle != EWebPropertyBorderStyle::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::BorderStyle;
                _uiValueOut = eBorderStyle;
            }
            EWebPropertyColor::Type eColor = EWebPropertyColor::Find(uiId);
            if(eColor != EWebPropertyColor::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::Color;
                _uiValueOut = eColor;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::BorderWidth;
                case EWebPropertyUnit::Centimeter: return EWebProperty::BorderWidth;
                case EWebPropertyUnit::Millimeter: return EWebProperty::BorderWidth;
                case EWebPropertyUnit::Inch: return EWebProperty::BorderWidth;
                case EWebPropertyUnit::Point: return EWebProperty::BorderWidth;
                case EWebPropertyUnit::Pica: return EWebProperty::BorderWidth;
                case EWebPropertyUnit::Percentage: return EWebProperty::BorderWidth;
                case EWebPropertyUnit::Em: return EWebProperty::BorderWidth;
                case EWebPropertyUnit::BorderStyle: return EWebProperty::BorderStyle;
                case EWebPropertyUnit::Color: return EWebProperty::BorderColor;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentBorder>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BorderTop>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyBorderStyle::Type eBorderStyle = EWebPropertyBorderStyle::Find(uiId);
            if(eBorderStyle != EWebPropertyBorderStyle::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::BorderStyle;
                _uiValueOut = eBorderStyle;
            }
            EWebPropertyColor::Type eColor = EWebPropertyColor::Find(uiId);
            if(eColor != EWebPropertyColor::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::Color;
                _uiValueOut = eColor;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::BorderTopWidth;
                case EWebPropertyUnit::Centimeter: return EWebProperty::BorderTopWidth;
                case EWebPropertyUnit::Millimeter: return EWebProperty::BorderTopWidth;
                case EWebPropertyUnit::Inch: return EWebProperty::BorderTopWidth;
                case EWebPropertyUnit::Point: return EWebProperty::BorderTopWidth;
                case EWebPropertyUnit::Pica: return EWebProperty::BorderTopWidth;
                case EWebPropertyUnit::Percentage: return EWebProperty::BorderTopWidth;
                case EWebPropertyUnit::Em: return EWebProperty::BorderTopWidth;
                case EWebPropertyUnit::BorderStyle: return EWebProperty::BorderTopStyle;
                case EWebPropertyUnit::Color: return EWebProperty::BorderTopColor;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentBorder>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BorderRight>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyBorderStyle::Type eBorderStyle = EWebPropertyBorderStyle::Find(uiId);
            if(eBorderStyle != EWebPropertyBorderStyle::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::BorderStyle;
                _uiValueOut = eBorderStyle;
            }
            EWebPropertyColor::Type eColor = EWebPropertyColor::Find(uiId);
            if(eColor != EWebPropertyColor::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::Color;
                _uiValueOut = eColor;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::BorderRightWidth;
                case EWebPropertyUnit::Centimeter: return EWebProperty::BorderRightWidth;
                case EWebPropertyUnit::Millimeter: return EWebProperty::BorderRightWidth;
                case EWebPropertyUnit::Inch: return EWebProperty::BorderRightWidth;
                case EWebPropertyUnit::Point: return EWebProperty::BorderRightWidth;
                case EWebPropertyUnit::Pica: return EWebProperty::BorderRightWidth;
                case EWebPropertyUnit::Percentage: return EWebProperty::BorderRightWidth;
                case EWebPropertyUnit::Em: return EWebProperty::BorderRightWidth;
                case EWebPropertyUnit::BorderStyle: return EWebProperty::BorderRightStyle;
                case EWebPropertyUnit::Color: return EWebProperty::BorderRightColor;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentBorder>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BorderBottom>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyBorderStyle::Type eBorderStyle = EWebPropertyBorderStyle::Find(uiId);
            if(eBorderStyle != EWebPropertyBorderStyle::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::BorderStyle;
                _uiValueOut = eBorderStyle;
            }
            EWebPropertyColor::Type eColor = EWebPropertyColor::Find(uiId);
            if(eColor != EWebPropertyColor::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::Color;
                _uiValueOut = eColor;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::BorderBottomWidth;
                case EWebPropertyUnit::Centimeter: return EWebProperty::BorderBottomWidth;
                case EWebPropertyUnit::Millimeter: return EWebProperty::BorderBottomWidth;
                case EWebPropertyUnit::Inch: return EWebProperty::BorderBottomWidth;
                case EWebPropertyUnit::Point: return EWebProperty::BorderBottomWidth;
                case EWebPropertyUnit::Pica: return EWebProperty::BorderBottomWidth;
                case EWebPropertyUnit::Percentage: return EWebProperty::BorderBottomWidth;
                case EWebPropertyUnit::Em: return EWebProperty::BorderBottomWidth;
                case EWebPropertyUnit::BorderStyle: return EWebProperty::BorderBottomStyle;
                case EWebPropertyUnit::Color: return EWebProperty::BorderBottomColor;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentBorder>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BorderLeft>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyBorderStyle::Type eBorderStyle = EWebPropertyBorderStyle::Find(uiId);
            if(eBorderStyle != EWebPropertyBorderStyle::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::BorderStyle;
                _uiValueOut = eBorderStyle;
            }
            EWebPropertyColor::Type eColor = EWebPropertyColor::Find(uiId);
            if(eColor != EWebPropertyColor::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::Color;
                _uiValueOut = eColor;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::BorderLeftWidth;
                case EWebPropertyUnit::Centimeter: return EWebProperty::BorderLeftWidth;
                case EWebPropertyUnit::Millimeter: return EWebProperty::BorderLeftWidth;
                case EWebPropertyUnit::Inch: return EWebProperty::BorderLeftWidth;
                case EWebPropertyUnit::Point: return EWebProperty::BorderLeftWidth;
                case EWebPropertyUnit::Pica: return EWebProperty::BorderLeftWidth;
                case EWebPropertyUnit::Percentage: return EWebProperty::BorderLeftWidth;
                case EWebPropertyUnit::Em: return EWebProperty::BorderLeftWidth;
                case EWebPropertyUnit::BorderStyle: return EWebProperty::BorderLeftStyle;
                case EWebPropertyUnit::Color: return EWebProperty::BorderLeftColor;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentBorder>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BorderColor>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyColor::Type eColor = EWebPropertyColor::Find(uiId);
            if(eColor != EWebPropertyColor::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::Color;
                _uiValueOut = eColor;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Color: return EWebProperty::BorderColor;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentBorder>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BorderTopColor>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyColor::Type eColor = EWebPropertyColor::Find(uiId);
            if(eColor != EWebPropertyColor::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::Color;
                _uiValueOut = eColor;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Color: return EWebProperty::BorderTopColor;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentBorder>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BorderRightColor>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyColor::Type eColor = EWebPropertyColor::Find(uiId);
            if(eColor != EWebPropertyColor::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::Color;
                _uiValueOut = eColor;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Color: return EWebProperty::BorderRightColor;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentBorder>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BorderBottomColor>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyColor::Type eColor = EWebPropertyColor::Find(uiId);
            if(eColor != EWebPropertyColor::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::Color;
                _uiValueOut = eColor;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Color: return EWebProperty::BorderBottomColor;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentBorder>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BorderLeftColor>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyColor::Type eColor = EWebPropertyColor::Find(uiId);
            if(eColor != EWebPropertyColor::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::Color;
                _uiValueOut = eColor;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Color: return EWebProperty::BorderLeftColor;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentBorder>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BorderStyle>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyBorderStyle::Type eBorderStyle = EWebPropertyBorderStyle::Find(uiId);
            if(eBorderStyle != EWebPropertyBorderStyle::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::BorderStyle;
                _uiValueOut = eBorderStyle;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::BorderStyle: return EWebProperty::BorderStyle;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentBorder>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BorderTopStyle>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyBorderStyle::Type eBorderStyle = EWebPropertyBorderStyle::Find(uiId);
            if(eBorderStyle != EWebPropertyBorderStyle::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::BorderStyle;
                _uiValueOut = eBorderStyle;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::BorderStyle: return EWebProperty::BorderTopStyle;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentBorder>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BorderRightStyle>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyBorderStyle::Type eBorderStyle = EWebPropertyBorderStyle::Find(uiId);
            if(eBorderStyle != EWebPropertyBorderStyle::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::BorderStyle;
                _uiValueOut = eBorderStyle;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::BorderStyle: return EWebProperty::BorderRightStyle;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentBorder>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BorderBottomStyle>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyBorderStyle::Type eBorderStyle = EWebPropertyBorderStyle::Find(uiId);
            if(eBorderStyle != EWebPropertyBorderStyle::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::BorderStyle;
                _uiValueOut = eBorderStyle;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::BorderStyle: return EWebProperty::BorderBottomStyle;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentBorder>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BorderLeftStyle>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyBorderStyle::Type eBorderStyle = EWebPropertyBorderStyle::Find(uiId);
            if(eBorderStyle != EWebPropertyBorderStyle::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::BorderStyle;
                _uiValueOut = eBorderStyle;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::BorderStyle: return EWebProperty::BorderLeftStyle;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentBorder>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BorderWidth>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::BorderWidth;
                case EWebPropertyUnit::Centimeter: return EWebProperty::BorderWidth;
                case EWebPropertyUnit::Millimeter: return EWebProperty::BorderWidth;
                case EWebPropertyUnit::Inch: return EWebProperty::BorderWidth;
                case EWebPropertyUnit::Point: return EWebProperty::BorderWidth;
                case EWebPropertyUnit::Pica: return EWebProperty::BorderWidth;
                case EWebPropertyUnit::Percentage: return EWebProperty::BorderWidth;
                case EWebPropertyUnit::Em: return EWebProperty::BorderWidth;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentBorder>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BorderTopWidth>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::BorderTopWidth;
                case EWebPropertyUnit::Centimeter: return EWebProperty::BorderTopWidth;
                case EWebPropertyUnit::Millimeter: return EWebProperty::BorderTopWidth;
                case EWebPropertyUnit::Inch: return EWebProperty::BorderTopWidth;
                case EWebPropertyUnit::Point: return EWebProperty::BorderTopWidth;
                case EWebPropertyUnit::Pica: return EWebProperty::BorderTopWidth;
                case EWebPropertyUnit::Percentage: return EWebProperty::BorderTopWidth;
                case EWebPropertyUnit::Em: return EWebProperty::BorderTopWidth;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentBorder>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BorderRightWidth>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::BorderRightWidth;
                case EWebPropertyUnit::Centimeter: return EWebProperty::BorderRightWidth;
                case EWebPropertyUnit::Millimeter: return EWebProperty::BorderRightWidth;
                case EWebPropertyUnit::Inch: return EWebProperty::BorderRightWidth;
                case EWebPropertyUnit::Point: return EWebProperty::BorderRightWidth;
                case EWebPropertyUnit::Pica: return EWebProperty::BorderRightWidth;
                case EWebPropertyUnit::Percentage: return EWebProperty::BorderRightWidth;
                case EWebPropertyUnit::Em: return EWebProperty::BorderRightWidth;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentBorder>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BorderBottomWidth>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::BorderBottomWidth;
                case EWebPropertyUnit::Centimeter: return EWebProperty::BorderBottomWidth;
                case EWebPropertyUnit::Millimeter: return EWebProperty::BorderBottomWidth;
                case EWebPropertyUnit::Inch: return EWebProperty::BorderBottomWidth;
                case EWebPropertyUnit::Point: return EWebProperty::BorderBottomWidth;
                case EWebPropertyUnit::Pica: return EWebProperty::BorderBottomWidth;
                case EWebPropertyUnit::Percentage: return EWebProperty::BorderBottomWidth;
                case EWebPropertyUnit::Em: return EWebProperty::BorderBottomWidth;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentBorder>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BorderLeftWidth>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::BorderLeftWidth;
                case EWebPropertyUnit::Centimeter: return EWebProperty::BorderLeftWidth;
                case EWebPropertyUnit::Millimeter: return EWebProperty::BorderLeftWidth;
                case EWebPropertyUnit::Inch: return EWebProperty::BorderLeftWidth;
                case EWebPropertyUnit::Point: return EWebProperty::BorderLeftWidth;
                case EWebPropertyUnit::Pica: return EWebProperty::BorderLeftWidth;
                case EWebPropertyUnit::Percentage: return EWebProperty::BorderLeftWidth;
                case EWebPropertyUnit::Em: return EWebProperty::BorderLeftWidth;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentBorder>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::Padding>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::Padding;
                case EWebPropertyUnit::Centimeter: return EWebProperty::Padding;
                case EWebPropertyUnit::Millimeter: return EWebProperty::Padding;
                case EWebPropertyUnit::Inch: return EWebProperty::Padding;
                case EWebPropertyUnit::Point: return EWebProperty::Padding;
                case EWebPropertyUnit::Pica: return EWebProperty::Padding;
                case EWebPropertyUnit::Percentage: return EWebProperty::Padding;
                case EWebPropertyUnit::Em: return EWebProperty::Padding;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentNode>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::PaddingTop>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::PaddingTop;
                case EWebPropertyUnit::Centimeter: return EWebProperty::PaddingTop;
                case EWebPropertyUnit::Millimeter: return EWebProperty::PaddingTop;
                case EWebPropertyUnit::Inch: return EWebProperty::PaddingTop;
                case EWebPropertyUnit::Point: return EWebProperty::PaddingTop;
                case EWebPropertyUnit::Pica: return EWebProperty::PaddingTop;
                case EWebPropertyUnit::Percentage: return EWebProperty::PaddingTop;
                case EWebPropertyUnit::Em: return EWebProperty::PaddingTop;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentNode>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::PaddingRight>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::PaddingTop;
                case EWebPropertyUnit::Centimeter: return EWebProperty::PaddingTop;
                case EWebPropertyUnit::Millimeter: return EWebProperty::PaddingTop;
                case EWebPropertyUnit::Inch: return EWebProperty::PaddingTop;
                case EWebPropertyUnit::Point: return EWebProperty::PaddingTop;
                case EWebPropertyUnit::Pica: return EWebProperty::PaddingTop;
                case EWebPropertyUnit::Percentage: return EWebProperty::PaddingTop;
                case EWebPropertyUnit::Em: return EWebProperty::PaddingTop;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentNode>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::PaddingBottom>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::PaddingBottom;
                case EWebPropertyUnit::Centimeter: return EWebProperty::PaddingBottom;
                case EWebPropertyUnit::Millimeter: return EWebProperty::PaddingBottom;
                case EWebPropertyUnit::Inch: return EWebProperty::PaddingBottom;
                case EWebPropertyUnit::Point: return EWebProperty::PaddingBottom;
                case EWebPropertyUnit::Pica: return EWebProperty::PaddingBottom;
                case EWebPropertyUnit::Percentage: return EWebProperty::PaddingBottom;
                case EWebPropertyUnit::Em: return EWebProperty::PaddingBottom;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentNode>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::PaddingLeft>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::PaddingLeft;
                case EWebPropertyUnit::Centimeter: return EWebProperty::PaddingLeft;
                case EWebPropertyUnit::Millimeter: return EWebProperty::PaddingLeft;
                case EWebPropertyUnit::Inch: return EWebProperty::PaddingLeft;
                case EWebPropertyUnit::Point: return EWebProperty::PaddingLeft;
                case EWebPropertyUnit::Pica: return EWebProperty::PaddingLeft;
                case EWebPropertyUnit::Percentage: return EWebProperty::PaddingLeft;
                case EWebPropertyUnit::Em: return EWebProperty::PaddingLeft;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentNode>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::Top>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::Top;
                case EWebPropertyUnit::Centimeter: return EWebProperty::Top;
                case EWebPropertyUnit::Millimeter: return EWebProperty::Top;
                case EWebPropertyUnit::Inch: return EWebProperty::Top;
                case EWebPropertyUnit::Point: return EWebProperty::Top;
                case EWebPropertyUnit::Pica: return EWebProperty::Top;
                case EWebPropertyUnit::Percentage: return EWebProperty::Top;
                case EWebPropertyUnit::Em: return EWebProperty::Top;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentNode>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::Right>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::Right;
                case EWebPropertyUnit::Centimeter: return EWebProperty::Right;
                case EWebPropertyUnit::Millimeter: return EWebProperty::Right;
                case EWebPropertyUnit::Inch: return EWebProperty::Right;
                case EWebPropertyUnit::Point: return EWebProperty::Right;
                case EWebPropertyUnit::Pica: return EWebProperty::Right;
                case EWebPropertyUnit::Percentage: return EWebProperty::Right;
                case EWebPropertyUnit::Em: return EWebProperty::Right;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentNode>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::Bottom>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::Bottom;
                case EWebPropertyUnit::Centimeter: return EWebProperty::Bottom;
                case EWebPropertyUnit::Millimeter: return EWebProperty::Bottom;
                case EWebPropertyUnit::Inch: return EWebProperty::Bottom;
                case EWebPropertyUnit::Point: return EWebProperty::Bottom;
                case EWebPropertyUnit::Pica: return EWebProperty::Bottom;
                case EWebPropertyUnit::Percentage: return EWebProperty::Bottom;
                case EWebPropertyUnit::Em: return EWebProperty::Bottom;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentNode>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::Left>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::Left;
                case EWebPropertyUnit::Centimeter: return EWebProperty::Left;
                case EWebPropertyUnit::Millimeter: return EWebProperty::Left;
                case EWebPropertyUnit::Inch: return EWebProperty::Left;
                case EWebPropertyUnit::Point: return EWebProperty::Left;
                case EWebPropertyUnit::Pica: return EWebProperty::Left;
                case EWebPropertyUnit::Percentage: return EWebProperty::Left;
                case EWebPropertyUnit::Em: return EWebProperty::Left;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentNode>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::Width>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::Width;
                case EWebPropertyUnit::Centimeter: return EWebProperty::Width;
                case EWebPropertyUnit::Millimeter: return EWebProperty::Width;
                case EWebPropertyUnit::Inch: return EWebProperty::Width;
                case EWebPropertyUnit::Point: return EWebProperty::Width;
                case EWebPropertyUnit::Pica: return EWebProperty::Width;
                case EWebPropertyUnit::Percentage: return EWebProperty::Width;
                case EWebPropertyUnit::Em: return EWebProperty::Width;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentNode>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::Height>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::Height;
                case EWebPropertyUnit::Centimeter: return EWebProperty::Height;
                case EWebPropertyUnit::Millimeter: return EWebProperty::Height;
                case EWebPropertyUnit::Inch: return EWebProperty::Height;
                case EWebPropertyUnit::Point: return EWebProperty::Height;
                case EWebPropertyUnit::Pica: return EWebProperty::Height;
                case EWebPropertyUnit::Percentage: return EWebProperty::Height;
                case EWebPropertyUnit::Em: return EWebProperty::Height;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentNode>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::Display>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyDisplay::Type eDisplay = EWebPropertyDisplay::Find(uiId);
            if(eDisplay != EWebPropertyDisplay::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::Display;
                _uiValueOut = eDisplay;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Display: return EWebProperty::Display;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentNode>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::Content>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyDisplay::Type eDisplay = EWebPropertyDisplay::Find(uiId);
            if(eDisplay != EWebPropertyDisplay::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::Display;
                _uiValueOut = eDisplay;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::String: return EWebProperty::Content;
                case EWebPropertyUnit::Display: return EWebProperty::Display;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentText>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::Color>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyColor::Type eColor = EWebPropertyColor::Find(uiId);
            if(eColor != EWebPropertyColor::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::Color;
                _uiValueOut = eColor;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Color: return EWebProperty::Color;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentText>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::Background>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyBackgroundAttachment::Type eBackgroundAttachment = EWebPropertyBackgroundAttachment::Find(uiId);
            if(eBackgroundAttachment != EWebPropertyBackgroundAttachment::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::BackgroundAttachment;
                _uiValueOut = eBackgroundAttachment;
            }
            EWebPropertyColor::Type eColor = EWebPropertyColor::Find(uiId);
            if(eColor != EWebPropertyColor::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::Color;
                _uiValueOut = eColor;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::String: return EWebProperty::BackgroundImage;
                case EWebPropertyUnit::BackgroundAttachment: return EWebProperty::BackgroundAttachment;
                case EWebPropertyUnit::Color: return EWebProperty::BackgroundColor;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentRectangle>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BackgroundAttachment>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyBackgroundAttachment::Type eBackgroundAttachment = EWebPropertyBackgroundAttachment::Find(uiId);
            if(eBackgroundAttachment != EWebPropertyBackgroundAttachment::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::BackgroundAttachment;
                _uiValueOut = eBackgroundAttachment;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::BackgroundAttachment: return EWebProperty::BackgroundAttachment;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentRectangle>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BackgroundImage>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::String: return EWebProperty::BackgroundImage;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentRectangle>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BackgroundColor>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyColor::Type eColor = EWebPropertyColor::Find(uiId);
            if(eColor != EWebPropertyColor::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::Color;
                _uiValueOut = eColor;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Color: return EWebProperty::BackgroundColor;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentRectangle>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::BackgroundRepeat>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyBackgroundRepeat::Type eBackgroundRepeat = EWebPropertyBackgroundRepeat::Find(uiId);
            if(eBackgroundRepeat != EWebPropertyBackgroundRepeat::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::BackgroundRepeat;
                _uiValueOut = eBackgroundRepeat;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::BackgroundRepeat: return EWebProperty::BackgroundRepeat;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentRectangle>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::Font>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::String: return EWebProperty::FontFamily;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentText>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::FontFamily>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::String: return EWebProperty::FontFamily;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentText>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::FontSize>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::FontSize;
                case EWebPropertyUnit::Centimeter: return EWebProperty::FontSize;
                case EWebPropertyUnit::Millimeter: return EWebProperty::FontSize;
                case EWebPropertyUnit::Inch: return EWebProperty::FontSize;
                case EWebPropertyUnit::Point: return EWebProperty::FontSize;
                case EWebPropertyUnit::Pica: return EWebProperty::FontSize;
                case EWebPropertyUnit::Percentage: return EWebProperty::FontSize;
                case EWebPropertyUnit::Em: return EWebProperty::FontSize;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentText>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::FontWeight>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyFontWeight::Type eFontWeight = EWebPropertyFontWeight::Find(uiId);
            if(eFontWeight != EWebPropertyFontWeight::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::FontWeight;
                _uiValueOut = eFontWeight;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Pixel: return EWebProperty::FontWeight;
                case EWebPropertyUnit::Centimeter: return EWebProperty::FontWeight;
                case EWebPropertyUnit::Millimeter: return EWebProperty::FontWeight;
                case EWebPropertyUnit::Inch: return EWebProperty::FontWeight;
                case EWebPropertyUnit::Point: return EWebProperty::FontWeight;
                case EWebPropertyUnit::Pica: return EWebProperty::FontWeight;
                case EWebPropertyUnit::Percentage: return EWebProperty::FontWeight;
                case EWebPropertyUnit::Em: return EWebProperty::FontWeight;
                case EWebPropertyUnit::FontWeight: return EWebProperty::FontWeight;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentText>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::FontStyle>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyFontStyle::Type eFontStyle = EWebPropertyFontStyle::Find(uiId);
            if(eFontStyle != EWebPropertyFontStyle::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::FontStyle;
                _uiValueOut = eFontStyle;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::FontStyle: return EWebProperty::FontStyle;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentText>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::ListStyle>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyListPosition::Type eListPosition = EWebPropertyListPosition::Find(uiId);
            if(eListPosition != EWebPropertyListPosition::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::ListPosition;
                _uiValueOut = eListPosition;
            }
            EWebPropertyListStyle::Type eListStyle = EWebPropertyListStyle::Find(uiId);
            if(eListStyle != EWebPropertyListStyle::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::ListStyle;
                _uiValueOut = eListStyle;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::String: return EWebProperty::ListStyleImage;
                case EWebPropertyUnit::ListPosition: return EWebProperty::ListStylePosition;
                case EWebPropertyUnit::ListStyle: return EWebProperty::ListStyleType;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentList>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::ListStyleImage>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::String: return EWebProperty::ListStyleImage;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentList>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::ListStylePosition>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyListPosition::Type eListPosition = EWebPropertyListPosition::Find(uiId);
            if(eListPosition != EWebPropertyListPosition::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::ListPosition;
                _uiValueOut = eListPosition;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::ListPosition: return EWebProperty::ListStylePosition;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentList>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::ListStyleType>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			const uint32 uiId = Identifier::Compute(_szValue);
            EWebPropertyListStyle::Type eListStyle = EWebPropertyListStyle::Find(uiId);
            if(eListStyle != EWebPropertyListStyle::Unknown)
            {
                _eUnitOut = EWebPropertyUnit::ListStyle;
                _uiValueOut = eListStyle;
            }
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::ListStyle: return EWebProperty::ListStyleType;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentList>();
		}
	};
	
	template <>
	class WebPropertyAnalyzer<EWebProperty::ZIndex>
	{
	public:

		static void ParseValue(const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			UNUSED(_szValue);UNUSED(_eUnitOut);UNUSED(_uiValueOut);
		}

		static EWebProperty::Type GetAtomicProperty(EWebPropertyUnit::Type _eUnit)
		{
			switch(_eUnit)
			{
				case EWebPropertyUnit::Number: return EWebProperty::ZIndex;
                
			}
			
			return EWebProperty::Unknown;
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement)
		{
			return _pElement->GetOrCreateComponent<WebComponentNode>();
		}
	};
	
	template<>
	class WebPropertyAnalyzer<EWebProperty::Unknown>
	{
	public:
		static void ParseValue(EWebProperty::Type _eType, const char* _szValue, EWebPropertyUnit::Type& _eUnitOut, uint32& _uiValueOut)
		{
			switch(_eType)
			{
				case EWebProperty::AlignContent: WebPropertyAnalyzer<EWebProperty::AlignContent>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::Margin: WebPropertyAnalyzer<EWebProperty::Margin>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::MarginTop: WebPropertyAnalyzer<EWebProperty::MarginTop>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::MarginRight: WebPropertyAnalyzer<EWebProperty::MarginRight>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::MarginBottom: WebPropertyAnalyzer<EWebProperty::MarginBottom>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::MarginLeft: WebPropertyAnalyzer<EWebProperty::MarginLeft>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::Border: WebPropertyAnalyzer<EWebProperty::Border>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BorderTop: WebPropertyAnalyzer<EWebProperty::BorderTop>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BorderRight: WebPropertyAnalyzer<EWebProperty::BorderRight>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BorderBottom: WebPropertyAnalyzer<EWebProperty::BorderBottom>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BorderLeft: WebPropertyAnalyzer<EWebProperty::BorderLeft>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BorderColor: WebPropertyAnalyzer<EWebProperty::BorderColor>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BorderTopColor: WebPropertyAnalyzer<EWebProperty::BorderTopColor>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BorderRightColor: WebPropertyAnalyzer<EWebProperty::BorderRightColor>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BorderBottomColor: WebPropertyAnalyzer<EWebProperty::BorderBottomColor>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BorderLeftColor: WebPropertyAnalyzer<EWebProperty::BorderLeftColor>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BorderStyle: WebPropertyAnalyzer<EWebProperty::BorderStyle>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BorderTopStyle: WebPropertyAnalyzer<EWebProperty::BorderTopStyle>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BorderRightStyle: WebPropertyAnalyzer<EWebProperty::BorderRightStyle>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BorderBottomStyle: WebPropertyAnalyzer<EWebProperty::BorderBottomStyle>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BorderLeftStyle: WebPropertyAnalyzer<EWebProperty::BorderLeftStyle>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BorderWidth: WebPropertyAnalyzer<EWebProperty::BorderWidth>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BorderTopWidth: WebPropertyAnalyzer<EWebProperty::BorderTopWidth>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BorderRightWidth: WebPropertyAnalyzer<EWebProperty::BorderRightWidth>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BorderBottomWidth: WebPropertyAnalyzer<EWebProperty::BorderBottomWidth>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BorderLeftWidth: WebPropertyAnalyzer<EWebProperty::BorderLeftWidth>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::Padding: WebPropertyAnalyzer<EWebProperty::Padding>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::PaddingTop: WebPropertyAnalyzer<EWebProperty::PaddingTop>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::PaddingRight: WebPropertyAnalyzer<EWebProperty::PaddingRight>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::PaddingBottom: WebPropertyAnalyzer<EWebProperty::PaddingBottom>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::PaddingLeft: WebPropertyAnalyzer<EWebProperty::PaddingLeft>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::Top: WebPropertyAnalyzer<EWebProperty::Top>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::Right: WebPropertyAnalyzer<EWebProperty::Right>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::Bottom: WebPropertyAnalyzer<EWebProperty::Bottom>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::Left: WebPropertyAnalyzer<EWebProperty::Left>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::Width: WebPropertyAnalyzer<EWebProperty::Width>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::Height: WebPropertyAnalyzer<EWebProperty::Height>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::Display: WebPropertyAnalyzer<EWebProperty::Display>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::Content: WebPropertyAnalyzer<EWebProperty::Content>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::Color: WebPropertyAnalyzer<EWebProperty::Color>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::Background: WebPropertyAnalyzer<EWebProperty::Background>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BackgroundAttachment: WebPropertyAnalyzer<EWebProperty::BackgroundAttachment>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BackgroundImage: WebPropertyAnalyzer<EWebProperty::BackgroundImage>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BackgroundColor: WebPropertyAnalyzer<EWebProperty::BackgroundColor>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::BackgroundRepeat: WebPropertyAnalyzer<EWebProperty::BackgroundRepeat>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::Font: WebPropertyAnalyzer<EWebProperty::Font>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::FontFamily: WebPropertyAnalyzer<EWebProperty::FontFamily>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::FontSize: WebPropertyAnalyzer<EWebProperty::FontSize>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::FontWeight: WebPropertyAnalyzer<EWebProperty::FontWeight>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::FontStyle: WebPropertyAnalyzer<EWebProperty::FontStyle>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::ListStyle: WebPropertyAnalyzer<EWebProperty::ListStyle>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::ListStyleImage: WebPropertyAnalyzer<EWebProperty::ListStyleImage>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::ListStylePosition: WebPropertyAnalyzer<EWebProperty::ListStylePosition>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::ListStyleType: WebPropertyAnalyzer<EWebProperty::ListStyleType>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                case EWebProperty::ZIndex: WebPropertyAnalyzer<EWebProperty::ZIndex>::ParseValue(_szValue, _eUnitOut, _uiValueOut); break;
                
			}
		}

		static EWebProperty::Type GetAtomicProperty(EWebProperty::Type _eType, EWebPropertyUnit::Type _eUnit, uint32 _uiOffset)
		{
			uint32 uiType = _eType;
			switch(_eType)
			{
				case EWebProperty::AlignContent: uiType = WebPropertyAnalyzer<EWebProperty::AlignContent>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::Margin: uiType = WebPropertyAnalyzer<EWebProperty::Margin>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::MarginTop: uiType = WebPropertyAnalyzer<EWebProperty::MarginTop>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::MarginRight: uiType = WebPropertyAnalyzer<EWebProperty::MarginRight>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::MarginBottom: uiType = WebPropertyAnalyzer<EWebProperty::MarginBottom>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::MarginLeft: uiType = WebPropertyAnalyzer<EWebProperty::MarginLeft>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::Border: uiType = WebPropertyAnalyzer<EWebProperty::Border>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BorderTop: uiType = WebPropertyAnalyzer<EWebProperty::BorderTop>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BorderRight: uiType = WebPropertyAnalyzer<EWebProperty::BorderRight>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BorderBottom: uiType = WebPropertyAnalyzer<EWebProperty::BorderBottom>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BorderLeft: uiType = WebPropertyAnalyzer<EWebProperty::BorderLeft>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BorderColor: uiType = WebPropertyAnalyzer<EWebProperty::BorderColor>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BorderTopColor: uiType = WebPropertyAnalyzer<EWebProperty::BorderTopColor>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BorderRightColor: uiType = WebPropertyAnalyzer<EWebProperty::BorderRightColor>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BorderBottomColor: uiType = WebPropertyAnalyzer<EWebProperty::BorderBottomColor>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BorderLeftColor: uiType = WebPropertyAnalyzer<EWebProperty::BorderLeftColor>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BorderStyle: uiType = WebPropertyAnalyzer<EWebProperty::BorderStyle>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BorderTopStyle: uiType = WebPropertyAnalyzer<EWebProperty::BorderTopStyle>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BorderRightStyle: uiType = WebPropertyAnalyzer<EWebProperty::BorderRightStyle>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BorderBottomStyle: uiType = WebPropertyAnalyzer<EWebProperty::BorderBottomStyle>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BorderLeftStyle: uiType = WebPropertyAnalyzer<EWebProperty::BorderLeftStyle>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BorderWidth: uiType = WebPropertyAnalyzer<EWebProperty::BorderWidth>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BorderTopWidth: uiType = WebPropertyAnalyzer<EWebProperty::BorderTopWidth>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BorderRightWidth: uiType = WebPropertyAnalyzer<EWebProperty::BorderRightWidth>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BorderBottomWidth: uiType = WebPropertyAnalyzer<EWebProperty::BorderBottomWidth>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BorderLeftWidth: uiType = WebPropertyAnalyzer<EWebProperty::BorderLeftWidth>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::Padding: uiType = WebPropertyAnalyzer<EWebProperty::Padding>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::PaddingTop: uiType = WebPropertyAnalyzer<EWebProperty::PaddingTop>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::PaddingRight: uiType = WebPropertyAnalyzer<EWebProperty::PaddingRight>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::PaddingBottom: uiType = WebPropertyAnalyzer<EWebProperty::PaddingBottom>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::PaddingLeft: uiType = WebPropertyAnalyzer<EWebProperty::PaddingLeft>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::Top: uiType = WebPropertyAnalyzer<EWebProperty::Top>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::Right: uiType = WebPropertyAnalyzer<EWebProperty::Right>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::Bottom: uiType = WebPropertyAnalyzer<EWebProperty::Bottom>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::Left: uiType = WebPropertyAnalyzer<EWebProperty::Left>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::Width: uiType = WebPropertyAnalyzer<EWebProperty::Width>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::Height: uiType = WebPropertyAnalyzer<EWebProperty::Height>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::Display: uiType = WebPropertyAnalyzer<EWebProperty::Display>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::Content: uiType = WebPropertyAnalyzer<EWebProperty::Content>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::Color: uiType = WebPropertyAnalyzer<EWebProperty::Color>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::Background: uiType = WebPropertyAnalyzer<EWebProperty::Background>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BackgroundAttachment: uiType = WebPropertyAnalyzer<EWebProperty::BackgroundAttachment>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BackgroundImage: uiType = WebPropertyAnalyzer<EWebProperty::BackgroundImage>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BackgroundColor: uiType = WebPropertyAnalyzer<EWebProperty::BackgroundColor>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::BackgroundRepeat: uiType = WebPropertyAnalyzer<EWebProperty::BackgroundRepeat>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::Font: uiType = WebPropertyAnalyzer<EWebProperty::Font>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::FontFamily: uiType = WebPropertyAnalyzer<EWebProperty::FontFamily>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::FontSize: uiType = WebPropertyAnalyzer<EWebProperty::FontSize>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::FontWeight: uiType = WebPropertyAnalyzer<EWebProperty::FontWeight>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::FontStyle: uiType = WebPropertyAnalyzer<EWebProperty::FontStyle>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::ListStyle: uiType = WebPropertyAnalyzer<EWebProperty::ListStyle>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::ListStyleImage: uiType = WebPropertyAnalyzer<EWebProperty::ListStyleImage>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::ListStylePosition: uiType = WebPropertyAnalyzer<EWebProperty::ListStylePosition>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::ListStyleType: uiType = WebPropertyAnalyzer<EWebProperty::ListStyleType>::GetAtomicProperty(_eUnit); break;
                case EWebProperty::ZIndex: uiType = WebPropertyAnalyzer<EWebProperty::ZIndex>::GetAtomicProperty(_eUnit); break;
                
			}
			
			return (EWebProperty::Type)(uiType + _uiOffset);
		}
		
		static WebComponent* GetOrCreateComponent(WebElement* _pElement, EWebProperty::Type _eType)
		{
			switch(_eType)
			{
				case EWebProperty::AlignContent: return WebPropertyAnalyzer<EWebProperty::AlignContent>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::Margin: return WebPropertyAnalyzer<EWebProperty::Margin>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::MarginTop: return WebPropertyAnalyzer<EWebProperty::MarginTop>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::MarginRight: return WebPropertyAnalyzer<EWebProperty::MarginRight>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::MarginBottom: return WebPropertyAnalyzer<EWebProperty::MarginBottom>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::MarginLeft: return WebPropertyAnalyzer<EWebProperty::MarginLeft>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::Border: return WebPropertyAnalyzer<EWebProperty::Border>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BorderTop: return WebPropertyAnalyzer<EWebProperty::BorderTop>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BorderRight: return WebPropertyAnalyzer<EWebProperty::BorderRight>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BorderBottom: return WebPropertyAnalyzer<EWebProperty::BorderBottom>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BorderLeft: return WebPropertyAnalyzer<EWebProperty::BorderLeft>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BorderColor: return WebPropertyAnalyzer<EWebProperty::BorderColor>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BorderTopColor: return WebPropertyAnalyzer<EWebProperty::BorderTopColor>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BorderRightColor: return WebPropertyAnalyzer<EWebProperty::BorderRightColor>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BorderBottomColor: return WebPropertyAnalyzer<EWebProperty::BorderBottomColor>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BorderLeftColor: return WebPropertyAnalyzer<EWebProperty::BorderLeftColor>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BorderStyle: return WebPropertyAnalyzer<EWebProperty::BorderStyle>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BorderTopStyle: return WebPropertyAnalyzer<EWebProperty::BorderTopStyle>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BorderRightStyle: return WebPropertyAnalyzer<EWebProperty::BorderRightStyle>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BorderBottomStyle: return WebPropertyAnalyzer<EWebProperty::BorderBottomStyle>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BorderLeftStyle: return WebPropertyAnalyzer<EWebProperty::BorderLeftStyle>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BorderWidth: return WebPropertyAnalyzer<EWebProperty::BorderWidth>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BorderTopWidth: return WebPropertyAnalyzer<EWebProperty::BorderTopWidth>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BorderRightWidth: return WebPropertyAnalyzer<EWebProperty::BorderRightWidth>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BorderBottomWidth: return WebPropertyAnalyzer<EWebProperty::BorderBottomWidth>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BorderLeftWidth: return WebPropertyAnalyzer<EWebProperty::BorderLeftWidth>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::Padding: return WebPropertyAnalyzer<EWebProperty::Padding>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::PaddingTop: return WebPropertyAnalyzer<EWebProperty::PaddingTop>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::PaddingRight: return WebPropertyAnalyzer<EWebProperty::PaddingRight>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::PaddingBottom: return WebPropertyAnalyzer<EWebProperty::PaddingBottom>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::PaddingLeft: return WebPropertyAnalyzer<EWebProperty::PaddingLeft>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::Top: return WebPropertyAnalyzer<EWebProperty::Top>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::Right: return WebPropertyAnalyzer<EWebProperty::Right>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::Bottom: return WebPropertyAnalyzer<EWebProperty::Bottom>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::Left: return WebPropertyAnalyzer<EWebProperty::Left>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::Width: return WebPropertyAnalyzer<EWebProperty::Width>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::Height: return WebPropertyAnalyzer<EWebProperty::Height>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::Display: return WebPropertyAnalyzer<EWebProperty::Display>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::Content: return WebPropertyAnalyzer<EWebProperty::Content>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::Color: return WebPropertyAnalyzer<EWebProperty::Color>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::Background: return WebPropertyAnalyzer<EWebProperty::Background>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BackgroundAttachment: return WebPropertyAnalyzer<EWebProperty::BackgroundAttachment>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BackgroundImage: return WebPropertyAnalyzer<EWebProperty::BackgroundImage>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BackgroundColor: return WebPropertyAnalyzer<EWebProperty::BackgroundColor>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::BackgroundRepeat: return WebPropertyAnalyzer<EWebProperty::BackgroundRepeat>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::Font: return WebPropertyAnalyzer<EWebProperty::Font>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::FontFamily: return WebPropertyAnalyzer<EWebProperty::FontFamily>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::FontSize: return WebPropertyAnalyzer<EWebProperty::FontSize>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::FontWeight: return WebPropertyAnalyzer<EWebProperty::FontWeight>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::FontStyle: return WebPropertyAnalyzer<EWebProperty::FontStyle>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::ListStyle: return WebPropertyAnalyzer<EWebProperty::ListStyle>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::ListStyleImage: return WebPropertyAnalyzer<EWebProperty::ListStyleImage>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::ListStylePosition: return WebPropertyAnalyzer<EWebProperty::ListStylePosition>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::ListStyleType: return WebPropertyAnalyzer<EWebProperty::ListStyleType>::GetOrCreateComponent(_pElement); break;
                case EWebProperty::ZIndex: return WebPropertyAnalyzer<EWebProperty::ZIndex>::GetOrCreateComponent(_pElement); break;
                
			}
			
			return NULL;
		}
	};
} } 
#endif