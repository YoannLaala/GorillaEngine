#ifndef _WEB_PROPERTY_HPP_
#define _WEB_PROPERTY_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>
#include <Web/Property/Enum/WebProperty.hpp>
#include <Web/Property/Enum/WebPropertyBackgroundRepeat.hpp>
#include <Web/Property/Enum/WebPropertyBorderStyle.hpp>
#include <Web/Property/Enum/WebPropertyColor.hpp>
#include <Web/Property/Enum/WebPropertyDisplay.hpp>
#include <Web/Property/Enum/WebPropertyFontStyle.hpp>
#include <Web/Property/Enum/WebPropertyFontWeight.hpp>
#include <Web/Property/Enum/WebPropertyListStyle.hpp>
#include <Web/Property/Enum/WebPropertyUnit.hpp>

/******************************************************************************
**	Class Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebProperty
	{
	public:
		WebProperty();
		WebProperty(const WebProperty& _kReference);
		WebProperty(EWebPropertyUnit::Type _eUnit, uint32 _uiValue);
		WebProperty(EWebPropertyUnit::Type _eUnit, int32 _iValue);
		WebProperty(EWebPropertyUnit::Type _eUnit, float32 _fValue);
		WebProperty(EWebPropertyUnit::Type _eUnit, const char* _szValue);
		~WebProperty();

		inline EWebPropertyUnit::Type GetUnit() const { return m_eUnit; }
		inline uint32		GetUInt32() const { return m_uiValue; }
		inline int32		GetInt32() const { return m_iValue; }
		inline float32		GetFloat32() const { return m_fValue; }
		inline const char*	GetString() const { return m_szValue; }

		inline void Set(EWebPropertyUnit::Type _eUnit, uint32 _uiValue) { m_eUnit = _eUnit; m_uiValue = _uiValue; }
		inline void Set(EWebPropertyUnit::Type _eUnit, int32 _iValue) { m_eUnit = _eUnit; m_iValue = _iValue; }
		inline void Set(EWebPropertyUnit::Type _eUnit, float32 _fValue) { m_eUnit = _eUnit; m_fValue = _fValue; }
		void Set(EWebPropertyUnit::Type _eUnit, const char* _szValue);

	private:
		EWebPropertyUnit::Type m_eUnit;
		union
		{
			uint32 m_uiValue;
			int32 m_iValue;
			float32 m_fValue;
			char* m_szValue;
		};
	};
}}
#endif