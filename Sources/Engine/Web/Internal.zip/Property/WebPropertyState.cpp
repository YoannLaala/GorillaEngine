/******************************************************************************
**	Includes
******************************************************************************/
#include "WebPropertyState.hpp"

/******************************************************************************
**	Class Definition
******************************************************************************/
namespace Gorilla { namespace Web
{
	//!	@brief		Constructor
	//!	@date		2015-12-29
	WebPropertyState::WebPropertyState()
		: m_pStyle(NULL)
		, m_pProperty(NULL)
		, m_eSelector(EWebSelector::TagInherited)
	{
		// Nothing to do
	}

	//!	@brief		Destructor
	//!	@date		2015-12-29
	WebPropertyState::~WebPropertyState()
	{
		// Nothing to do
	}
}}