/******************************************************************************
**	Includes
******************************************************************************/
#include "WebProperty.hpp"

/******************************************************************************
**	Class Definition
******************************************************************************/
namespace Gorilla { namespace Web
{			
	//!	@brief		Constructor
	//!	@date		2015-12-29
	WebProperty::WebProperty()
		: m_eUnit(EWebPropertyUnit::String)
		, m_szValue(NULL)
	{
		// Nothing to do
	}

	//!	@brief		Constructor
	//!	@date		2015-12-29
	WebProperty::WebProperty(const WebProperty& _kReference)
		: m_eUnit(_kReference.GetUnit())
	{
		switch(_kReference.GetUnit())
		{
			case EWebPropertyUnit::String:
			{
				if(_kReference.GetString())
				{
					Set(EWebPropertyUnit::String, _kReference.GetString());
				}
				break;
			}

			default:
			{
				memcpy_s(this, sizeof(WebProperty), &_kReference, sizeof(WebProperty));
				break;
			}
		}
	}

	//!	@brief		Constructor
	//!	@date		2015-12-29
	WebProperty::WebProperty(EWebPropertyUnit::Type _eUnit, uint32 _uiValue)
	{
		Set(_eUnit, _uiValue);
	}

	//!	@brief		Constructor
	//!	@date		2015-12-29
	WebProperty::WebProperty(EWebPropertyUnit::Type _eUnit, int32 _iValue)
	{
		Set(_eUnit, _iValue);
	}

	//!	@brief		Constructor
	//!	@date		2015-12-29
	WebProperty::WebProperty(EWebPropertyUnit::Type _eUnit, float32 _fValue)
	{
		Set(_eUnit, _fValue);
	}

	//!	@brief		Constructor
	//!	@date		2015-12-29
	WebProperty::WebProperty(EWebPropertyUnit::Type _eUnit, const char* _szValue)
	{
		Set(_eUnit, _szValue);
	}

	//!	@brief		Destructor
	//!	@date		2015-12-29
	WebProperty::~WebProperty()
	{
		if(m_eUnit == EWebPropertyUnit::String)
		{
			SAFE_DELETE(m_szValue);
		}
	}

	//!	@brief		Set
	//!	@date		2015-12-29
	void WebProperty::Set(EWebPropertyUnit::Type _eUnit, const char* _szValue) 
	{ 
		m_eUnit = _eUnit; 
		size_t iSize = strlen(_szValue);
		if(iSize)
		{
			m_szValue = new char[iSize+1];
			memcpy_s(m_szValue, iSize, _szValue, iSize);
			m_szValue[iSize] = 0;
		}
	}
}}