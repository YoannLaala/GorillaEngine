/******************************************************************************
**	Includes
******************************************************************************/
#include "WebRequest.hpp"

#include <Web/Document/WebDocument.hpp>

/******************************************************************************
**	Class Definition
******************************************************************************/
namespace Gorilla { namespace Web
{
	//!	@brief		Constructor
	//!	@date		2015-12-29
	WebRequest::WebRequest()
		: m_pSource(NULL)
		, m_pDocument(NULL)
	{
		// Nothing to do
	}
		
	//!	@brief		Destructor
	//!	@date		2015-12-29
	WebRequest::~WebRequest()
	{
		// Nothing to do
	}

	//!	@brief		Initialize
	//!	@date		2015-12-29
	void WebRequest::Initialize(WebDocument* _pDocument, const char* _szUrl, WebPage* _pSource /*= NULL*/)
	{
		m_pSource = _pSource;
		m_pDocument = _pDocument;
		m_sUrl = _szUrl;
	}
}}
