///******************************************************************************
//**	Includes
//******************************************************************************/
//#include "WebElementText.hpp"
//
//#include <Core/String/String16.hpp>
//#include <Core/String/StringHelper.hpp>
//
//#include <Component/GUI/Web/WebProperty.hpp>
//
//#include <Renderer/Canvas/CanvasContext.hpp>
//#include <Renderer/Canvas/Text/CanvasText.hpp>
//
///******************************************************************************
//**	Class Definition
//******************************************************************************/
//namespace Gorilla { namespace Web
//{
//	//!	@brief		Constructor
//	//!	@date		2015-12-29
//	WebElementText::WebElementText()
//		: m_pText(NULL)
//		, m_pFont(NULL)
//		, m_pColor(NULL)
//	{
//		// Nothing to do
//	}
//
//	//!	@brief		Destructor
//	//!	@date		2015-12-29
//	WebElementText::~WebElementText()
//	{
//		// Nothing to do
//	}
//
//	//!	@brief		Draw
//	//!	@date		2015-12-29
//	static Vector<String> vText;
//	static Vector<String> vFontId;
//
//	void WebElementText::Draw(Renderer::CanvasContext* /*_pContext*/, Renderer::CanvasSurface* /*_pSurface*/)
//	{ 
//		//_pContext->DrawText(_pSurface, (uint32)m_vPosition.GetX(), (uint32)m_vPosition.GetY(), m_pText, m_pColor);
//		//WebElement::Draw(_pContext, _pSurface);
//	}
//}}