#ifndef _WEB_ELEMENT_IMAGE_HPP_
#define _WEB_ELEMENT_IMAGE_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>
#include <Web/Element/WebElement.hpp>

/******************************************************************************
**	Class Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebElementImage : public WebElement 
	{
	public:
		WebElementImage();
		~WebElementImage();

		virtual void AddAttribute(const char* _szName, const char* _szValue) override;
	};
}}
#endif