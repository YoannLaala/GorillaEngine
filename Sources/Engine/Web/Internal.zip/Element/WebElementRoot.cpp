/******************************************************************************
**	Includes
******************************************************************************/
#include "WebElementRoot.hpp"
#include <Web/Element/WebElementStyle.hpp>

/******************************************************************************
**	Class Definition
******************************************************************************/
namespace Gorilla { namespace Web
{
	//!	@brief		Constructor
	//!	@date		2015-12-29
	WebElementRoot::WebElementRoot()
	{
		// Nothing to do
	}

	//!	@brief		Destructor
	//!	@date		2015-12-29
	WebElementRoot::~WebElementRoot()
	{
		// Nothing to do
	}

	//!	@brief		CreateStyle
	//!	@date		2015-12-29
	WebElementStyle* WebElementRoot::CreateStyle() 
	{ 
		WebElementStyle* pStyle = new WebElementStyle(); 
		m_vStyle.Add(pStyle); 
		
		return pStyle; 
	}

	//!	@brief		ApplyStyle
	//!	@date		2015-12-29
	void WebElementRoot::ApplyStyle()
	{
		/*const uint32 uiStyleCount = m_vStyle.GetSize();
		for(uint32 uiStyle = 0; uiStyle < uiStyleCount; ++uiStyle)
		{
			WebElementStyle* pStyle = m_vStyle[uiStyle];
			pStyle->Apply(this);
		}*/
	}

	//!	@brief		SetScroll
	//!	@date		2015-12-29
	void WebElementRoot::SetScroll(float32 _fScrollX, float32 _fScrollY)
	{ 
		WebProperty kLeftProperty(EWebPropertyUnit::Pixel, -_fScrollX);
		WebProperty kTopProperty(EWebPropertyUnit::Pixel, -_fScrollY);

		// Draw all children;
		/*const uint32 uiElementCount = m_vElement.GetSize();
		for(uint32 uiElement = 0; uiElement < uiElementCount; ++uiElement)
		{
			WebElement* pElement = m_vElement[uiElement];
			pElement->OnPropertyChanged(EWebProperty::Left, &kLeftProperty);
			pElement->OnPropertyChanged(EWebProperty::Top, &kTopProperty);
		}*/
	}

	//!	@brief		Draw
	//!	@date		2015-12-29
	/*void WebElementRoot::Draw(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface)
	{ 
		// Draw all children;
		const uint32 uiElementCount = m_vElement.GetSize();
		for(uint32 uiElement = 0; uiElement < uiElementCount; ++uiElement)
		{
			WebElement* pElement = m_vElement[uiElement];
			pElement->Draw(_pContext, _pSurface);
		}
	}*/
}}