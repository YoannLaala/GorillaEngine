#ifndef _WEB_ELEMENT_HPP_
#define _WEB_ELEMENT_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>

#include <Web/Element/Enum/WebElement.hpp>
#include <Web/Property/WebProperty.hpp>
#include <Web/Component/WebComponent.hpp>

/******************************************************************************
**	Define
******************************************************************************/
#define DEFAULT_FONT_FAMILY		"Arial"
#define DEFAULT_FONT_SIZE		14.0f
#define DEFAULT_FONT_WEIGHT		Renderer::EFontWeight::Normal
#define DEFAULT_FONT_STYLE		Renderer::EFontStyle::Normal

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebPage;
	class WebElementStyle;
	class WebPropertyState;
	class WebComponentNode;
}}

namespace Gorilla { namespace Renderer
{
	class CanvasContext;
	class CanvasSurface;
}}

/******************************************************************************
**	Class Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebElement
	{
		friend class WebPage;
		friend class WebComponent;
		friend class WebComponentNode;

	public:
		struct EFlag
		{
			enum Type : uint8
			{
				Changed				= 0x01,
				LayoutChanged		= 0x02,
			};
		};

		WebElement();
		~WebElement();

		void							Update();

		// Identifier
		inline uint32					GetTagId() const { return m_uiTagId; }
		inline uint32					GetId() const { return m_uiId; }
		inline bool						HasClassId(uint32 _uiClassId) const { return m_vClassId.Find(_uiClassId) != (uint32)-1; }
		void							AddClass(const char* _szName);
		void							RemoveClass(const char* _szName);

		// Specific Attribute handler
		virtual void					AddAttribute(const char* _szName, const char* _szValue);

		// Hierarchy
		template <class T>
		T*								AddElement();
		void							AddElement(WebElement* _pElement);

		inline uint32					GetChildCount() const { return m_vElement.GetSize(); }
		inline WebElement*				GetChild(uint32 _uiIndex) { return m_vElement[_uiIndex]; }
		
		void							Find(const WebSelector& _kSelector, Vector<WebElement*>& _vElementOut);

		inline WebPage*					GetPage	() { return m_pPage; }
		inline const WebPage*			GetPage() const { return m_pPage; }

		inline WebElement*				GetParent() { return m_pParent; }
		inline const WebElement*		GetParent() const { return m_pParent; }

		// Component
		template <class T>
		inline bool						HasComponent() const { return GetComponent<T>() != NULL; }

		template <class T>
		T*								GetComponent();

		template <class T>
		T*								GetOrCreateComponent();

		// Property State
		inline bool						HasPropertyState(EWebProperty::Type _eProperty) const { return m_aPropertyStateIndex[_eProperty] != (uint8)-1; }
		WebPropertyState*				GetPropertyState(EWebProperty::Type _eProperty);
		inline const WebPropertyState*	GetPropertyState(EWebProperty::Type _eProperty) const { return const_cast<WebElement*>(this)->GetPropertyState(_eProperty); }
		WebPropertyState*				GetOrCreatePropertyState(EWebProperty::Type _eProperty);

		// Property Owner
		bool							IsPropertyAvailable(EWebProperty::Type _eProperty, EWebSelector::Type _eSelector) const;
		bool							IsProperyOwner(EWebProperty::Type _eProperty, const WebElementStyle* _pStyle) const;
		void							SetPropertyOwner(EWebProperty::Type _eProperty, EWebSelector::Type _eSelector, const WebElementStyle* _pStyle);

		// PropertyChanged
		void							SetProperty(EWebProperty::Type _eProperty, const WebProperty* _pProperty);
		const WebProperty*				GetPropertyChanged(EWebProperty::Type _eProperty);

	private:
		void							OnChanged(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface);

	private:
		inline void						SetPage	(WebPage* _pPage) { m_pPage = _pPage; }
		inline void						SetParent(WebElement* _pParent) { m_pParent = _pParent; }
		inline void						SetTagId(uint32 _uiTagId) { m_uiTagId = _uiTagId; }

		// Flag
		inline bool						HasFlag		(EFlag::Type _eFlag) const { return (m_eFlag & _eFlag) != 0; }
		inline void						SetFlag		(EFlag::Type _eFlag) { m_eFlag |= _eFlag; }
		inline void						RemoveFlag	(EFlag::Type _eFlag) { m_eFlag &= ~_eFlag; }

	private:
		uint8							m_aComponentIndex[EWebComponent::Count];
		uint8							m_aPropertyStateIndex[EWebProperty::Count];

		Vector<WebElement*>				m_vElement;
		Vector<WebComponent*>			m_vComponent;
		Vector<WebPropertyState>		m_vPropertyState;
		Vector<uint32>					m_vClassId;
		WebPage*						m_pPage;
		WebElement*						m_pParent;
		uint32							m_uiTagId;
		uint32							m_uiId;
		uint8							m_eFlag;
	};

	// Hierarchy
	template <class T>
	T* WebElement::AddElement()
	{
		T* pElement = new T();
		AddElement(pElement);

		return pElement;
	}

	//!	@brief		GetComponent
	//!	@date		2015-12-29
	template <class T>
	T* WebElement::GetComponent()
	{
		uint8 uiIndex = m_aComponentIndex[T::RTTI::GetType()];
		if(uiIndex != (uint8)-1)
		{
			return static_cast<T*>(m_vComponent[uiIndex]);
		}

		return NULL;
	}

	//!	@brief		GetOrCreateComponent
	//!	@date		2015-12-29
	template <class T>
	T* WebElement::GetOrCreateComponent()
	{
		T* pComponent = GetComponent<T>();
		if(!pComponent)
		{
			// Allocate component
			pComponent = new T();
			pComponent->SetElement(this);
			
			// Get current Index
			uint8 eType = T::RTTI::GetType();
			uint8 uiIndex = (uint8)m_vComponent.GetSize();
			m_vComponent.Add();	// Reserve memory

			// Sort if needed
			for(uint8 uiComponent = 0; uiComponent < uiIndex; ++uiComponent)
			{
				WebComponent* pSortedComponent = m_vComponent[uiComponent];
				if(eType < pSortedComponent->GetType())
				{
					// Move those with inferior priority to the right
					uint8 uiMoveByte = (uiIndex - uiComponent) * sizeof(T*);
					memcpy_s(&m_vComponent[uiComponent+1], uiMoveByte, &m_vComponent[uiComponent], uiMoveByte);
					
					// Update Component Index
					for(uint8 uiComponentIndex = uiComponent+1; uiComponentIndex < uiIndex+1; ++uiComponentIndex)
					{
						pSortedComponent = m_vComponent[uiComponentIndex];
						++m_aComponentIndex[pSortedComponent->GetType()];
					}
					uiIndex = uiComponent;

					break;
				}
			}

			// Set Index & Component to proper location
			m_aComponentIndex[eType] = uiIndex;
			m_vComponent[uiIndex] = pComponent;			
		}

		return pComponent;
	}

	//class WebComponentList : public WebComponent
	//{
	//public:
	//	WebComponentList()
	//		: m_pGeometry(NULL)
	//		, m_pColor(NULL)
	//	{
	//		// Nothing to do
	//	}

	//	~WebComponentList()
	//	{
	//		// Nothing to do
	//	}

	//	static EWebComponent::Type GetType() { return EWebComponent::Elipse; }

	//protected:
	//	void Prepare(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface) override
	//	{ 
	//		WebElement* pElement = GetElement();

	//		// Prepare Style
	//		const WebProperty* pStyleProperty = pElement->GetPropertyChanged(EWebProperty::ListStyleType);
	//		if(!m_pGeometry || pStyleProperty)
	//		{
	//			_pContext->DestroyResource(m_pGeometry);

	//			m_eStyle = pStyleProperty ? (EWebPropertyListStyle::Type)pStyleProperty->GetUInt32() : EWebPropertyListStyle::Disc;
	//			switch(m_eStyle)
	//			{
	//				case EWebPropertyListStyle::Square:
	//				{
	//					m_pGeometry = WebResourceFactory::GetRectangle(_pContext, _pSurface, 2.0f, 2.0f);
	//					break;
	//				}

	//				case EWebPropertyListStyle::Circle:
	//				case EWebPropertyListStyle::Disc:
	//				{
	//					m_pGeometry = WebResourceFactory::GetElipse(_pContext, _pSurface, 1.0f, 1.0f);
	//					break;
	//				}
	//			}
	//		}

	//		// Prepare Color
	//		if(!m_pColor)
	//		{
	//			m_pColor = WebResourceFactory::GetBrush(_pContext, _pSurface, Renderer::Color::Black);
	//		}

	//		WebComponent::Prepare(_pContext, _pSurface);
	//	}

	//	void Draw(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface) override
	//	{ 
	//		WebElement* pElement = GetElement();
	//		const WebComponentNode* pCpnNode = pElement->GetComponent<WebComponentNode>();

	//		switch(m_eStyle)
	//		{
	//			case EWebPropertyListStyle::Square:
	//			case EWebPropertyListStyle::Disc:
	//			{
	//				_pContext->FillGeometry(_pSurface, m_pGeometry, m_pColor, pCpnNode->GetPositionLeft(), pCpnNode->GetPositionTop());
	//				break;
	//			}

	//			case EWebPropertyListStyle::Circle:
	//			{
	//				_pContext->DrawGeometry(_pSurface, m_pGeometry, m_pColor, pCpnNode->GetPositionLeft(), pCpnNode->GetPositionTop());
	//				break;
	//			}
	//		}
	//	}

	//private:
	//	Renderer::CanvasGeometry* m_pGeometry;
	//	Renderer::CanvasBrush* m_pColor;
	//	EWebPropertyListStyle::Type m_eStyle;
	//};

	

	//class WebComponentBorder : public WebComponent
	//{
	//public:
	//	WebComponentBorder()
	//		: m_vWidth(0.0f, 0.0f, 0.0f, 0.0f)
	//	{
	//		memset(&m_aColor, 0, sizeof(Renderer::CanvasBrush*) * 4);
	//		memset(&m_aStyle, 0, sizeof(Renderer::CanvasStyle*) * 4);
	//	}

	//	~WebComponentBorder()
	//	{
	//		// Nothing to do
	//	}

	//	static EWebComponent::Type GetType() { return EWebComponent::Border; }

	//	virtual void OnPropertyChanged(EWebProperty::Type _eProperty, const WebProperty* _pProperty)
	//	{
	//		switch(_eProperty)
	//		{
	//			case EWebProperty::BorderWidth:
	//			{
	//				float32 fWidth = _pProperty->GetFloat32();
	//				m_vWidth.Set(fWidth, fWidth, fWidth, fWidth);
	//				break;
	//			}

	//			case EWebProperty::BorderTopWidth:
	//			{
	//				m_vWidth.SetX(_pProperty->GetFloat32());
	//				break;
	//			}

	//			case EWebProperty::BorderRightWidth:
	//			{
	//				m_vWidth.SetY(_pProperty->GetFloat32());
	//				break;
	//			}

	//			case EWebProperty::BorderBottomWidth:
	//			{
	//				m_vWidth.SetZ(_pProperty->GetFloat32());
	//				break;
	//			}

	//			case EWebProperty::BorderLeftWidth:
	//			{
	//				m_vWidth.SetW(_pProperty->GetFloat32());
	//				break;
	//			}
	//		}

	//		WebComponent::OnPropertyChanged(_eProperty, _pProperty);
	//	}

	//	void Prepare(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface) override
	//	{ 
	//		WebElement* pElement = GetElement();
	//		for(uint32 uiBorder = 0; uiBorder < 4; ++uiBorder)
	//		{
	//			// Prepare each border needed
	//			// Start from top - right - bottom - left
	//			uint8 eBorderColor = EWebProperty::BorderTopColor;
	//			uint8 eBorderStyle = EWebProperty::BorderTopStyle;
	//			float32 fWidth = m_vWidth[uiBorder];
	//			if(fWidth > 0.0f)
	//			{
	//				// Prepare Color
	//				_pContext->DestroyResource(m_aColor[uiBorder]);
	//				const WebProperty* pColorProperty = pElement->GetPropertyChanged((EWebProperty::Type)eBorderColor++);
	//				Renderer::Color kColor = pColorProperty ? pColorProperty->GetUInt32() : Renderer::Color::Black;
	//				m_aColor[uiBorder] = WebResourceFactory::GetBrush(_pContext, _pSurface, kColor);

	//				// Prepare Style
	//				_pContext->DestroyResource(m_aStyle[uiBorder]);
	//				const WebProperty* pStyleProperty = pElement->GetPropertyChanged((EWebProperty::Type)eBorderStyle++);
	//				Renderer::ELineStyle::Type eLine = pStyleProperty ? (Renderer::ELineStyle::Type)pStyleProperty->GetUInt32() : Renderer::ELineStyle::Solid;
	//				m_aStyle[uiBorder] = WebResourceFactory::GetStyle(_pContext, _pSurface, eLine);
	//			}
	//		}

	//		WebComponent::Prepare(_pContext, _pSurface);
	//	}

	//	void ComputeLinePoint(EWebProperty::Type _eProperty, float32 _fLeft, float32 _fTop, float32 _fWidth, float32 _fHeight, Math::Vector2& _vPointA, Math::Vector2& _vPointB)
	//	{
	//		switch(_eProperty)
	//		{
	//			case EWebProperty::BorderTop:
	//			{
	//				_vPointA.Set(_fLeft, _fTop);
	//				_vPointB.Set(_fLeft + _fWidth, _fTop);
	//				break;
	//			};

	//			case EWebProperty::BorderRight:
	//			{
	//				_vPointA.Set(_fLeft + _fWidth, _fTop);
	//				_vPointB.Set(_fLeft + _fWidth, _fTop + _fHeight);
	//				break;
	//			};

	//			case EWebProperty::BorderBottom:
	//			{
	//				_vPointA.Set(_fLeft + _fWidth, _fTop + _fHeight);
	//				_vPointB.Set(_fLeft, _fTop + _fHeight);
	//				break;
	//			};

	//			case EWebProperty::BorderLeft:
	//			{
	//				_vPointA.Set(_fLeft, _fTop + _fHeight);
	//				_vPointB.Set(_fLeft, _fTop);
	//				break;
	//			};
	//		}
	//	}

	//	void Draw(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface) override
	//	{ 
	//		const WebComponentNode* pCpnNode = GetElement()->GetComponent<WebComponentNode>();

	//		// Draw each border as line
	//		Math::Vector2 vPointA, vPointB;
	//		for(uint32 uiBorder = 0; uiBorder < 4; ++uiBorder)
	//		{
	//			Renderer::CanvasBrush* pColor = m_aColor[uiBorder];
	//			if(pColor)
	//			{
	//				ComputeLinePoint((EWebProperty::Type)(EWebProperty::BorderTop + uiBorder), pCpnNode->GetPositionLeft(), pCpnNode->GetPositionTop(), pCpnNode->GetWidth(), pCpnNode->GetHeight(), vPointA, vPointB);
	//				_pContext->DrawLine(_pSurface, pColor, vPointA.GetX(), vPointA.GetY(), vPointB.GetX(), vPointB.GetY(), m_aStyle[uiBorder], m_vWidth[uiBorder]);
	//			}
	//		}
	//	}

	//private:
	//	Renderer::CanvasBrush* m_aColor[4];
	//	Renderer::CanvasStyle* m_aStyle[4];
	//	Math::Vector4 m_vWidth;
	//};

	class WebPropertyValueComputer
	{
	public:
		static uint32 Enum(WebElement* _pElement, EWebProperty::Type _eProperty)
		{
			const WebProperty* pProperty = _pElement->GetPropertyChanged(_eProperty);
			return pProperty ? pProperty->GetUInt32() : 0;
		}

		static float32 Size(const WebProperty* pProperty, float32 _fValueDefault = 0.0f, float32 _fValueMin = -FLT_MAX, float32 _fValueMax = FLT_MAX)
		{
			float32 fValue = _fValueDefault;
			switch(pProperty->GetUnit())
			{
				case EWebPropertyUnit::Pixel:
				{
					fValue = Math::Clamp(pProperty->GetFloat32(), _fValueMin, _fValueMax);
					break;
				}

				// 1in = 2.54mm
				case EWebPropertyUnit::Centimeter:
				{
					fValue = Math::Clamp(pProperty->GetFloat32() * (96.0f / 2.54f), _fValueMin, _fValueMax);
					break;
				}

				// 1in = 25.4mm
				case EWebPropertyUnit::Millimeter:
				{
					fValue = Math::Clamp(pProperty->GetFloat32() * (96.0f / 25.4f), _fValueMin, _fValueMax);
					break;
				}

				// 1in = 96px
				case EWebPropertyUnit::Inch:
				{
					fValue = Math::Clamp(pProperty->GetFloat32() * 96.0f, _fValueMin, _fValueMax);
					break;
				}

				// 1pt = 1/72 of 1in
				case EWebPropertyUnit::Point:
				{
					fValue = Math::Clamp(pProperty->GetFloat32() * (96.0f / 72.0f), _fValueMin, _fValueMax);
					break;
				}

				// 1pc = 12 pt
				case EWebPropertyUnit::Pica:
				{
					fValue = Math::Clamp(12.0f * (pProperty->GetFloat32() * (96.0f / 72.0f)), _fValueMin, _fValueMax);
					break;
				}

				case EWebPropertyUnit::Percentage:
				{
					fValue = pProperty->GetFloat32() * 0.01f * _fValueMax;
					break;
				}

				case EWebPropertyUnit::Em:
				{
					fValue = pProperty->GetFloat32() * DEFAULT_FONT_SIZE;
					break;
				}
			}

			return fValue;
		}
	};
}}
#endif