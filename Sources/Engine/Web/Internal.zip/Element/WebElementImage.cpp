/******************************************************************************
**	Includes
******************************************************************************/
#include "WebElementImage.hpp"

/******************************************************************************
**	Class Definition
******************************************************************************/
namespace Gorilla { namespace Web
{
	//!	@brief		Constructor
	//!	@date		2015-12-29
	WebElementImage::WebElementImage()
	{
		// Nothing to do
	}

	//!	@brief		Destructor
	//!	@date		2015-12-29
	WebElementImage::~WebElementImage()
	{
		// Nothing to do
	}

	//!	@brief		AddAttribute
	//!	@date		2015-12-29
	void WebElementImage::AddAttribute(const char* /*_szName*/, const char* /*_szValue*/)
	{
		// Source
		/*if(_strnicmp(_szName, "src", 3) == 0)
		{
			m_sFilePath = _szValue;
			return;
		}

		WebElement::AddAttribute(_szName, _szValue);*/
	}
}}