/******************************************************************************
**	Includes
******************************************************************************/
#include "WebElementStyle.hpp"

/******************************************************************************
**	Class Definition
******************************************************************************/
namespace Gorilla { namespace Web
{
	//!	@brief		Constructor
	//!	@date		2015-12-29
	WebElementStyle::WebElementStyle()
	{
		// Nothing to do
	}


	//!	@brief		Destructor
	//!	@date		2015-12-29
	WebElementStyle::~WebElementStyle()
	{
		// Nothing to do
	}

	//!	@brief		GetProperty
	//!	@date		2015-12-29
	WebProperty* WebElementStyle::GetProperty(const char* _szName)
	{
		uint32 uiPropertyId = Identifier::Compute(_szName);
		HashMap<uint32, WebProperty>::Node* pNode = m_mProperty.Find(uiPropertyId);
		if(pNode)
		{
			return &pNode->GetValue();
		}

		return NULL;
	}

	//!	@brief		AddProperty
	//!	@date		2015-12-29
	WebProperty& WebElementStyle::AddProperty(EWebProperty::Type _eProperty)
	{
		HashMap<uint32, WebProperty>::Node* pNode = m_mProperty.Find(_eProperty);
		if(!pNode)
		{
			pNode = m_mProperty.Add(_eProperty);
		}

		return pNode->GetValue();
	}

	//!	@brief		RemoveProperty
	//!	@date		2015-12-29
	void WebElementStyle::RemoveProperty(const char* _szName)
	{
		uint32 uiPropertyId = Identifier::Compute(_szName);
		m_mProperty.Remove(uiPropertyId);
	}
	
	//!	@brief		ApplyOn
	//!	@date		2015-12-29
	void WebElementStyle::ApplyOn(WebElement* _pElement) 
	{ 
		// Element Style
		if(m_vSelector.IsEmpty())
		{
			ApplyAllProperty(_pElement, EWebSelector::Element);
			return;
		}

		// Get all Element for each selector available
		const uint32 uiSelectorCount = m_vSelector.GetSize();
		for(uint32 uiSelector = 0; uiSelector < uiSelectorCount; ++uiSelector)
		{
			const WebSelector& kSelector = m_vSelector[uiSelector];
			_pElement->Find(kSelector, m_vElement);
				
			// Register all element found with the proper selector
			const uint32 uiElementCount = m_vElement.GetSize();
			for(uint32 uiElement = 0; uiElement < uiElementCount; ++uiElement)
			{
				WebElement* pElementFound = m_vElement[uiElement];
				ApplyAllProperty(pElementFound, kSelector.GetIdType());
			};
		}
	}

	//!	@brief		ApplyAllProperty
	//!	@date		2015-12-29
	void WebElementStyle::ApplyAllProperty(WebElement* _pElement, EWebSelector::Type _eSelector) 
	{ 
		HashMap<uint32, WebProperty>::Iterator itProperty = m_mProperty.GetFirst();
		HashMap<uint32, WebProperty>::Iterator itPropertyLast = m_mProperty.GetLast();
		while(itProperty != itPropertyLast)
		{
			// Property already owned by a style with more priority
			EWebProperty::Type eProperty = (EWebProperty::Type)itProperty->GetKey();
			if(_pElement->IsPropertyAvailable(eProperty, _eSelector))
			{
				_pElement->SetPropertyOwner(eProperty, _eSelector, this);
				_pElement->SetProperty(eProperty, &itProperty->GetValue());
			}

			++itProperty;
		}

		// Compute child Selector
		EWebSelector::Type eChildSelector = _eSelector;
		if(eChildSelector > EWebSelector::ElementInherited)
		{
			eChildSelector = (EWebSelector::Type)(EWebSelector::ClassInherited + (_eSelector - EWebSelector::Class)); // Tranform selector into selector inherited
		}
		else if(eChildSelector == EWebSelector::Tag)
		{
			eChildSelector = EWebSelector::TagInherited;
		}

		// Apply it on all children
		uint32 uiChildCount = _pElement->GetChildCount();
		for(uint32 uiChild = 0; uiChild < uiChildCount; ++uiChild)
		{
			WebElement* pChild = _pElement->GetChild(uiChild);
			ApplyAllProperty(pChild, eChildSelector);
		}
	}

	//!	@brief		NotifyPropertyChanged
	//!	@date		2015-12-29
	void WebElementStyle::NotifyPropertyChanged(EWebProperty::Type _eProperty, const WebProperty* _pProperty)
	{
		// Notify all Elements
		const uint32 uiElementCount = m_vElement.GetSize();
		for(uint32 uiElement = 0; uiElement < uiElementCount; ++uiElement)
		{
			WebElement* pElement = m_vElement[uiElement];
			NotifyPropertyChanged(_eProperty, _pProperty, pElement);
		}
	}

	//!	@brief		NotifyPropertyChanged
	//!	@date		2015-12-29
	void WebElementStyle::NotifyPropertyChanged(EWebProperty::Type _eProperty, const WebProperty* _pProperty, WebElement* _pElement)
	{
		if(_pElement->IsProperyOwner(_eProperty, this))
		{
			_pElement->SetProperty(_eProperty, _pProperty);
		}

		// Apply it on all children
		uint32 uiChildCount = _pElement->GetChildCount();
		for(uint32 uiChild = 0; uiChild < uiChildCount; ++uiChild)
		{
			WebElement* pChild = _pElement->GetChild(uiChild);
			NotifyPropertyChanged(_eProperty, _pProperty, pChild);
		}
	}
}}