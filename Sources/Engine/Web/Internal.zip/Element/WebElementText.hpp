#ifndef _WEB_ELEMENT_TEXT_HPP_
#define _WEB_ELEMENT_TEXT_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>
#include <Web/Element/WebElement.hpp>

/******************************************************************************
**	Class Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	//class WebFont
	//{
	//	WebFont()
	//		: m_sFamily("Arial")
	//		, m_pFont(NULL)
	//		, m_fSize(12.0f)
	//		, m_uiWeight(Renderer::EWeight::Normal)
	//		, m_eStyle(Renderer::EStyle::Normal)
	//	{
	//		// Nothing to do
	//	}

	//	~WebFont()
	//	{
	//		// Nothing to do
	//	}

	//public:
	//	inline void SetFamily(const char* _szName) { m_sFamily = _szName; }
	//	inline void SetSize(float32 _fSize) { m_fSize = _fSize; }
	//	inline void SetWeight(uint32 _uiWeight) { m_uiWeight = _uiWeight; }
	//	inline void SetStyle(Renderer::EStyle::Type _eStyle) { m_eStyle = _eStyle; }

	//private:
	//	String m_sFamily;
	//	Renderer::CanvasFont* m_pFont;
	//	float32 m_fSize;
	//	uint32 m_uiWeight;
	//	Renderer::EStyle::Type m_eStyle;
	//};

//	class WebElementText : public WebElement 
//	{
//	public:
//		WebElementText();
//		~WebElementText();
//
//		virtual void Draw(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface) override;
//
////		virtual void OnPropertyChanged(EWebProperty::Type _eProperty, const WebProperty* _pProperty) override
////		{
////			switch(_eProperty)
////			{
////				case EWebProperty::FontFamily:
////				case EWebProperty::FontSize:
////				case EWebProperty::FontWeight:
////				case EWebProperty::FontStyle:
////				{
////					m_pFont->SetSize(_pProperty->GetFloat32());
////					break;
////				};
////
////				case EWebProperty::FontStyle:
////				{
////}
////
////				case EWebProperty::Color:
////				{
////					//m_pFont->SetStyle((Renderer::EStyle::Type)_pProperty->GetInt32());
////					break;
////				};
////			}
////
////			WebElement::OnPropertyChanged(_eProperty, _pProperty);
////		}
//
//	private:
//		Renderer::CanvasText* m_pText;
//		Renderer::CanvasFont* m_pFont;
//		Renderer::CanvasBrush* m_pColor;
//	};
}}
#endif