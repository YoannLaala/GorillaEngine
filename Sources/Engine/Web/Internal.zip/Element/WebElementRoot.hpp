#ifndef _WEB_ELEMENT_ROOT_HPP_
#define _WEB_ELEMENT_ROOT_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>
#include <Web/Element/WebElement.hpp>

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebElementStyle;
}}

/******************************************************************************
**	Class Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebElementRoot : public WebElement
	{
	public:
		WebElementRoot();
		~WebElementRoot();

		WebElementStyle*	CreateStyle();
		void				ApplyStyle();

		void				SetScroll(float32 _fScrollX, float32 _fScrollY);

	private:
		Vector<WebElementStyle*> m_vStyle;
	};
}}
#endif