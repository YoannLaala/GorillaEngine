#ifndef _WEB_ELEMENT_STYLE_HPP_
#define _WEB_ELEMENT_STYLE_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>
#include <Web/WebSelector.hpp>
#include <Web/Property/WebProperty.hpp>

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{	
	class WebStyle;
}}

/******************************************************************************
**	Class Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebElementStyle
	{
		friend class WebStyle;

	public:
		WebElementStyle();
		~WebElementStyle();

		WebProperty*	GetProperty(const char* _szName);
		WebProperty&	AddProperty(EWebProperty::Type _eProperty);
		void			RemoveProperty(const char* _szName);

		void			ApplyOn(WebElement* _pElement) ;

	protected:
		WebSelector& AddSelector() { return m_vSelector.Add(); }

		void ApplyAllProperty(WebElement* _pElement, EWebSelector::Type _eSelector);
		void WebElementStyle::NotifyPropertyChanged(EWebProperty::Type _eProperty, const WebProperty* _pProperty);
		void WebElementStyle::NotifyPropertyChanged(EWebProperty::Type _eProperty, const WebProperty* _pProperty, WebElement* _pElement);

	private:
		HashMap<uint32, WebProperty> m_mProperty;
		Vector<WebElement*> m_vElement;
		Vector<WebSelector> m_vSelector;
	};
}}
#endif