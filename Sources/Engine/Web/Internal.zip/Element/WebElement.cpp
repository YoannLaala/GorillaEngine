/******************************************************************************
**	Includes
******************************************************************************/
#include "WebElement.hpp"

#include <Core/String/StringHelper.hpp>
#include <Core/String/String16.hpp>

#include <Web/WebBrowser.hpp>
#include <Web/Document/WebPage.hpp>
#include <Web/Document/WebStyle.hpp>
#include <Web/Element/WebElementStyle.hpp>

#include <Web/Component/WebComponent.hpp>
#include <Web/Component/WebComponentNode.hpp>
#include <Web/Property/Analyzer/WebPropertyAnalyzer.hpp>
#include <Web/Property/WebPropertyState.hpp>

#include <Renderer/Canvas/CanvasContext.hpp>
#include <Renderer/Canvas/Resource/Texture/CanvasSurface.hpp>

/******************************************************************************
**	Class Definition
******************************************************************************/
namespace Gorilla { namespace Web
{
	//!	@brief		Constructor
	//!	@date		2015-12-29
	WebElement::WebElement()
		: m_pPage(NULL)
		, m_uiTagId((uint32)-1)
		, m_pParent(NULL)	
		, m_uiId((uint32)-1)
		, m_eFlag(0)
	{
		memset(&m_aComponentIndex, (uint8)-1, EWebComponent::Count);
		memset(&m_aPropertyStateIndex, (uint8)-1, EWebProperty::Count);
	}

	//!	@brief		Destructor
	//!	@date		2015-12-29
	WebElement::~WebElement()
	{
		// Nothing to do
	}	

	//!	@brief		AddAttribute
	//!	@date		2015-12-29
	void WebElement::AddAttribute(const char* _szName, const char* _szValue)
	{
		// Identifier
		if(_strnicmp(_szName, "id", 2) == 0)
		{
			m_uiId = Identifier::Compute(_szValue);
			return;
		}

		// Class
		if(_strnicmp(_szName, "class", 5) == 0)
		{
			AddClass(_szValue);
			return;
		}

		// Style
		if(_strnicmp(_szName, "style", 5) == 0)
		{
			// Build source
			String sSource;
			sSource.Append("this{").Append(_szValue).Append("}");

			// Parse source and apply style associated
			WebElementStyle kStyle;
			WebStyle::Parse(&kStyle, sSource.GetBuffer(), sSource.GetLength());
			kStyle.ApplyOn(this);
		
			return;
		}

		//uint32 uiAttributeId = Identifier::Compute(_szName);
			
		// Create string attribute
		/*uint32 uiSize = (uint32)strlen(_szValue)+1;
		WebAttribute kAttribute;
		kAttribute.m_szValue = new char[uiSize];
		memcpy_s(kAttribute.m_szValue, uiSize, _szValue, uiSize);

		m_vAttribute.Add(uiAttributeId, kAttribute);*/
	}

	//!	@brief		AddClass
	//!	@date		2015-12-29
	void WebElement::AddClass(const char* _szName)
	{
		char* pCursor = const_cast<char*>(_szName);
		char* pPosition = strstr(pCursor, " ");
		while (pPosition)
		{
			uint32 uiClassId = Identifier::Compute(pCursor, (uint32)(pPosition - pCursor));
			m_vClassId.Add(uiClassId);
			pCursor = ++pPosition;

			pPosition = strstr(pCursor, " ");
		}

		uint32 uiClassId = Identifier::Compute(pCursor);
		m_vClassId.Add(uiClassId);
	}

	//!	@brief		AddElement
	//!	@date		2015-12-29
	void WebElement::AddElement(WebElement* _pElement)
	{
		_pElement->SetParent(this);
		m_vElement.Add(_pElement);
	}

	//!	@brief		Update
	//!	@date		2015-12-29
	void WebElement::Update() 
	{ 
		// Update all component
		const uint32 uiComponentCount = m_vComponent.GetSize();
		for(uint32 uiComponent = 0; uiComponent < uiComponentCount; ++uiComponent)
		{
			WebComponent* pComponent = m_vComponent[uiComponent];
			pComponent->Execute();
		}

		// Update all children
		const uint32 uiElementCount = m_vElement.GetSize();
		for(uint32 uiElement = 0; uiElement < uiElementCount; ++uiElement)
		{
			WebElement* pElement = m_vElement[uiElement];
			pElement->Update();
		}

		// Clean PropertyState
		/*const uint32 uiPropertyStateCount = m_vPropertyState.GetSize();
		for(uint32 uiPropertyState = 0; uiPropertyState < uiPropertyStateCount; ++uiPropertyState)
		{
			WebPropertyState& kPropertyState = m_vPropertyState[uiPropertyState];
			kPropertyState.SetProperty(NULL);
		}*/

		//const uint32 uiElementCount = m_vElement.GetSize();

		//

		//// Apply offset depending on size for each brother
		//Math::Vector2 vOffset;

		//for(uint32 uiElement = 0; uiElement < uiElementCount; ++uiElement)
		//{
		//	WebElement* pElement = m_vElement[uiElement];



		//	// Update position
		//	pElement->SetPosition(m_vPosition.GetX() + vOffset.GetX(), m_vPosition.GetY() + vOffset.GetY());
		//	if(GetWidth() <= vOffset.GetX() + pElement->GetWidth())
		//	{
		//		vOffset.Set(0, vOffset.GetY() + pElement->GetHeight());
		//	}
		//	else
		//	{
		//		vOffset.AddX(pElement->GetWidth());
		//	}

		//	// Recursive on child
		//	pElement->Update();
		//}
	}

	//!	@brief		Update
	//!	@date		2015-12-29
	void WebElement::OnChanged(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface)
	{
		if(HasFlag(EFlag::LayoutChanged))
		{
			WebComponentNode* pCpnNode = GetComponent<WebComponentNode>();

			const uint32 uiComponentCount = m_vComponent.GetSize();
			for(uint32 uiComponent = WebComponentNode::RTTI::GetType()+1; uiComponent < uiComponentCount; ++uiComponent)
			{
				WebComponent* pComponent = m_vComponent[uiComponent];
				pComponent->OnSizeChanged(_pContext, _pSurface, pCpnNode->GetWidth(), pCpnNode->GetHeight());
			}
			
			RemoveFlag(EFlag::LayoutChanged);
		}

		// Notify all children
		bool bChildLayoutChanged = false;
		const uint32 uiElementCount = m_vElement.GetSize();
		for(uint32 uiElement = 0; uiElement < uiElementCount; ++uiElement)
		{
			WebElement* pElement = m_vElement[uiElement];
			if(pElement->HasFlag(EFlag::LayoutChanged))
			{
				bChildLayoutChanged = true;
			}

			pElement->OnChanged(_pContext, _pSurface);
		}

		// Update position
		if(bChildLayoutChanged)
		{
			float32 fHeight = 0.0f;
			WebComponentNode* pCpnNode = GetComponent<WebComponentNode>();
			Math::Vector2 vPosition = pCpnNode->GetPosition();

			// Update all children
			const uint32 uiElementCount = m_vElement.GetSize();
			for(uint32 uiElement = 0; uiElement < uiElementCount; ++uiElement)
			{
				WebElement* pElement = m_vElement[uiElement];

				WebComponentNode* pCpnNodeElement = pElement->GetComponent<WebComponentNode>();
				pCpnNodeElement->SetPosition(vPosition.GetX(), vPosition.GetY());
				fHeight = Math::Max(fHeight, pCpnNodeElement->GetHeight());

				// Update position
				switch(pCpnNodeElement->GetDisplayType())
				{
					case EWebPropertyDisplay::Block:
					{
						vPosition.AddY(pCpnNodeElement->GetHeight());
						break;
					}

					default:
					{
						if(pCpnNode->GetWidth() <= vPosition.GetX() + pCpnNodeElement->GetWidth())
						{
							vPosition.Set(pCpnNode->GetLeft(), pCpnNode->GetTop() + pCpnNodeElement->GetHeight());
						}
						else
						{
							vPosition.AddX(pCpnNodeElement->GetWidth());
						}

						break;
					}
				}
			}
		}
		RemoveFlag(EFlag::Changed);
	}

	//void WebElement::OnSizeChanged()
	//{
	//	Renderer::CanvasContext* pContext = m_pPage->GetBrowser()->GetContext();
	//	Renderer::CanvasSurface* pSurface = m_pPage->GetSurface();
	//	for(uint32 uiComponent = 0; uiComponent < uiComponentCount; ++uiComponent)
	//	{
	//		WebComponent* pComponent = m_vComponent[uiComponent];
	//		pComponent->OnSizeChanged(pContext, pSurface, pCpnNode->GetWidth(), pCpnNode->GetHeight());
	//	}

	//	for(uint32 uiElement = 0; uiElement < uiElementCount; ++uiElement)
	//	{
	//		WebElement* pElement = m_vElement[uiElement];
	//		pElement->
	//	}

	//	RemoveFlag(EFlag::SizeChanged);
	//}


	//void WebElement::OnNodeChanged()
	//{
	//	WebComponentNode* pCpnNode = GetComponent<WebComponentNode>();

	//	// Apply node size when width and height has been set
	//	if(HasFlag(EFlag::SizeChanged))
	//	{
	//		Renderer::CanvasContext* pContext = m_pPage->GetBrowser()->GetContext();
	//		Renderer::CanvasSurface* pSurface = m_pPage->GetSurface();
	//		for(uint32 uiComponent = 0; uiComponent < uiComponentCount; ++uiComponent)
	//		{
	//			WebComponent* pComponent = m_vComponent[uiComponent];
	//			pComponent->OnSizeChanged(pContext, pSurface, pCpnNode->GetWidth(), pCpnNode->GetHeight());
	//		}

	//		for(uint32 uiElement = 0; uiElement < uiElementCount; ++uiElement)
	//		{
	//			WebElement* pElement = m_vElement[uiElement];
	//			pElement->
	//		}

	//		RemoveFlag(EFlag::SizeChanged);
	//	}

	//	// Update position
	//	float32 fHeight = 0.0f;
	//	Math::Vector2 vPosition = pCpnNode->GetPosition();
	//	for(uint32 uiElement = 0; uiElement < uiElementCount; ++uiElement)
	//	{
	//		WebElement* pElement = m_vElement[uiElement];

	//		WebComponentNode* pCpnNodeElement = pElement->GetComponent<WebComponentNode>();
	//		pCpnNodeElement->SetPosition(vPosition.GetX(), vPosition.GetY());
	//		fHeight = Math::Max(fHeight, pCpnNodeElement->GetHeight());

	//		// Update position
	//		if(pCpnNode->GetWidth() <= vPosition.GetX() + pCpnNodeElement->GetWidth())
	//		{
	//			vPosition.Set(pCpnNode->GetLeft(), pCpnNode->GetTop() + fHeight);
	//		}
	//		else
	//		{
	//			vPosition.AddX(pCpnNodeElement->GetWidth());
	//		}
	//	}	

	//	RemoveFlag(EFlag::NodeChanged);
	//}

	//!	@brief		PrepareAllComponent
	//! @details	Prepare all component for a scpecific category
	//!	@date		2015-12-29
	//void WebElement::PrepareAllComponent(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, EWebComponentCategory::Type _eCategory)
	//{
	//	// Prepare the component for the current category
	//	const uint32 uiComponentCount = m_vComponent.GetSize();
	//	for(uint32 uiComponent = 0; uiComponent < uiComponentCount; ++uiComponent)
	//	{
	//		WebComponent* pComponent = m_vComponent[uiComponent];
	//		pComponent->Prepare(_pContext, _pSurface);
	//	}
	//}

	//!	@brief		Prepare
	//! @details	Prepare all component
	//!	@date		2015-12-29
	//void WebElement::Prepare(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface) 
	//{ 
	//	PrepareAllComponent(_pContext, _pSurface, EWebComponentCategory::Tranform);
	//	PrepareAllComponent(_pContext, _pSurface, EWebComponentCategory::Content);
	//	PrepareAllComponent(_pContext, _pSurface, EWebComponentCategory::Decoration);

	//	// Prepare all children
	//	const uint32 uiElementCount = m_vElement.GetSize();
	//	if(uiElementCount)
	//	{
	//		for(uint32 uiElement = 0; uiElement < uiElementCount; ++uiElement)
	//		{
	//			WebElement* pElement = m_vElement[uiElement];
	//			pElement->Prepare(_pContext, _pSurface);
	//		}

	//		// Apply child size if needed
	//		/*WebComponentNode* pCpnNode = GetComponent<WebComponentNode>();
	//		pCpnNode->SetSize(pCpnNode->GetWidth() - pCpnNode->GetMarginRight(), pCpnNode->GetHeight());*/

	//		//if(!IsProperyOwned(EWebProperty::Width) || !IsProperyOwned(EWebProperty::Height))
	//		//{
	//		//	// Compute size depending on child
	//		//	Math::Vector2 vSize;
	//		//	for(uint32 uiElement = 0; uiElement < uiElementCount; ++uiElement)
	//		//	{
	//		//		WebElement* pElement = m_vElement[uiElement];
	//		//		WebComponentNode* pCpnNodeChild = pElement->GetComponent<WebComponentNode>();
	//		//		if(pCpnNodeChild)
	//		//		{
	//		//			vSize.Set(vSize.GetX() + pCpnNodeChild->GetWidth(), Math::Max(vSize.GetY(), pCpnNodeChild->GetHeight()));
	//		//		}
	//		//	}

	//		//	// Apply Width
	//		//	if(!IsProperyOwned(EWebProperty::Width))
	//		//	{
	//		//		float32 fWidth = Math::Min(vSize.GetX(), (float32)_pSurface->GetWidth());
	//		//		pCpnNode->SetWidth(fWidth);
	//		//	}

	//		//	// Apply Height
	//		//	if(!IsProperyOwned(EWebProperty::Height))
	//		//	{
	//		//		float32 fHeight = Math::Min(vSize.GetY(), (float32)_pSurface->GetHeight());
	//		//		pCpnNode->SetHeight(fHeight);
	//		//	}
	//		//}
	//	}

	//	// Clean PropertyState
	//	const uint32 uiPropertyStateCount = m_vPropertyState.GetSize();
	//	for(uint32 uiPropertyState = 0; uiPropertyState < uiPropertyStateCount; ++uiPropertyState)
	//	{
	//		WebPropertyState& kPropertyState = m_vPropertyState[uiPropertyState];
	//		kPropertyState.SetProperty(NULL);
	//	}

	//	m_bHasChanged = false;
	//}

	//!	@brief		PreDraw
	//! @details	Prepare all component
	//!	@date		2015-12-29
	//void WebElement::UpdatePosition() 
	//{ 
	//	// Apply offset on children if there are at least 1
	//	WebComponentNode* pCpnNode = GetComponent<WebComponentNode>();
	//	Math::Vector2 vMargin(pCpnNode->GetMarginLeft(), pCpnNode->GetMarginTop());
	//	Math::Vector2 vOffset(pCpnNode->GetMarginLeft() + pCpnNode->GetPositionLeft(), pCpnNode->GetPositionTop());

	//	const uint32 uiElementCount = m_vElement.GetSize();
	//	for(uint32 uiElement = 0; uiElement < uiElementCount; ++uiElement)
	//	{
	//		WebElement* pElement = m_vElement[uiElement];
	//		WebComponentNode* pCpnNodeChild = pElement->GetComponent<WebComponentNode>();
	//		if(pCpnNodeChild)
	//		{
	//			// Take the max between the margin bottom (previous) and the top (current)
	//			vMargin.Set(Math::Max(vMargin.GetX(), pCpnNodeChild->GetMarginLeft()), Math::Max(vMargin.GetY(), pCpnNodeChild->GetMarginTop()));
	//			vOffset.AddY(vMargin.GetY());
	//			pCpnNodeChild->SetPosition(vOffset.GetX(), vOffset.GetY());

	//			switch(pCpnNodeChild->GetDisplayType())
	//			{
	//				case EWebPropertyDisplay::Block:
	//				{
	//					vOffset.AddY(pCpnNodeChild->GetHeight());
	//					break;
	//				}

	//				case EWebPropertyDisplay::Inline:
	//				{
	//					if(pCpnNode->GetWidth() <= vOffset.GetX() + pCpnNodeChild->GetWidth())
	//					{
	//						vOffset.Set(pCpnNode->GetPositionLeft(), pCpnNode->GetPositionTop() + vOffset.GetY() + pCpnNodeChild->GetHeight());
	//					}
	//					else
	//					{
	//						vOffset.AddX(pCpnNodeChild->GetWidth());
	//					}
	//					break;
	//				}
	//			}	
	//			
	//			// Keep value of the margin bottom for the next one
	//			vMargin.Set(pCpnNodeChild->GetMarginRight(), pCpnNodeChild->GetMarginBottom());
	//		}
	//		pElement->UpdatePosition();
	//	}
	//}

	//!	@brief		Draw
	//! @details	Use rendered element
	//!	@date		2015-12-29
	//void WebElement::Draw(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface) 
	//{ 
	//	// Prepare element if it has changed
	//	if(HasChanged())
	//	{
	//		Prepare(_pContext, _pSurface);
	//		UpdatePosition();
	//	}

	//	// Rendering component
	//	for(uint32 uiComponentCategory = 0; uiComponentCategory < EWebComponentCategory::Count; ++uiComponentCategory)
	//	{
	//		// Prepare the component for the current category
	//		Vector<WebComponent*>& vComponent = m_aComponent[uiComponentCategory];
	//		const uint32 uiComponentCount = vComponent.GetSize();
	//		for(uint32 uiComponent = 0; uiComponent < uiComponentCount; ++uiComponent)
	//		{
	//			WebComponent* pComponent = vComponent[uiComponent];
	//			pComponent->Draw(_pContext, _pSurface);
	//		}
	//	}
	//	
	//	// Draw all children;
	//	const uint32 uiElementCount = m_vElement.GetSize();
	//	for(uint32 uiElement = 0; uiElement < uiElementCount; ++uiElement)
	//	{
	//		WebElement* pElement = m_vElement[uiElement];
	//		pElement->Draw(_pContext, _pSurface);
	//	}
	//}

	//!	@brief		Find
	//!	@date		2015-12-29
	void WebElement::Find(const WebSelector& _kSelector, Vector<WebElement*>& _vElement)
	{
		// Check if the element tag is the same
		if(_kSelector.GetTagId() == EWebElement::Count || _kSelector.GetTagId() == GetTagId())
		{
			// Check if the Id match
			bool bIdMatched = true;
			switch(_kSelector.GetIdType())
			{
				case EWebSelector::Id:
				{
					bIdMatched = _kSelector.GetId() == GetId();
					break;
				}

				case EWebSelector::Class:
				{
					bIdMatched = HasClassId(_kSelector.GetId());
					break;
				}
			}

			// Add the style if the id match
			if(bIdMatched)
			{
				_vElement.Add(this);
				return;
			}
		}

		// Continue on all children
		const uint32 uiElementCount = m_vElement.GetSize();
		for(uint32 uiElement = 0; uiElement < uiElementCount; ++uiElement)
		{
			WebElement* pElement = m_vElement[uiElement];
			pElement->Find(_kSelector, _vElement);
		}
	}

	//!	@brief		GetPropertyState
	//!	@date		2015-12-29
	WebPropertyState* WebElement::GetPropertyState(EWebProperty::Type _eProperty)
	{
		uint8 uiIndex = m_aPropertyStateIndex[_eProperty];
		if(uiIndex != (uint8)-1)
		{
			return &m_vPropertyState[uiIndex];
		}

		return NULL;
	}

	//!	@brief		GetOrCreatePropertyState
	//!	@date		2015-12-29
	WebPropertyState* WebElement::GetOrCreatePropertyState(EWebProperty::Type _eProperty)
	{
		WebPropertyState* pPropertyState = GetPropertyState(_eProperty);
		if(!pPropertyState)
		{
			uint8 uiIndex = (uint8)m_vPropertyState.GetSize();
			m_aPropertyStateIndex[_eProperty] = uiIndex;
			return &m_vPropertyState.Add();
		}

		return pPropertyState;
	}

	//!	@brief		IsPropertyAvailable
	//!	@date		2015-12-29
	bool WebElement::IsPropertyAvailable(EWebProperty::Type _eProperty, EWebSelector::Type _eSelector) const
	{
		const WebPropertyState* pPropertyState = GetPropertyState(_eProperty);
		if(pPropertyState)
		{
			if(pPropertyState->GetSelector() > _eSelector)
			{
				return false;
			}
		}
				
		return true;
	}

	//!	@brief		IsProperyOwner
	//!	@date		2015-12-29
	bool WebElement::IsProperyOwner(EWebProperty::Type _eProperty, const WebElementStyle* _pStyle) const 
	{
		const WebPropertyState* pPropertyState = GetPropertyState(_eProperty);
		return pPropertyState && pPropertyState->GetStyle() == _pStyle;
	}

	//!	@brief		SetPropertyOwner
	//!	@date		2015-12-29
	void WebElement::SetPropertyOwner(EWebProperty::Type _eProperty, EWebSelector::Type _eSelector, const WebElementStyle* _pStyle)
	{
		// Build property state if needed
		WebPropertyState* pPropertyState = GetOrCreatePropertyState(_eProperty);
		pPropertyState->SetSelector(_eSelector);
		pPropertyState->SetStyle(_pStyle);
	}

	//!	@brief		GetPropertyChanged
	//!	@date		2015-12-29
	const WebProperty* WebElement::GetPropertyChanged(EWebProperty::Type _eProperty)
	{
		// Build property state if needed
		uint8 uiIndex = m_aPropertyStateIndex[_eProperty];
		if(uiIndex != (uint8)-1)
		{
			WebPropertyState& kPropertyState = m_vPropertyState[uiIndex];
			return kPropertyState.GetProperty();
		}

		return NULL;
	}

	//!	@brief		SetProperty
	//!	@date		2015-12-29
	void WebElement::SetProperty(EWebProperty::Type _eProperty, const WebProperty* _pProperty) 
	{ 
		// Update Component property
		Renderer::CanvasContext* pContext = m_pPage->GetBrowser()->GetContext();
		Renderer::CanvasSurface* pSurface = m_pPage->GetSurface();
		WebComponent* pComponent = WebPropertyAnalyzer<EWebProperty::Unknown>::GetOrCreateComponent(this, _eProperty);
		pComponent->OnPropertyChanged(pContext, pSurface, _eProperty, _pProperty);	
		SetFlag(EFlag::Changed);
	}
}}