#ifndef _WEB_BROWSER_HPP_
#define _WEB_BROWSER_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>
#include <Core/Process/Mutex.hpp>
#include <Web/WebRequest.hpp>

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebDocument;
	class WebPage;
}}

namespace Gorilla { namespace Renderer
{
	class Renderer;
	class Texture2D;
	class CanvasContext;
}}

namespace v8
{
	class Platform;
	class Isolate;
}

/******************************************************************************
**	Class Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebBrowser
	{
		friend class WebPage;

	public:
		WebBrowser(Renderer::Renderer* _pRenderer = NULL);
		~WebBrowser();

		WebPage*		Open					(const char* _szUrl, Renderer::Texture2D* _pTexture = NULL);
		WebPage*		Open					(const char* _szUrl, uint32 _uiWidth, uint32 _uiHeight);
		WebPage*		Open					(uint32 _uiWidth, uint32 _uiHeight);							// Open blank page
		WebPage*		Open					(Renderer::Texture2D* _pTexture = NULL);						// Open blank page
		void			Close					(WebPage* _pPage);

		inline Renderer::CanvasContext* GetContext() { return m_pContext; }

	private:
		template <class T>
		T*				Open					();

		template <class T>
		T*				Open					(const char* _szUrl);

		bool			Open					(WebDocument* _pDocument, const char* _szUrl, WebPage* _pSource = NULL);
		void			Parse					(WebDocument* _pDocument, const char* _szBuffer, uint32 _uiSize, WebPage* _pSource = NULL);

	private:
		static void		RequestThreadEntry		(void* _pData);
		void			RequestLoop				();
		static size_t	HandleRequestResult		(char* _pSource, size_t n, size_t l, void* _pData);

		void			PushRequest				(WebDocument* _pDocument, const char* _szUrl, WebPage* _pSource = NULL);

	private:
		Vector<WebDocument*>			m_vDocument;
		Vector<Renderer::Texture2D*>	m_vTexture;
		Renderer::Renderer*				m_pRenderer;
		Renderer::CanvasContext*		m_pContext;
		v8::Platform*					m_pPlatform;
		v8::Isolate*					m_pIsolate;
		bool							m_bIsRendererInternal;

		// Thread
		Vector<WebRequest>				m_vRequest;
		Mutex							m_kMutexRequest;
		Condition						m_kConditionRequest;
		bool							m_bIsRunning;
	};

	//!	@brief		Open
	//!	@date		2016-01-30
	template <class T>
	T* WebBrowser::Open()
	{
		T* pDocument = new T();
		m_vDocument.Add(pDocument);

		return pDocument;
	}

	//!	@brief		Open
	//!	@date		2016-01-30
	template <class T>
	T* WebBrowser::Open(const char* _szUrl)
	{
		T* pDocument = Open<T>();
		Open(pDocument, _szUrl);

		return pDocument;
	}
}}
#endif