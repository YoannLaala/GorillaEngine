#ifndef _WEB_RESOURCE_FACTORY_HPP_
#define _WEB_RESOURCE_FACTORY_HPP_

/******************************************************************************
**	Includes
******************************************************************************/
#include <Core/Core.hpp>

/******************************************************************************
**	Forward Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{
	class WebElement;
	class WebProperty;
}}

namespace Gorilla { namespace Renderer
{
	class CanvasContext;
	class CanvasSurface;
	class CanvasBrush;
	class CanvasStyle;
	class CanvasGeometry;
	class CanvasFont;
	class CanvasText;
}}

/******************************************************************************
**	Class Declaration
******************************************************************************/
namespace Gorilla { namespace Web
{	
	class WebResourceFactory
	{
	public:

		static Renderer::CanvasBrush*		GetBrush(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, uint32 _uiColor);
		static Renderer::CanvasStyle*		GetStyle(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, uint32 _eLine);
		static Renderer::CanvasGeometry*	GetRectangle(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, float32 _fWidth, float32 _fHeight, float32 _fRadiusX = 0.0f, float32 _fRadiusY = 0.0f);
		static Renderer::CanvasGeometry*	GetElipse(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, float32 _fRadiusX, float32 _fRadiusY);
		static Renderer::CanvasFont*		GetFont(Renderer::CanvasContext* _pContext, const char* _szFamily, float32 _fSize, uint32 _uiWeight, uint32 _eStyle);
		static Renderer::CanvasText*		GetText(Renderer::CanvasContext* _pContext, Renderer::CanvasSurface* _pSurface, const char* _szText, Renderer::CanvasFont* _pFont);
	};
}}				

#endif