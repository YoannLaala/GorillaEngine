/******************************************************************************
**	Includes
******************************************************************************/
#include "WebSelector.hpp"

/******************************************************************************
**	Class Definition
******************************************************************************/
namespace Gorilla { namespace Web
{
	//!	@brief		Constructor
	//!	@date		2015-12-29
	WebSelector::WebSelector()
		: m_uiTagId((uint32)-1)
		, m_uiId((uint32)-1)
		, m_eSelector(EWebSelector::Tag)
		, m_eModifier(EWebModifier::Default)
	{
		// Nothing to do
	}

	//!	@brief		Destructor
	//!	@date		2015-12-29
	WebSelector::~WebSelector()
	{
		// Nothing to do
	}
}}